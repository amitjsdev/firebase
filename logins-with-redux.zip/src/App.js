import React from 'react';
import { connect } from 'react-redux';
import 'antd/dist/antd.css';
import './App.css';
import { Layout, Menu } from 'antd';
import AppHeader from './Components/AppHeader'
import AuthComponent from './Components/AuthComponent'
import bg from './assets/img/bg.jpg'
import Home from './Components/Home/Home'
import firebase from 'firebase/app';
import { setUser } from './Components/Home/store/HomeActions'
import 'firebase/auth';
import 'firebase/database';
import 'firebase/firestore';
import { FirebaseDynamicLinks as FDL } from 'firebase-dynamic-links';
const config = {
  apiKey: "AIzaSyDNvruyhBUmt5Jey0sI-G42lTGceiq3b5M",
  authDomain: "wannasplit-31c5c.firebaseapp.com",
  projectId: "wannasplit-31c5c",
  storageBucket: "wannasplit-31c5c.appspot.com",
  messagingSenderId: "737793658462",
  appId: "1:737793658462:web:0ca7ccdab10572c19f6ecf",
  measurementId: "G-V8X75M2FHZ"


};
firebase.initializeApp(config);

 
const firebaseDynamicLinks = new FDL(config);
const { Content, Footer, Sider } = Layout;


class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      loading: true,
      LoginPopoupVisible: false
    }
  }
  checkUserExist = async (provider, providerId) => {
    const db = firebase.firestore();
    const citiesRef = db.collection('users');
    const snapshot = await citiesRef.where(provider, '==', providerId).get();
    if (snapshot.empty) {
      return false;
    }
    let datum;
    snapshot.forEach(doc => {
      datum = doc.data()
      datum.dbId = doc.id
      console.log(doc.id, '=>', doc.data());
    });
    return datum;
  }
  logout =()=>{
    firebase.auth().signOut().then(() => {
      window.location.reload()
    }).catch((error) => {
      // An error happened.
    });
  }


  async componentDidMount() {
    firebase.auth().onAuthStateChanged(async (res) => {
      if (res) {
        const user = firebase.auth().currentUser
        this.setState({ loading: false });
        if (user != null) {
          let providerType = null;
          let providerId = null;
          user.providerData.forEach(function (profile) {
            providerType = profile.providerId;
            providerId = profile.uid;
          });

          const name = user.displayName;
          const email = user.email;
          const photoURL = user.photoURL;
          const emailVerified = user.emailVerified;
          const uid = user.uid;
          console.log(name, email, photoURL, emailVerified, uid,);
          let dbUser = null;
          if (email) {
            dbUser = await this.checkUserExist('email', email)
          } else if (providerType == 'phone' && providerId) {
            dbUser = await this.checkUserExist('providerId', providerId)
          }
          console.log({ dbUser });

          this.props.setUser({
            providerId, providerType, name, email, photoURL, emailVerified, uid, userRef: user, ...dbUser
          })
        }
      } else {
        console.log('uuun');
        this.setState({ loading: false });
      }
    });
  }


  ShowLoginPopoup = (e) => {
    e.preventDefault();
    this.setState({ LoginPopoupVisible: true })

  }

  render() {

    const { user, isAuthenticated } = this.props;
    const { LoginPopoupVisible } = this.state;

    return (
      <Layout style={{ backgroundImage: `url(${bg})`, height: '100vh' }}>
        <AppHeader showLoginPopoup={this.ShowLoginPopoup} logout={this.logout} isAuthenticated={isAuthenticated} />
        <Layout>

          <Content>
            {isAuthenticated ? <Home user={user} firebase={firebase} firebaseDynamicLinks={firebaseDynamicLinks} /> : <AuthComponent firebase={firebase} showLoginPopoup={LoginPopoupVisible} />}


          </Content>

        </Layout>
        {/* <Footer>footer</Footer> */}
      </Layout>
    );
  }
}
const mapStateToProps = state => {
  return {
    user: state.home.user,
    isAuthenticated: state.home.isAuthenticated,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    setUser: (payload) => dispatch(setUser(payload)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(App)