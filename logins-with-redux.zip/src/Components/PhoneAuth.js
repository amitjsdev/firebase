import React from 'react';
import { signInWithGoogle } from '../firebase/firebase.utils';
import { auth } from '../firebase/firebase.utils';
import firebase from '../firebase/firebase.utils';


class PhoneAuth extends React.Component { 
constructor(props) {
    super(props);
     this.state = {
      sendOTP: false,
      phone_number: "",
      currentUser: null,
      otp: "",
      isButtonDisabled: true,
      error: '',
      cardAnimation: 'cardHidden',
    };
  }
   componentDidMount() {
    this.setupRecaptcha();
     setTimeout(() => {
      this.setState({cardAnimation: ""});
    }, 700);
     // window.recaptchaVerifier.render().then(widgetId => {
    //
  window.recaptchaWidgetId = widgetId;
    // });
    // Removed, since it errors on load with this code.
   }
   setupRecaptcha = () => {
    window.recaptchaVerifier = new this.props.firebase.recaptchaVerifier(
      'recaptcha-container',
      {
        size: "normal",
        callback: response => {
          // reCAPTCHA solved, allow signInWithPhoneNumber.
          // ...
          this.setState({ isButtonDisabled: false });
        },
        "expired-callback": response => {
          // Response expired. Ask user to solve reCAPTCHA again.
          // ...
          this.setState({ isButtonDisabled: true, error: "Recaptcha Expired. Please try again." });
         }
      }
    );
    console.log(window.recaptchaVerifier)
    // Here is where i get the silent error about "strict" mode.
  };
   handleLogin = () => {
    let appVerifier = window.recaptchaVerifier;
    this.props.firebase.doSignInWithPhoneNumber(this.state.phone_number, appVerifier).then(confirmationResult => {
      this.setState({sendOTP: true});
      window.confirmationResult = confirmationResult;
    }).catch(err => {
      this.setState({error: err})
    })
  };
   handleOTPCheck = () => {
    window.confirmationResult
      .confirm(this.state.otp)
      .then(function(result) {
        // User signed in successfully.
        console.log(result);
        // ...
      })
      .catch(function(error) {
        // User couldn't sign in (bad verification code?)
        // ...
      });
  };
   handleSubmit(event) {
    event.preventDefault();
  }
   onChange = event => {
    this.setState({ [event.target.name]: event.target.value });
  };
   render() {
    const { phone_number, otp, error } = this.state;
     const isInvalid = phone_number === '';
    const { classes } = this.props;
     return (
      <div
        className={classes.pageHeader}
        style={{
          backgroundImage: "url(" + backgroundImage + ")",
          backgroundSize: "cover",
          backgroundPosition: "top center"
        }}
      >
        <div className={classes.container}>
          <Grid container justify="center">
            <Grid item xs={12} sm={12} md={4}>
              <Card className={classes[this.state.cardAnimation]}>
                <form className={classes.form}>
                
 <CardHeader color="primary" className={classes.cardHeader}>
                
   <Typography variant={'h4'}>Login</Typography>
                
 </CardHeader>
                
 <CardBody>
                
   <TextField
                
     label={"Phone Number"}
                
     id="phone_number"
                
     name={"phone_number"}
                
     fullWidth
                
      InputProps={{
                
     
 endAdornment: <InputAdornment position="end"><Phone/></InputAdornment>,
                
     }}
                
     type={"tel"}
                
   />
                
   <TextField
                
     label="One-Time Password"
                
     id="otp"
                
     name={"otp"}
                
     fullWidth
                
      InputProps={{
                
     
 endAdornment: <InputAdornment position="end"><Lock/></InputAdornment>,
                
     }}
                
      type={'password'}
                
     autoComplete={'false'}
                
   />
                
 </CardBody>
                
 <div id={'recaptcha-container'}/>
                
  <p className={classes.divider}>Standard messaging rates may apply.</p>
                
  <CardFooter className={classes.cardFooter}>
                
   <Button color="primary" size="large" onClick={this.handleLogin}>
                
     Verify
                
   </Button>
                
 </CardFooter>
                 </form>
              </Card>
            </Grid>
          </Grid>
        </div>
        <Footer whiteFont />
      </div>
    );
  } }
   const SignInForm = compose(
  withRouter,
  withFirebase, )(SignInFormBase);
  
  
  export default PhoneAuth;