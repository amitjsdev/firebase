import React, { Component } from "react";
import { Modal, FormGroup, Input } from "reactstrap";
import ContinueIcon from "../../assets/images/signin/continue.png";
import constant from "../../Services/constant.json"

class VerifyOTP extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      show: false,
    };
  }

  render() {
    return (
      <div className="login-page">
        <div className="login-wrapper verify-otp">
          <div className="icon">
            <img src={ContinueIcon} />
          </div>

          <h2 className="mb-4">{constant.VerifyOtp}</h2>
          <FormGroup className="mb-4">
            <Input type="text" placeholder="Name" />
          </FormGroup>

          <FormGroup className="mb-4">
            <Input type="email" placeholder="Email" />
          </FormGroup>
          <p className="otp-code-text">
            We have sent a 4 digit Code on
            <br />
            <span>
              9778676454<button className="ml-2 change-btn">Change</button>
            </span>
          </p>

          <button className="verify-btn">Continue</button>
        </div>
      </div>
    );
  }
}
export default VerifyOTP;
