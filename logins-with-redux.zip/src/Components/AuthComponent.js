
import React from 'react';
import { Modal, Row, Col, Button, Layout, Menu, Card, Alert } from 'antd';
import MobileAuth from "./MobileAuth";
import EmailAuth from "./EmailAuth";
import { connect } from 'react-redux';
import { setUser } from './Home/store/HomeActions'
const { Header, Footer, Sider } = Layout;

class AuthComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            modal1Visible: false,
            modal2Visible: false,
            currentUser: null,
            auth: '',
            auth_type: '',
            email: '',
            first_name: '',
            id: '',
            last_name: '',
            name: '',
            profile: '',
            token: '',
            phoneModal: null,
            emailModal: false
        };

    }

    checkUserExist = async (mail) => {
        const db = this.props.firebase.firestore();
        const citiesRef = db.collection('users');
        const snapshot = await citiesRef.where('email', '==', mail).get();
        if (snapshot.empty) {
            return false;
        }
        let datum;
        snapshot.forEach(doc => {
            datum = doc.data()
            datum.dbId = doc.id
            console.log(doc.id, '=>', doc.data());
        });
        return datum;
    }

    insertIntoDb = async (data) => {
        const db = this.props.firebase.firestore();
        const citiesRef = db.collection('users');
        const snapshot = await citiesRef.add(data);

        return snapshot;
    }

    updateReduxStore = (data) => {
        this.props.setUser(data)
    }

    loginWithGoogleClickHandler = async () => {
        const firebase = this.props.firebase;
        const provider = new firebase.auth.GoogleAuthProvider();
        provider.setCustomParameters({ prompt: 'select_account' });
        firebase.auth().signInWithPopup(provider).then(async (resp) => {
            console.log({ resp })
            const mail = resp.user.email;
            const isExistinDb = await this.checkUserExist(mail);
            console.log('isExistinDb', isExistinDb);
            if (isExistinDb) {
                this.updateReduxStore(isExistinDb)
                //update redux store 
            } else {
                let data = {
                    email: resp.user.email,
                    name: resp.user.displayName,
                    picture: resp.user.picture ? resp.user.picture : '',
                    auth_type: 'google'
                }
                console.log({ data })
                const isInserted = await this.insertIntoDb(data);
                if (isInserted && isInserted.id) {
                    data.dbId = isInserted.id;
                    this.updateReduxStore(data)
                    //update redux store  
                }

            }


        })

    }

    phoneAuthHandler = async () => {
        this.setState({ phoneModal: true })
    }

    emailSignUp = async ({ email, password }) => {
        console.log(email, password);
        this.setState({ registering: true, registerErr: null })
        this.props.firebase.auth().createUserWithEmailAndPassword(email, password)
            .then(async (userCredential) => {
                const isExistinDb = await this.checkUserExist(email);
                console.log('isExistinDb', isExistinDb);
                if (isExistinDb) {
                    this.updateReduxStore(isExistinDb)
                    //update redux store 
                } else {
                    let data = {
                        email: email,
                        name: '',
                        picture: '',
                        auth_type: 'email'
                    }
                    console.log({ data })
                    const isInserted = await this.insertIntoDb(data);
                    if (isInserted && isInserted.id) {
                        data.dbId = isInserted.id;
                        this.updateReduxStore(data)
                        //update redux store  
                    }

                }
                this.setState({ registering: false })
            })
            .catch((error) => {
                this.setState({
                    registering: false,
                    registerErr: error.message
                })
                console.log({ error });
            });
    }
    emailLogin = async ({ email, password }) => {
        console.log(email, password);
        this.setState({ logging: true, loginErr: null })
        this.props.firebase.auth().signInWithEmailAndPassword(email, password)
            .then(async (userCredential) => {
                const isExistinDb = await this.checkUserExist(email);
                console.log('isExistinDb', isExistinDb);
                if (isExistinDb) {
                    this.updateReduxStore(isExistinDb)
                    //update redux store 
                } else {
                    let data = {
                        email: email,
                        name: '',
                        picture: '',
                        auth_type: 'email'
                    }
                    console.log({ data })
                    const isInserted = await this.insertIntoDb(data);
                    if (isInserted && isInserted.id) {
                        data.dbId = isInserted.id;
                        this.updateReduxStore(data)
                        //update redux store  
                    }

                }
                this.setState({ logging: false })
            })
            .catch((error) => {
                this.setState({
                    logging: false,
                    loginErr: error.message
                })
                console.log({ error });
            });

    }


    PhoneCallback = async (number) => {
        const isExist = this.checkUserExist(number);
        if (!isExist) {
            let data = {
                email: number,
                name: '',
                picture: '',
                auth_type: 'phone'
            }
            const isInserted = await this.insertIntoDb(data)
            if (isInserted) {
                this.updateReduxStore(isInserted)
            } else {
                this.setState({ error: true, errorMessage: '', phoneModal: false })
            }
        } else {
            this.updateReduxStore(isExist)
            this.setState({ phoneModal: false })
        }

    }

    fbAuthHandler = async () => {
        const firebase = this.props.firebase;
        const provider = new firebase.auth.FacebookAuthProvider();
        firebase.auth().signInWithPopup(provider).then(async (result) => {
            const credential = result.credential;
            // The signed-in user info.
            const user = result.user;
            const mail = user.email;
            console.log(user.providerId);
            const isExistinDb = await this.checkUserExist(mail);
            console.log('isExistinDb', isExistinDb);
            if (isExistinDb) {
                this.updateReduxStore(isExistinDb)
                //update redux store 
            } else {
                let data = {
                    email: mail,
                    name: '',
                    picture: '',
                    auth_type: 'facebook'
                }
                console.log({ data })
                const isInserted = await this.insertIntoDb(data);
                if (isInserted && isInserted.id) {
                    data.dbId = isInserted.id;
                    this.updateReduxStore(data)
                    //update redux store  
                }

            }
        })
            .catch((error) => {
                // Handle Errors here.
                const errorCode = error.code;
                const errorMessage = error.message;
                // The email of the user's account used.
                const email = error.email;
                // The firebase.auth.AuthCredential type that was used.
                const credential = error.credential;

                // ...
            });
    }

    setModal2Visible(modal2Visible) {
        this.setState({ modal2Visible });
    }


    render() {

        return (
            <> <div id="recaptcha-container" className="recaptcha-container"></div>
                <Modal
                    visible={this.state.phoneModal}
                    //closable={false}
                    footer={false}
                    zIndex={1000}
                    onCancel={e => this.setState({ phoneModal: false })}
                >
                    <MobileAuth firebase={this.props.firebase} callback={this.PhoneCallback} />
                </Modal>
                <Modal
                    visible={this.state.emailModal}
                    //closable={false}
                    footer={false}
                    zIndex={1000}
                    onCancel={e => this.setState({ emailModal: false })}
                >
                    <EmailAuth register={this.emailSignUp} login={this.emailLogin}
                        registerErr={this.state.registerErr}
                        loginErr={this.state.loginErr}
                        registering={this.state.registering}
                        logging={this.state.logging}

                    />
                </Modal>


                <Modal
                    visible={this.props.showLoginPopoup}
                    closable={false}
                    footer={false}
                    zIndex={999}
                >
                    <Card>
                        <h1 className="heading">Get Start</h1>
                        <Alert type="info" message="By clicking Log in, you agree to our Terms.Learn how we process your data in our Privacy Policy. and Cookie Policy" />
                        <div className="row">
                            <Card >
                                <Button onClick={this.fbAuthHandler}
                                    type="primary"
                                    shape="round"
                                    size="large"
                                >Log in with  Facebook</Button>
                            </Card>
                        </div>
                        <div className="row">
                            <Card >
                                <Button onClick={this.loginWithGoogleClickHandler}
                                    type="primary"
                                    shape="round"
                                    size="large"
                                >Log in with Google </Button>
                            </Card>
                        </div>
                        <div className="row">
                            <Card >
                                <Button onClick={this.phoneAuthHandler}
                                    type="primary"
                                    shape="round"
                                    size="large"
                                >Log in with Phone Number
                            </Button>
                            </Card>
                        </div>
                        <div className="row">
                            <Card >
                                <Button onClick={e => this.setState({ emailModal: true })}
                                    type="primary"
                                    shape="round"
                                    size="large"
                                >Sign up with Email
                            </Button>
                            </Card>
                        </div>
                    </Card>
                </Modal>
            </>

        );
    }
}
const mapStateToProps = state => {
    return {
        data: state.home.data,
    };
};

const mapDispatchToProps = dispatch => {
    return {
        setUser: payload => dispatch(setUser(payload)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(AuthComponent)