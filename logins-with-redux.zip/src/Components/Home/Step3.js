import React from 'react';
import { Form, Input, InputNumber, Button, Card } from 'antd';
const layout = {
    labelCol: {
        span: 8,
    },
    wrapperCol: {
        span: 16,
    },
};
const validateMessages = {
    required: '${label} is required!',
    types: {
        email: '${label} is not a valid email!',
        number: '${label} is not a valid number!',
    },
    number: {
        range: '${label} must be between ${min} and ${max}',
    },
};

const Step3 = ({next}) => {
    const onFinish = (values) => {
        next({step:3,...values})
    };

    return (
        <Card>
            <Form {...layout} layout="vertical" name="nest-messages" onFinish={onFinish} validateMessages={validateMessages}>


                <Form.Item name="introduction" label="Tell us something about yourself"
                    rules={[
                        {
                            required: true,
                            message: ' Tell us something about yourself'
                        },
                    ]}
                    hasFeedback>
                    <Input.TextArea />
                </Form.Item>
                <Form.Item >
                    <Button type="primary" htmlType="submit">
                        Submit
        </Button>
                </Form.Item>
            </Form>
        </Card>
    );
};
export default Step3;