import React from 'react'
import { connect } from 'react-redux';
import Community from './Community';
import CompleteSignup from './CompleteSignup';
import {setUser} from './store/HomeActions'
class Home extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            signUpCompleted:false
        }

    }

    complete =async(data)=>{
        
        let {user}=this.props;
        console.log(data, user);
        user ={...user, ...data, signUpCompleted:true};
        const postData ={...user};
        delete postData.userRef;
        delete postData.dbUser;
        console.log(postData);
        const db = this.props.firebase.firestore();
        const res = await db.collection('users').doc(user.dbId).set(postData);
        console.log(res);
        this.setState({signUpCompleted:true})
        this.props.setUser(user)
    }

    render() {
        const {user,firebase, firebaseDynamicLinks} =this.props;

        return (
            <>
                {
                    user  && user.signUpCompleted ? 
                    <Community 
                    firebase={firebase} 
                    user={user}
                    firebaseDynamicLinks={firebaseDynamicLinks}
                    /> : <CompleteSignup complete={this.complete}  user={user}/>
                }
            </>
        );
    }
}

const mapStateToProps = state => {
    return {
        user: state.home.user,
        isAuthenticated: state.home.isAuthenticated,
    };
};

const mapDispatchToProps = dispatch => {
    return {
        setUser: (payload) => dispatch(setUser(payload)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(Home)
