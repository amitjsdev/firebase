
import React from 'react';
import { Modal, Button } from 'antd';
import { Card, Col, Row } from 'antd';
import { Alert } from 'antd';
import { Steps, message } from 'antd';
import { Typography } from 'antd';
import Step1 from './Step1';
import Step2 from './Step2';
import Step3 from './Step3';
import { RightCircleOutlined } from '@ant-design/icons';
const { Title } = Typography;
const { Step } = Steps;
class CompleteSignup extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      modal2Visible: true,
      current: 0,
      data:{},
      profile:{}
    };
  }
  

  setModal2Visible(modal2Visible) {
    this.setState({ modal2Visible });
  }

  complete =()=>{
    this.props.complete(this.state.profile)
  }
  next = (payload) => {
    let { data ,profile} = this.state;
    data[payload.step] = payload;
    profile={...profile, ...payload}
    this.setState({ data, current: payload.step ,profile })
  };


  render() {
    const { current } = this.state;
    const {user} =this.props;
    const steps = [
      {
        title: 'First',
      },
      {
        title: 'Second',
      },
      {
        title: 'Last',
      },
    ];
    return (
      <>

       
        <Modal
          title={<Title level={3}>Hello {user && user.name ? user.name :''}</Title>}
          centered
          visible={this.state.modal2Visible}
          onOk={() => this.setModal2Visible(false)}
          onCancel={() => this.setModal2Visible(false)}
          closeIcon={false}
          closable={false}
          width={1000}
          footer={null}
        >
          <Card title={<Alert message={<Title level={4}>Please Complete SignUp Process</Title>} type="info" />} bordered={false}>
            <Steps current={current}>
              {steps.map(item => (
                <Step key={item.title} />
              ))}
            </Steps>
            <div className="steps-content" style={{ marginTop: '20px' }}>
              {
                current == 0 ? <Step1 next={this.next} /> :
                  current == 1 ? <Step2 next={this.next} /> :
                    current == 2 ? <Step3 next={this.next} /> :
                      null
              }
            </div>
            <div className="steps-action">
              {current == 3 ?
              <> 
              <Alert
                message="Wow &#128077;"
                description="Congratulations for being a #SuperMom"
                type="success"
                showIcon
              />
              <Button
              style={{marginTop:'20px'}}
              type="primary"
              size="large"
              shape="round"
              icon={<RightCircleOutlined />}
              
              onClick={this.complete}
            >
              Next
            </Button>
            </>
             : null}
            </div>

          </Card>
        </Modal>
      </>
    );
  }
}

export default CompleteSignup;