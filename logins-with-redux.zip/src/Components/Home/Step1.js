import React from 'react';
import { Form, DatePicker, Card, Button } from 'antd';
const formItemLayout = {
    layout:'vertical',
  labelCol: {
    xs: {
      span: 24,
    },
    sm: {
      span: 8,
    },
  },
  wrapperCol: {
    xs: {
      span: 24,
    },
    sm: {
      span: 16,
    },
  },
};
const config = {
  rules: [
    {
      type: 'object',
      required: true,
      message: 'Please select your date of birth',
    },
  ],
};

const Step1 = ({next}) => {
  const onFinish = (fieldsValue) => {
    const values = {
      ...fieldsValue,
      'dob': fieldsValue['dob'].format('DD-MM-YYYY'),
    };
    console.log({values});
    next({step:1,...values})
  };
  const disabledDate=(current) =>{
    // Can not select days before today and today
    return current && current.valueOf() > Date.now();
  }

  return (
    <Card title={null} style={{marginTop:'20px'}} >
    <Form name="time_related_controls" {...formItemLayout} onFinish={onFinish}>
      <Form.Item name="dob" label="Please select your date of birth" {...config} hasFeedback >
        <DatePicker
          disabledDate={disabledDate}
          format="DD-MM-YYYY"
          style={{
          width: '100%',
        }}/>
      </Form.Item>
      
      <Form.Item
        // wrapperCol={{
        //   xs: {
        //     span: 24,
        //     offset: 0,
        //   },
        //   sm: {
        //     span: 16,
        //     offset: 8,
        //   },
        // }}
      >
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
      </Form.Item>
    </Form>
    </Card>
  );
};

export default Step1; 