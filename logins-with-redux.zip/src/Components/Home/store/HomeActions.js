import * as ActionTypes from './HomeActionTypes';
import Axios from 'axios';
import { message } from 'antd';

export const setLoading = (payload) => ({
    type: ActionTypes.HOME_LOADING,
    payload
})

export const setError = (payload) => ({
    type: ActionTypes.LOAD_HOME_FAILURE,
    payload
})

export const setUser = (payload) => ({
    type: ActionTypes.LOAD_HOME_SUCCESS,
    payload
})

export const loadHome = (payload) => ({
    type: ActionTypes.LOAD_HOME,
    payload
})

export const updateHome = (payload) => ({
    type: ActionTypes.UPDATE_HOME,
    payload
})

