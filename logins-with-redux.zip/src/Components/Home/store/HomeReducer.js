import * as ActionTypes from './HomeActionTypes';

const initialState = {
    data: [{lkm:true}],
    loading: false,
    loaded: false,
    error: {},
    user:undefined,
    isAuthenticated:false,
}

export default (state = initialState, { type, payload }) => {
    switch (type) {

    case ActionTypes.LOAD_HOME:
        return { ...state, data: payload, loading:true }

    case ActionTypes.LOAD_HOME_SUCCESS:
        return { ...state, user: payload, isAuthenticated:true }
    
    case ActionTypes.LOAD_HOME_FAILURE:
        return { ...state, error: payload,loading:false }
    
    case ActionTypes.HOME_LOADING:
        return { ...state, loading: payload }

    case ActionTypes.UPDATE_HOME: 
        return {...state, data: payload,loaded: true,loading:false}

    default:
        return state;
    }
}
