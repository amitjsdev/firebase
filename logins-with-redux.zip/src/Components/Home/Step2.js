import React from 'react';
import { Form, Input, Button, Select, Space, Card } from 'antd';
const { Option } = Select;
const layout = {
    layout: 'vertical',
    labelCol: {
        span: 8,
    },
    wrapperCol: {
        span: 16,
    },
};

const Step2 = ({next}) => {
    const [form] = Form.useForm();


    const onFinish = (values) => {
        next({step:2,...values})
    };



    return (
        <Card >
            <Form {...layout} form={form} name="control-hooks" onFinish={onFinish}>

                <Form.Item
                    name="motherOrNot"
                    label="We would like you to tell us if "
                    rules={[
                        {
                            required: true,
                            message: 'Please select an option'
                        },
                    ]}
                >
                    <Select
                        placeholder="Select an option "
                        allowClear
                    >
                        <Option value="You are a mother ">You are a mother </Option>
                        <Option value="You will be a mother soon ">You will be a mother soon </Option>
                        <Option value="other">other</Option>
                    </Select>
                </Form.Item>

                <Form.Item >
                    <Button type="primary" htmlType="submit">
                        Submit
        </Button>

                </Form.Item>
            </Form>
        </Card>
    );
};
export default Step2;