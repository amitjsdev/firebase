import React, { Component } from "react";
import firebaseComponent from "@firebase/app";
import { Form, DatePicker, Card, Button, Alert } from 'antd';
import { Modal, Row, Col, Input, Layout, Menu } from 'antd';

const config = {
    rules: [
        {
            type: 'string',
            required: true,
            message: 'Please Enter your Phone number',
        },
    ],
};
class MobileAuth extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            number: '',
            otpSend: false,
            sending:false,
            error:undefined,
            verifying:null,
            verifyError:null,
            code :null
        };
    }
    onFinish = ({ number }) => {
        this.setState({ number, sending:true })
        //console.log(this.state)
        this.verifyNumber();
    };
    resend =(e)=>{
        e.preventDefault();
        this.setState({
            otpSend: false,
            sending:false,
            error:undefined,
            verifying:null,
            verifyError:null, 
        },()=>this.verifyNumber())
    }
    verifyNumber = () => {
        const { number } = this.state;
        const firebase = this.props.firebase;
        this.SetUpReCaptcha();
        let appVerifier = window.recaptchaVerifier;
        !!firebase &&
            firebase
                .auth()
                .signInWithPhoneNumber(number, appVerifier)
                .then((confirmationResult) => {
                    this.setState({ otpSend: true, confirmationResult })
                })
                .catch( (error)=> {
                    
                    this.setState({ otpSend: false, error:error.toString() })
                });
    };

    SetUpReCaptcha = () => {
        const firebase = this.props.firebase;
        window.recaptchaVerifier = new firebaseComponent.auth.RecaptchaVerifier(
            "recaptcha-container",
            {
                size: "invisible",
                callback: function (response) {
                    this.verifyNumber();
                },
            }
        );
    };

    handleVerifyOTP = ({ otp }) => {
        this.setState({verifying:true, verifyError:null,code:null})
        const { confirmationResult } = this.state;
        window.confirmationResult = confirmationResult;
        confirmationResult
            .confirm(otp)
            .then((result)=> {
                console.log("accept", result);
                this.setState({verifying:false, verify:true,verifyError:null })
                //var user = result.user;

            })
            .catch((error) => {
                this.setState({verifying:false, verify:false,verifyError:error.message,code:error.code })
                console.log("error", error);
            });
    };

    componentDidUpdate(prevProps, prevState){
        if(this.state.verify && this.state.verify != prevState.verify){
            this.props.callback(this.state.number)
        }
    }


    render() {
        const { otpSend, sending, error,verifying, verify,verifyError,code} = this.state;
        return (
            <Card title={null} style={{ marginTop: '20px' }} >
                {otpSend ?
                    <Form name="time_related_controls" layout="vertical" onFinish={this.handleVerifyOTP}>
                        <Form.Item name="otp" label="Enter OTP" hasFeedback 
                        rules={ [
                            {
                                type: 'string',
                                required: true,
                                message: 'Please Enter OTP',
                            },
                            { min: 6, message: 'Invalid OTP' },
                            { max: 6, message: 'Invalid OTP' }
                        ]}>
                            <Input />
                        </Form.Item>
                        {verifyError ?  <Form.Item>
                            <Alert type="error" message={verifyError}/>
                        </Form.Item> : null }
                        {verify ?  <Form.Item>
                            <Alert type="success" message='Number verified'/>
                        </Form.Item> : null }
                        <Form.Item>
                            {verify ? 
                             <Button type="primary" htmlType="submit">
                                 Next
                              
                             </Button>:
                            <Button type="primary" htmlType="submit">
                            {verifying ? 'Verifying..':'Verify OTP'}
                             
                            </Button>
                             }
                             {code =='auth/code-expired' &&  <Button type="primary" onClick={this.resend}>
                                 Resend OTP
                              
                             </Button>}
                        </Form.Item>
                    </Form>
                    :
                    <Form name="time_related_controls" layout="vertical" onFinish={this.onFinish}>
                        <Form.Item name="number" label="Enter your Mobile Number" hasFeedback 
                        rules={ [
                            { type: 'string',required: true, message: 'Please Enter Phone Number',},
                            { min: 13, message: 'Invalid Phone Number' },
                            { max: 13, message: 'Invalid Phone Number' }
                        ]}
                        >
                            <Input placeholder="+9199XXXXXXXX" />
                        </Form.Item>
                        {error ?  <Form.Item>
                            <Alert type="error" message={error}/>
                        </Form.Item> : null }
                        <Form.Item>
                            <Button type="primary" htmlType="submit">
                            {sending ? 'Sending ...':'Send OTP'} 
                            </Button>
                        </Form.Item>
                    </Form>
                }
            </Card>
        );
    }
}

export default MobileAuth;
