import React, { Component } from "react";
import firebaseComponent from "@firebase/app";
import { Form, DatePicker, Card, Button, Alert } from 'antd';
import { Modal, Row, Col, Input, Layout, Menu } from 'antd';
import { Tabs } from 'antd';

const { TabPane } = Tabs;
const config = {
    rules: [
        {
            type: 'string',
            required: true,
            message: 'Please Enter your Phone number',
        },
    ],
};
class EmailAuth extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
           
        };
    }

    

    render() {
        const { login, register, loginErr, registerErr, registering,logging } = this.props;
        return (
            <Card title={null} style={{ marginTop: '20px' }} >
                <Tabs defaultActiveKey="1" >
                    <TabPane tab="Login" key="1">
                        <Form name="time_related_controls" layout="vertical" onFinish={login}>
                            <Form.Item name="email" label="Enter your email" hasFeedback
                                rules={[
                                    { type: 'email', required: true, message: 'Please Enter email', },
                                ]}
                            >
                                <Input placeholder="" />
                            </Form.Item>
                            <Form.Item name="password" label="Enter your password" hasFeedback
                                rules={[
                                    { type: 'string', required: true, message: 'Please Enter password', },
                                    // { min: 6, message: 'Password must have at least 6 characters' },
                                ]}
                            >
                                <Input placeholder="" type="password" />
                            </Form.Item>
                            {loginErr ? <Form.Item>
                                <Alert type="error" message={loginErr} />
                            </Form.Item> : null}
                            <Form.Item>

                                <Button type="primary" htmlType="submit" >
                                    {logging ? 'logging ...' : 'Login'}
                                </Button>
                            </Form.Item>
                        </Form>

                    </TabPane>
                    <TabPane tab="Register" key="2">
                        <Form name="time_related_controls" layout="vertical" onFinish={register}>
                            <Form.Item name="email" label="Enter your email" hasFeedback
                                rules={[
                                    { type: 'email', required: true, message: 'Please Enter email', },
                                ]}
                            >
                                <Input placeholder="" />
                            </Form.Item>
                            <Form.Item name="password" label="Enter your password" hasFeedback
                                rules={[
                                    { type: 'string', required: true, message: 'Please Enter password', },
                                    { min: 6, message: 'Password must have at least 6 characters' },
                                ]}
                            >
                                <Input placeholder="" type="password" />
                            </Form.Item>
                            {registerErr ? <Form.Item>
                                <Alert type="error" message={registerErr} />
                            </Form.Item> : null}
                            <Form.Item>
                                <Button type="primary" htmlType="submit">
                                    {registering ? 'Registering ...' : 'Register'}
                                </Button>

                            </Form.Item>
                        </Form>

                    </TabPane>

                </Tabs>
               
            </Card>
        );
    }
}

export default EmailAuth;
