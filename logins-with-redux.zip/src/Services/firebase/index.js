import getFirebase from './firebaseConfig';

export default function useFirebase() {
  // const [instance, setInstance] = useState(null);

  // useEffect(() => {
  //   setInstance(getFirebase());
  // }, []);

  return getFirebase();
} 