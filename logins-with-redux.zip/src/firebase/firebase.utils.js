import firebase from 'firebase/app';
import 'firebase/auth';
import 'firebase/database';
const settings = {timestampsInSnapshots: true};


const config = {
  apiKey: "AIzaSyDNvruyhBUmt5Jey0sI-G42lTGceiq3b5M",
  authDomain: "wannasplit-31c5c.firebaseapp.com",
  projectId: "wannasplit-31c5c",
  storageBucket: "wannasplit-31c5c.appspot.com",
  messagingSenderId: "737793658462",
  appId: "1:737793658462:web:a4894ec4f523929e9f6ecf",
  measurementId: "G-QDYDXWL1N9"

};

 
firebase.initializeApp(config);
export const auth = firebase.auth();

const provider = new firebase.auth.GoogleAuthProvider();
provider.setCustomParameters({ prompt: 'select_account' });

export const signInWithGoogle = () => {
			auth.signInWithPopup(provider).then((resp) =>{
			//console.log("resp",resp.additionalUserInfo.profile);
			console.log("resp",resp);
			// this.ref = firebase.firestore().collection('boards');
			/*  Firebase.database()
      .ref("/")
      .set(this.state);
    console.log("DATA SAVED"); */
	
			})
}
export default firebase;



