const challenges = [
    {
        "companyName": "Pfizer",
        "companyURL": "http://www.pfizer.com",
        "challengeName": "Pfizer Digital Health Innovation Challenge",
        "challengeDescription": "Help Pfizer build the future of Health IT",
        "challengeCashPrize": 100000,
        "challengeOtherPrize": "mentorship",
        "challengeURL": "http://www.pfizer.com",
        "tags": ["healthcare", "software"]
    },
    {
        "companyName": "Ameritas",
        "companyURL": "http://www.ameritas.com",
        "challengeName": "Ameritas Life Insurance Provider Challenge",
        "challengeDescription": "Help Ameritas build the future of Life Insurance",
        "challengeCashPrize": 50000,
        "challengeOtherPrize": "mentorship and travel",
        "challengeURL": "http://www.ameritas.com",
        "tags": ["insurance", "software"]
    },
    {
        "companyName": "Ameritas",
        "companyURL": "http://www.ameritas.com",
        "challengeName": "Ameritas Life Insurance Provider Challenge",
        "challengeDescription": "Help Ameritas build the future of Life Insurance",
        "challengeCashPrize": 50000,
        "challengeOtherPrize": "mentorship and travel",
        "challengeURL": "http://www.ameritas.com",
        "tags": ["insurance", "software"]
    },
    {
        "companyName": "Ameritas",
        "companyURL": "http://www.ameritas.com",
        "challengeName": "Ameritas Life Insurance Provider Challenge",
        "challengeDescription": "Help Ameritas build the future of Life Insurance",
        "challengeCashPrize": 50000,
        "challengeOtherPrize": "mentorship and travel",
        "challengeURL": "http://www.ameritas.com",
        "tags": ["insurance", "software"]
    },
    {
        "companyName": "Ameritas",
        "companyURL": "http://www.ameritas.com",
        "challengeName": "Ameritas Life Insurance Provider Challenge",
        "challengeDescription": "Help Ameritas build the future of Life Insurance",
        "challengeCashPrize": 50000,
        "challengeOtherPrize": "mentorship and travel",
        "challengeURL": "http://www.ameritas.com",
        "tags": ["insurance", "software"]
    },
    {
        "companyName": "Ameritas",
        "companyURL": "http://www.ameritas.com",
        "challengeName": "Ameritas Life Insurance Provider Challenge",
        "challengeDescription": "Help Ameritas build the future of Life Insurance",
        "challengeCashPrize": 50000,
        "challengeOtherPrize": "mentorship and travel",
        "challengeURL": "http://www.ameritas.com",
        "tags": ["insurance", "software"]
    },
    {
        "companyName": "Ameritas",
        "companyURL": "http://www.ameritas.com",
        "challengeName": "Ameritas Life Insurance Provider Challenge",
        "challengeDescription": "Help Ameritas build the future of Life Insurance",
        "challengeCashPrize": 50000,
        "challengeOtherPrize": "mentorship and travel",
        "challengeURL": "http://www.ameritas.com",
        "tags": ["insurance", "software"]
    },
    {
        "companyName": "Ameritas",
        "companyURL": "http://www.ameritas.com",
        "challengeName": "Ameritas Life Insurance Provider Challenge",
        "challengeDescription": "Help Ameritas build the future of Life Insurance",
        "challengeCashPrize": 50000,
        "challengeOtherPrize": "mentorship and travel",
        "challengeURL": "http://www.ameritas.com",
        "tags": ["insurance", "software"]
    },
    {
        "companyName": "Ameritas",
        "companyURL": "http://www.ameritas.com",
        "challengeName": "Ameritas Life Insurance Provider Challenge",
        "challengeDescription": "Help Ameritas build the future of Life Insurance",
        "challengeCashPrize": 50000,
        "challengeOtherPrize": "mentorship and travel",
        "challengeURL": "http://www.ameritas.com",
        "tags": ["insurance", "software"]
    },
    {
        "companyName": "Ameritas",
        "companyURL": "http://www.ameritas.com",
        "challengeName": "Ameritas Life Insurance Provider Challenge",
        "challengeDescription": "Help Ameritas build the future of Life Insurance",
        "challengeCashPrize": 50000,
        "challengeOtherPrize": "mentorship and travel",
        "challengeURL": "http://www.ameritas.com",
        "tags": ["insurance", "software"]
    }
]

export default challenges;