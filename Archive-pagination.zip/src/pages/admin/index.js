import React  , {useEffect} from "react";
import AdminPageSection from "../../components/AdminPage";
import { requireAuth } from "../../util/auth.js";

function AdminPage(props) {
  useEffect(()=>{
    props.setnav(true)
  },[])
  useEffect(() => {
    return () => {
      props.setnav(false)
    };
  }, []);
  return (
    <AdminPageSection
      color="white"
      size="medium"
      title="Admin PAge"
      subtitle=""
    />
  );
}

export default requireAuth(AdminPage);