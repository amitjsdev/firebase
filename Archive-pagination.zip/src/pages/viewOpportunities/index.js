import React from "react";
import ViewOpportunitiesSection from "../../components/ViewOpportunitiesSection";
import { requireAuth } from "../../util/auth.js";

function ViewOpportunities(props) {
  return (
    <ViewOpportunitiesSection
      color="white"
      size="medium"
      title="View Opportunities"
      subtitle=""
    />
  );
}

export default requireAuth(ViewOpportunities);
