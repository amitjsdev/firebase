import NewsletterSection from "./../components/NewsletterSection"
import PricingSection from "./../components/PricingSection";
import React from "react";

function PricingPage(props) {
  return [
    <PricingSection
      color="white"
      size="medium"
      backgroundImage=""
      backgroundImageOpacity={1}
      title="Pricing"
      subtitle="If you want to buy 5+ accounts, please contact us for special pricing"
    />,
    <NewsletterSection
      color="white"
      size="medium"
      backgroundImage=""
      backgroundImageOpacity={1}
      title="Free Leads"
      subtitle="Not ready for a paid plan? Sign up for our free newsletter to get our favorite innovation opportunities every other week!"
      buttonText="Sign Me Up!"
      inputPlaceholder="Enter Your Email"
      subscribedMessage="You're on the list!"
    />
  ];
}

export default PricingPage;
