import React, { useState } from "react";
import Navbar from "./../components/Navbar";
import IndexPage from "./index";
import AboutPage from "./about";
import FaqPage from "./faq";
import PricingPage from "./pricing";
import ContactPage from "./contact";
import DashboardPage from "./dashboard";
import Opportunities from "./opportunities";
import companies from "./companies";
import ViewOpportunities from "./viewOpportunities";
import ViewCompanies from "./ViewCompanies/index";
import AdminPage from "./admin";
import Saved from "./saved";
import Alerts from "./alerts";
import SettingsPage from "./settings";
import PurchasePage from "./purchase";
import AuthPage from "./auth";
import LeadsPage from "./leads";
import { Switch, Route, Router } from "./../util/router.js";
import FirebaseActionPage from "./firebase-action.js";
import NotFoundPage from "./not-found.js";
import Footer from "./../components/Footer";
import "./../util/analytics.js";
import { ProvideAuth, useAuth } from "./../util/auth.js";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import { configureStore } from "../redux/store";
import firebase from "./../util/firebase";
import "react-toastify/dist/ReactToastify.css";
import { connect } from "react-redux";
import logo from "../../src/assets/logo.png";

import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
const { store, persistor } = configureStore();

const Routes = (isAdmin, setnav) => {
  return (
    <Switch>
      <Route exact path="/" render={(props) => <IndexPage setnav={setnav} />} />

      <Route exact path="/about" component={AboutPage} />

      <Route exact path="/faq" component={FaqPage} />

      <Route exact path="/pricing" component={PricingPage} />

      <Route exact path="/contact" component={ContactPage} />

      <Route exact path="/dashboard" component={DashboardPage} />

      <Route exact path="/opportunities" component={Opportunities} />

      <Route exact path="/companies" component={companies} />
      <Route exact path="/companies/details" component={ViewCompanies} />
      <Route exact path="/opportunities/:id" component={ViewOpportunities} />

      {isAdmin && (
        <Route
          exact
          path="/admin"
          render={(props) => <AdminPage setnav={setnav} />}
        />
      )}

      <Route exact path="/saved" component={Saved} />

      <Route exact path="/alerts" component={Alerts} />

      <Route exact path="/leads" component={LeadsPage} />

      <Route exact path="/settings/:section" component={SettingsPage} />

      <Route exact path="/purchase/:plan" component={PurchasePage} />

      <Route
        exact
        path="/auth/:type"
        render={(props) => <AuthPage setnav={setnav} />}
      />

      <Route exact path="/firebase-action" component={FirebaseActionPage} />

      <Route component={NotFoundPage} />
    </Switch>
  );
};
function App(props) {
  const [navPos, setNavPos] = useState(false);
  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <ProvideAuth>
          <ToastContainer />
          <Router>
            <div className={navPos ? "" : "main-container sidebar-menu"}>
              <Navbar color="white" spaced={true} logo={logo} />
              <div className="main-content">
                {Routes(props && props.userData?.is_Admin, setNavPos)}
                <Footer
                  color="light"
                  size="large"
                  backgroundImage=""
                  backgroundImageOpacity={1}
                  copyright="© 2021 Open Innovation Leads"
                  logo={logo}
                />
              </div>
            </div>

            <ToastContainer />
          </Router>
        </ProvideAuth>
      </PersistGate>
    </Provider>
  );
}

const mapStateToProps = (state) => {
  return {
    userData: state.dbDataReducer.userData,
  };
};
export default connect(mapStateToProps)(App);

// export default App;
