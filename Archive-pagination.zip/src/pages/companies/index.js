import React from "react";
import CompaniesSection from "../../components/CompaniesSection";
import { requireAuth } from "../../util/auth.js";

function Companies(props) {
  return (
    <CompaniesSection
      color="white"
      size="medium"
      title="Companies"
      subtitle=""
    />
  );
}

export default requireAuth(Companies);
