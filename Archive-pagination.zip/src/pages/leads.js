import React, { Component } from "react";
import { requireAuth } from "../util/auth.js";
import challenges from "../data/challenges";
import LeadsTable from "../components/LeadsTable";

function LeadsPage(props) {
    return(
        <LeadsTable
            challengeList = {challenges}
        />
    );
}


export default requireAuth(LeadsPage);