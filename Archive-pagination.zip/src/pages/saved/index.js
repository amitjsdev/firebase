import React from "react";
import SavedSection from "../../components/SavedSection";
import { requireAuth } from "../../util/auth.js";

function Saved(props) {
  return <SavedSection color="white" size="medium" title="Saved" subtitle="" />;
}

export default requireAuth(Saved);
