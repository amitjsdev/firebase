import React from "react";
import AlertsSection from "../../components/AlertsSection";
import { requireAuth } from "../../util/auth.js";

function Alerts(props) {
  return <AlertsSection color="white" size="medium" title="Alerts" subtitle="" />;
}

export default requireAuth(Alerts);
