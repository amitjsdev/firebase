import ClientsSection from "./../components/ClientsSection";
import FeaturesSection from "./../components/FeaturesSection";
import HeroSection from "./../components/HeroSection";
import NewsletterSection from "./../components/NewsletterSection";
import React, { useEffect } from "react";
import TestimonialsSection from "./../components/TestimonialsSection";
import { useRouter } from "./../util/router.js";

function IndexPage(props) {
  const router = useRouter();
  useEffect(() => {
    props.setnav(true);
  }, []);
  useEffect(() => {
    return () => {
      props.setnav(false);
    };
  }, []);
  return (
    <>
      <HeroSection
        color="white"
        size="medium"
        backgroundImage=""
        backgroundImageOpacity={1}
        title="Use Open Innovation To Find Your Next Customer"
        subtitle="The Easiest Way To Surface Relevant Open Innovation Opportunities For Your Business"
        buttonText="Get Started"
        image="https://uploads.divjoy.com/undraw-japan_ubgk.svg"
        buttonOnClick={() => {
          // Navigate to pricing page
          router.push("/pricing");
        }}
      />

      <FeaturesSection
        color="white"
        size="medium"
        backgroundImage=""
        backgroundImageOpacity={1}
        title="Features"
        subtitle=""
      />
      <ClientsSection
        color="light"
        size="normal"
        backgroundImage=""
        backgroundImageOpacity={1}
        title="Instantly Access Innovation Opportunities From These Companies and More!"
        subtitle=""
      />
      {/* <TestimonialsSection
        color="light"
        size="medium"
        backgroundImage=""
        backgroundImageOpacity={1}
        title="Here's what people are saying"
        subtitle=""
      />*/}
      <NewsletterSection
        color="white"
        size="medium"
        backgroundImage=""
        backgroundImageOpacity={1}
        title="Free Leads"
        subtitle="Not ready for a paid plan? Sign up for our free newsletter to get our favorite innovation opportunities every other week!"
        buttonText="Sign Me Up"
        inputPlaceholder="Enter your email"
        subscribedMessage="You are now subscribed!"
      />
    </>
  );
}

export default IndexPage;
