import React from "react";
import ViewCompaniesSection from "../../components/ViewCompaniesSection";
import { requireAuth } from "../../util/auth.js";

function ViewOpportunities(props) {
  return (
    <ViewCompaniesSection
      color="white"
      size="medium"
      title="View Opportunities"
      subtitle=""
    />
  );
}

export default requireAuth(ViewOpportunities);
