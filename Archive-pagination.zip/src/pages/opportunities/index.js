import React from "react";
import OpportunitiesSection from "../../components/OpportunitiesSection";
import { requireAuth } from "../../util/auth.js";

function Opportunities(props) {
  return (
    <OpportunitiesSection
      color="white"
      size="medium"
      title="Opportunities"
      subtitle=""
    />
  );
}

export default requireAuth(Opportunities);
