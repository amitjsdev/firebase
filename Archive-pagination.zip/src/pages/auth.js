import React , {useEffect} from "react";
import AuthSection from "./../components/AuthSection";
import { useRouter } from "./../util/router.js";

function AuthPage(props) {
  const router = useRouter();
  useEffect(()=>{
    props.setnav(true)
  },[])
  useEffect(() => {
    return () => {
      props.setnav(false)
    };
  }, []);
  return (
    <AuthSection
      color="white"
      size="large"
      backgroundImage=""
      backgroundImageOpacity={1}
      type={router.query.type}
      afterAuthPath={router.query.next || "/opportunities"}
    />
  );
}

export default AuthPage;
