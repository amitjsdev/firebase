import React from "react";
import Section from "./Section";
import SectionHeader from "./SectionHeader";
import "./ClientsSection.scss";
import pfizer from "../assets/pfizer.svg";
import nasa from "../assets/nasa.svg";
import pg from "../assets/pg.svg";
import ge from "../assets/ge.svg";
import ClientLogo from "../assets/home/client-log.png";

function ClientsSection(props) {
  const items = [
    {
      name: "Pfizer",
      image: pfizer,
      width: "150px",
    },
    {
      name: "NASA",
      image: nasa,
      width: "135px",
    },
    {
      name: "P&G",
      image: pg,
      width: "110px",
    },
    {
      name: "General Electric",
      image: ge,
      width: "110px",
    },
  ];

  return (
    <Section
      color={props.color}
      size={props.size}
      backgroundImage={props.backgroundImage}
      backgroundImageOpacity={props.backgroundImageOpacity}
      className="ClientsSection__wrapper"
    >
      <div className="container">
        <div className="ClientsSection__content">
          <div className="column">
            <SectionHeader
              title={props.title}
              subtitle={props.subtitle}
              size={3}
              spaced={true}
            />
          </div>
          <div className="column">
            <div className="columns is-centered is-multiline">
              <div className="ClientsSection__logo">
                <img src={ClientLogo} alt="ClientLogo" />
              </div>
              {/* {items.map((item, index) => (
                <div className="column is-narrow " key={index}>
                  <div className="ClientsSection__logo">
                
                    <img src={item.image} width={item.width} alt={item.name} />
                  </div>
                </div>
              ))} */}
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}

export default ClientsSection;
