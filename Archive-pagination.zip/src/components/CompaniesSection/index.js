import React, { useEffect, useState, useRef } from "react";
import Section from "../Section";
import SectionHeader from "../SectionHeader";
import { useRouter } from "../../util/router.js";
import { useAuth } from "../../util/auth.js";
import Challenges from "../CompaniesChallenges";
import {
  getAllCompanies,
  getCompaniesByName,
  getNumberOfCompaniees
} from "../../util/db";
import Select from "react-select";
import PageLoader from "../PageLoader";
import FormAlert from "../../components/FormAlert";
import { asyncForEach } from "../../util/util";
import Pagination from "../Pagination";
import { AsyncIterator } from "analytics/lib/analytics.cjs";

let InitialOpportunites = [];
let initialCurrentOpps = [];
function CompaniesSection(props) {
  const [paginationData, setPaginationData] = useState(false);
  const [totalCount, setTotalCount] = useState();
  const [oppSortByNo, setOppSortByNo] = useState([]);
  const [oppSortByTime, setOppSortByTime] = useState([]);

  const [oppSortByNoPagination, setOppSortByNoPagination] = useState([]);
  const [oppSortByTimePagination, setOppSortByTimePagination] = useState([]);

  const [loaderDiv, setLoaderDiv] = useState(false);
  const [apiLoader, setApiLoader] = useState(false);
  const [isOppLoading, setIsOppLoading] = useState(false);
  const companiesPerpage = 1;
  const toggleBit = window.location.search;
  let params = new URLSearchParams(toggleBit);
  let value = params.get("pageBit");
  let page = parseInt(params.get("pN"));
  const [toggleCurrent, setToggleCurrent] = useState(
    value == "false" ? false : true
  );
  const [showAlert, setShowAlert] = useState(false);
  const [perpage, setperpage] = useState(5);
  const [opportunities, setOpportunities] = useState([]);
  // const catVal = JSON.parse(localStorage.getItem("catsInSelect"));
  const [catsInSelect, setCatsInSelect] = useState([]);
  const [searchValue, setSearchValue] = useState("");
  const [activePage, setActivePage] = useState(page ? page : 1);
  useEffect(() => {
    setIsOppLoading(true);
    getCompanies(perpage);
    getNumberOfCompany()
  }, []);

  const getNumberOfCompany = async () => {
    let data = await getNumberOfCompaniees();
    setTotalCount(data);
  };

  const getCompanies = (limit) => {
    let arrayByNo = [];
    let arrayByTime = [];
    getAllCompanies(limit, "noOfOpportunities")
      .then((results) => {
        results.docs.forEach((doc) => {
          arrayByNo.push(doc.data())
        })
        setOppSortByNo(arrayByNo)
        setIsOppLoading(false);
        setLoaderDiv(false);

        setApiLoader(false);
      })
    getAllCompanies(limit, "lastOpportunityUpdated")
      .then((results) => {
        results.docs.forEach((doc) => {
          arrayByTime.push(doc.data())
        })
        setOppSortByTime(arrayByTime)
        setIsOppLoading(false);
        setLoaderDiv(false);

        setApiLoader(false);
      });
  };

  const handleSearch = async () => {
    if (searchValue) {
      const data = await getCompaniesByName(searchValue);
      const array = []
      data.docs.forEach((doc) => {
        array.push(doc.data())
      })
      setOppSortByTime(array);
      setOppSortByNo(array);
    } else {
      getCompanies(perpage);
    }

  }
  let active = useRef(page ? page : 1);
  const handlePagination = async (e) => {
    setActivePage(e);
    getAllOpportunitiesWithFilter(e);
  };


  const seeAllCompanies = (e) => {
    setPaginationData(true);
    getAllOpportunitiesWithFilter(e);

  }

  const getAllOpportunitiesWithFilter = async (active) => {
    console.log("getAllCompanies", active)
    let limit = 'all';
    let arrayByNo = [];
    let arrayByTime = [];
    getAllCompanies(limit, "noOfOpportunities", active)
      .then((results) => {
        results.docs.forEach((doc) => {
          arrayByNo.push(doc.data())
        })
        console.log("arrayByNo",arrayByNo)
        setOppSortByNoPagination(arrayByNo)
        setIsOppLoading(false);
        setLoaderDiv(false);

        setApiLoader(false);
      })
    getAllCompanies(limit, "lastOpportunityUpdated", active)
      .then((results) => {
        results.docs.forEach((doc) => {
          arrayByTime.push(doc.data())
        })
        console.log("arrayByTime",arrayByTime)
        setOppSortByTimePagination(arrayByTime)
        setIsOppLoading(false);
        setLoaderDiv(false);

        setApiLoader(false);
      });
  };

  return (
    <Section color={props.color} size={props.size}>
      {showAlert && (
        <FormAlert
          type="success"
          message="You can select maximum 10 categories"
          style={{ maxWidth: "450px" }}
        />
      )}
      <div className="companies-wrapper">
        <div className="companies-header">
          <SectionHeader
            title={props.title}
            subtitle={props.subtitle}
            size={3}
            spaced={true}
            className="has-text-centered desktop-view-header"
          />
          <div className="companies-search">
            <input
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder="Search.."
            />
            <button onClick={handleSearch}>
              <i className="fas fa-chevron-down" />
            </button>
          </div>
        </div>
        <div className="companies-content">
          {apiLoader ? (
            <PageLoader />
          ) : (
            <>
              <Challenges
                content={oppSortByTime}
                title={"With New Opportunies"}
              />
              <Challenges
                content={oppSortByNo}
                title={"By Number of Opportunies"}
              />
            </>
          )}
          <button className="see-all-btn" onClick={() => seeAllCompanies(1)} >see all companies</button>
          {paginationData ? (
            <>
              {oppSortByNoPagination && oppSortByNoPagination.length > 0 ?
                <Challenges
                  content={oppSortByNoPagination}
                  title={"With New Opportunies"}
                />
                :
                null
              }

              {oppSortByTimePagination && oppSortByTimePagination.length > 0 ?
                <Challenges
                  content={oppSortByTimePagination}
                  title={"By Number of Opportunies"}
                />
                :
                null
              }

              <Pagination
                perpage={companiesPerpage}
                totalCount={totalCount}
                handlePagination={handlePagination}
                activePage={activePage} />
            </>
          ) : (
            null

          )
          }

        </div>
        {!apiLoader && loaderDiv ? (
          <PageLoader
            style={{
              height: "100px",
            }}
          />
        ) : null}
      </div>
    </Section>
  );
}
export default CompaniesSection;
