import React from "react";
import { Link } from "./../util/router.js";
import "./SettingsNav.scss";

function SettingsNav(props) {
  return (
    <div
      className={
        "SettingsSection__container container SettingsNav tabs is-toggle is-centered" +
        (props.parentColor === "white" ? " active-button" : "")
      }
    >
      <ul>
        <li
          className={"SettingsNav border" + (props.activeKey === "general" ? " gradient active-button" : "")}
        >
          <Link className="SettingsNav active-button" to="/settings/general">General</Link>
        </li>
        <li
          className={"SettingsNav border" + (props.activeKey === "password" ? " gradient SettingsNav active-button" : "")}
        >
          <Link to="/settings/password">Password</Link>
        </li>
        <li
          className={"SettingsNav border" + (props.activeKey === "billing" ? " gradient SettingsNav active-button" : "")}
        >
          <Link to="/settings/billing">Billing</Link>
        </li>
      </ul>
    </div>
  );
}

export default SettingsNav;
