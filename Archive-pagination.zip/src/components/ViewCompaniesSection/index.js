import React, { useState, useEffect } from "react";
import Section from "../Section";
import { getOpportunitiesById, getKeyPeopleById } from "../../util/db.js";
import moment from "moment";
import FormAlert from "../../components/FormAlert";
import { useAuth } from "../../util/auth.js";
import { withRouter } from "react-router-dom";
import PrizeMoney from "../../assets/opportunity/price-money.png";
import Deadlines from "../../assets/opportunity/deadlines.png";
import Category from "../../assets/opportunity/category.svg";
import Opportunities from "../../assets/companies/opportunities.svg";
import KeyPeople from "../../assets/companies/keyPeople.png";

function ViewCompaniesSection(props) {
  const [CompanyData, setCompanyData] = useState();
  const [opportunities, setOpportunities] = useState([]);
  const [keyPeople, setKeyPeople] = useState([]);

  const getCompanyData = () => {
    setCompanyData(props.location.state.data);
  };
 
  const getKeyPeoples = () =>{
    const promiseArr = []
    const getPeoplePromise = (item) =>{
      return new Promise((resolve , reject)=>{
        getKeyPeopleById(item).then(res =>{
          if(res){
            promiseArr.push(res.data())
            resolve(res.data())
          }
        })
       
      })
    }
   props.location.state.data.companyKeyPeople.forEach((item)=>{
     promiseArr.push(getPeoplePromise(item))  
   })
   Promise.all(promiseArr).then((res) => {
    setKeyPeople(res)
   })
  }

  const getAllOpportunities = () => {
    const promiseArr = [];
    //let opportunityId = [];
    const getOppPromise = (item) => {
      
      //opportunityId.push(item);
      return new Promise((resolve) => {
        getOpportunitiesById(item).then((res) => {
          if (res) {
            promiseArr.push({res,opportunityId:item});
            resolve({res,opportunityId:item});
          }
        });
      });
    };
    props.location.state.data.companyOpportunities.forEach((item) => {
      promiseArr.push(getOppPromise(item));
    });
    Promise.all(promiseArr).then((res) => {
      setOpportunities(res);
    });
  };



  const handleClick = (opportunityId) => {

    if (typeof opportunityId != "undefined") {
      props.history.push({
        pathname: "/opportunities/" + opportunityId,
        search: `?pageBit=false&pN=company`,
      });
    }
  };

  useEffect(() => {
    getCompanyData();
    getKeyPeoples();
    getAllOpportunities();
  }, []);

  return (
    <Section color={props.color} size={props.size}>
      <div className="companies-wrapper">
        <div className="companies-content">
          <div className="companies-cards">
            {CompanyData && (
              <>
                <div className="card">
                  <div className="card-content py-2 mb-4">
                    <p className="details">
                      <b>Category:</b>
                      {CompanyData.companyCategory}
                    </p>
                  </div>
                </div>
                <div className="card">
                  <div className="card-content py-2 mb-4">
                    <p className="details">
                      <b>Description:</b>
                      {CompanyData.companyDescription}
                    </p>
                  </div>
                </div>
                <div className="card">
                  <div className="card-content py-2 mb-4">
                    {" "}
                    <p className="details">
                      <b>Company Name:</b>
                      {CompanyData.companyName}
                    </p>
                  </div>
                </div>
                <div className="card">
                  <div className="card-content py-2 mb-4">
                    {" "}
                    <p className="details">
                      <b>Website:</b>
                      {CompanyData.companyURL}
                    </p>
                  </div>
                </div>
              </>
            )}
            <h3 className="title">Opportunities:</h3>
            <div className="card">
              <div className="card-content py-5">
                <div className="content">
                  {opportunities &&
                    opportunities.map((item) => (
                    
                      <>
                        <div className="name oppo-name">
                          <h4 onClick={()=>{handleClick(item.opportunityId)}}>
                            <img src={Opportunities} alt="Opportunities" />
                            {item.res.opportunityName}
                          </h4>
                        </div>
                      </>
                    ))}
                </div>
              </div>
            </div>

            <h3 className="title">Key People:</h3>
            <div className="card">
              <div className="card-content py-5">
                <div className="content">
                  {keyPeople &&
                    keyPeople.map((item) => (
                      <>
                        <div className="name oppo-name">
                          <h4>
                            <img src={KeyPeople} alt="KeyPeople" />
                            {item.personName}
                          </h4>
                        </div>
                      </>
                    ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}
export default withRouter(ViewCompaniesSection);
