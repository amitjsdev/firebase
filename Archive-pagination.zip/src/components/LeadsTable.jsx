import { wrap } from 'analytics/lib/analytics.cjs';
import React, { Component } from 'react';

import LeadsTableRow from '../components/LeadsTableRow';


class LeadsTable extends Component {
    constructor (props) {
        super(props)

        this.state = {
            challengeList: props.challengeList,
            displayedChallenges: [],
            allChallenges: [],
            totalTags: [],
            uniqueTags: []
        }

    }

    componentDidMount() { //displays the full opportunity list
        let challenges = []
        let challengeList = this.state.challengeList
        let totalTags = []
        let uniqueTags = []
        for (var i=0; i < challengeList.length; i++) {
            const challenge = challengeList[i];
            const tags = challenge["tags"]
            const url = challenge["challengeURL"]
            totalTags.push(tags)
            challenges.push(
                <LeadsTableRow companyName={challenge["companyName"]} challengeName={challenge["challengeName"]} cashPrize={challenge["challengeCashPrize"]} tags={tags} url={url} />
            )
        }
        totalTags.forEach(
            tags => {
                tags.forEach(
                    tag => {
                        if (uniqueTags.indexOf(tag) === -1) {
                            uniqueTags.push(tag)
                        }
                    }
                )
            }
        )
        uniqueTags.push('all')
        uniqueTags.forEach(
            (tag, index) => {
                uniqueTags[index] = <button onClick={() => this.filterByTag(tag)} class="button is-link is-medium" style={{margin: 5}}>{tag}</button>
            }
        )

        this.setState({
            displayedChallenges: challenges,
            allChallenges: challenges,
            totalTags: totalTags,
            uniqueTags: uniqueTags
        })
    }


    filterByTag = (tag) => {
        console.log("this is the tag you clicked")
        console.log(tag)
        let challengeList = this.state.challengeList
        let allChallenges = this.state.allChallenges
        let challenges = []
        for (var i=0; i < challengeList.length; i++) {
            const challenge = challengeList[i];
            const tags = challenge["tags"]
            for (var j=0; j < tags.length; j++) {
                if (tag === tags[j]) {
                    challenges.push(
                        <LeadsTableRow companyName={challenge["companyName"]} challengeName={challenge["challengeName"]} cashPrize={challenge["challengeCashPrize"]} tags={tags} />
                    )
                }
            }
        }
        if (tag === "all") {
            this.setState({displayedChallenges: allChallenges})
        } else {
            this.setState({displayedChallenges: challenges})
        }
    }

    render() {
        return [
            <h2 class="title has-text-centered">Current Innovation Challenges</h2>,
            <div class="block" style={{marginLeft: 15}}>{this.state.uniqueTags}</div>,
            <div class="tile is-ancestor">
                <div class="tile is-parent" style={{display: "inline-block"}}>
                    { this.state.displayedChallenges }
                </div>
             </div>
        ]
    }
}

export default LeadsTable;