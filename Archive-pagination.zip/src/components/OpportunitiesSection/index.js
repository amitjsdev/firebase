import React, { useEffect, useState, useRef } from "react";
import Section from "../Section";
import SectionHeader from "../SectionHeader";
import { useRouter } from "../../util/router.js";
import { useAuth } from "../../util/auth.js";
import Challenges from "../Challanges";
import {
  getAllCategories,
  getAllOpportunities,
  getFilteredOpportunities,
  getCurrentOpportunities,
  getCurrrentOppsWithFilter,
  getLimitedOpportunities,
} from "../../util/db.js";
import Select from "react-select";
import PageLoader from "../PageLoader";
import FormAlert from "../../components/FormAlert";
import { asyncForEach } from "../../util/util";
import Pagination from "../Pagination";
import { AsyncIterator } from "analytics/lib/analytics.cjs";

let InitialOpportunites = [];
let initialCurrentOpps = [];
function OpportunitiesSection(props) {
  const listElement = useRef();
  const [totalOpp, setTotalOpp] = useState(1);
  const [allCategories, setAllCategories] = useState([]);
  const [allOpportunities, setAllOpportunities] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [totalCount, setTotalCount] = useState();
  const [isOppLoading, setIsOppLoading] = useState(false);
  const [loaderDiv, setLoaderDiv] = useState(false);
  const [apiLoader, setApiLoader] = useState(false);
  const [previousScroll, setPreviousScroll] = useState(0);
  const toggleBit = window.location.search;
  let params = new URLSearchParams(toggleBit);
  let value = params.get("pageBit");
  let page = parseInt(params.get("pN"));

  const [toggleCurrent, setToggleCurrent] = useState(
    value == "false" ? false : true
  );
  const [val, setval] = useState(false);
  const tab = useRef(true);

  const [showAlert, setShowAlert] = useState(false);
  const [activePage, setActivePage] = useState(page ? page : 1);
  const [perpage, setperpage] = useState(16);
  const [lastvisible, setlastvisible] = useState();
  const [prevfirstvisible, setPrevfirstvisible] = useState();
  const secondCurrent = useRef();
  const cardsRef = useRef(null);
  // const catVal = JSON.parse(localStorage.getItem("catsInSelect"));
  const [catsInSelect, setCatsInSelect] = useState([]);

  console.log("valuevaluevalue", value, page);

  let active = useRef(page ? page : 1);
  console.log("toggleVal", props);
  const [sortBy, setSortBy] = useState([
    { sortingBy: "opportunityPrizeMoney", value: 0 },
    { sortingBy: "opportunityDeadline", value: 0 },
  ]);

  let bottomBoundaryRef = useRef(null);
  const timeout = useRef(null);
  const allOpportunitiesLocal = useRef([]);

  const handleSetOpportunities = (data) => {
    allOpportunitiesLocal.current = data;
    if (selectedCategories && selectedCategories.length > 0) {
      setAllOpportunities(selectedCategories);
      //  filterOpportunities(selectedCategories,8)
    } else {
      setAllOpportunities(data);
    }
  };

  // useEffect(()=>{
  //   setIsOppLoading(true);
  //   // setApiLoader(true)
  // },[apiLoader])

  useEffect(() => {
    setIsOppLoading(true);

    getOpportunities(true, toggleCurrent);
  }, []);

  const sortData = (allOpportunities, key, isAscending) => {
    var number = [];
    var char = [];
    allOpportunities.forEach((a) => {
      if (typeof a[key] == "number") number.push(a);
      else char.push(a);
    });

    let sorted = number
      .sort((a, b) => {
        if (isAscending) {
          return a[key] - b[key];
        } else {
          return b[key] - a[key];
        }
      })
      .concat(char.sort());

    setAllOpportunities(sorted);
    console.log('sorted',sorted);
  };

  const onSort = (key) => {
    const indexOfInitialSort = sortBy.findIndex((el) => {
      return el.sortingBy === key;
    });
    const initialSort = sortBy[indexOfInitialSort];
    let newArray = sortBy.slice();
    if (initialSort.value === 0) {
      let newSortObject = { ...initialSort, value: 1 };
      newArray[indexOfInitialSort] = newSortObject;
      newArray.map((el, idx) => {
        if (idx !== indexOfInitialSort) {
          el.value = 0;
        }
      });
      sortData(allOpportunities, key, true);
      setSortBy(newArray);
      allOpportunitiesLocal.current = allOpportunities;
    }
    if (initialSort.value === 1) {
      let newSortObject = { ...initialSort, value: 2 };
      newArray[indexOfInitialSort] = newSortObject;
      newArray.map((el, idx) => {
        if (idx !== indexOfInitialSort) {
          el.value = 0;
        }
      });
      sortData(allOpportunities, key, false);
      setSortBy(newArray);
      allOpportunitiesLocal.current = allOpportunities;
    }
    if (initialSort.value === 2) {
      let newSortObject = { ...initialSort, value: 0 };
      newArray[indexOfInitialSort] = newSortObject;
      newArray.map((el, idx) => {
        if (idx !== indexOfInitialSort) {
          el.value = 0;
        }
      });
      setSortBy(newArray);
      allOpportunitiesLocal.current = InitialOpportunites;
      if (toggleCurrent) {
        setAllOpportunities(InitialOpportunites);
        console.log('onSort',InitialOpportunites);
      } else {
        console.log('onSort',initialCurrentOpps);
        setAllOpportunities(initialCurrentOpps);
      }
    }
  };

  const getCurrentFilteredOpps = (cats, limit, resetlastVisible) => {
    console.log(limit, resetlastVisible);
    setLoaderDiv(true);
    const arr = [];
    getCurrrentOppsWithFilter(
      cats,
      limit,
      resetlastVisible,
      active.current
    ).then((results) => {
      console.log("results1", results);
      setLoaderDiv(false);

      setIsOppLoading(false);
      if (results) {
        if (results.resultlength) {
          setTotalOpp(results.resultlength);
        }
        results.data &&
          results.data.docs.forEach(function (doc) {
            let data = doc.data();
            data = { ...data, opportunityId: doc.id };
            arr.push(data);
          });
        setTotalCount(results.totaldata);
        setAllOpportunities(arr);
        setApiLoader(false);
      } else {
        setAllOpportunities([]);
        setApiLoader(false);
      }
    });
  };

  const fetchOpportunitiesData = (results) => {
    let arr = [];

    if (results) {
      if (results.resultlength) {
        setTotalOpp(results.resultlength);
      }
      results.data.forEach(function (doc) {
        let data = doc.data();
        data = { ...data, opportunityId: doc.id };
        arr.push(data);
      });
      console.log("arrarrop",arr)  
      InitialOpportunites = arr.slice();
      setTotalCount(results.totaldata);
      setAllOpportunities(arr);
    }
  };

  const getOpportunities = (
    resetlastVisible,
    current,
    categories,
    limit, //perpage
    totalOppsVal,
    resetOpps //true
  ) => {
    console.log("categories65", categories, current);
    localStorage.setItem("toggleVal", current, active.current);
    params.set("pN", active.current);
    params.set("pageBit", current);
    window.history.replaceState(null, null, "?" + params.toString());
    setActivePage(active.current);
    setApiLoader(true);
    secondCurrent.current = false;
    let maxLimit = categories && categories.length > 0 ? 16 : null;
    const cats = categories && categories.length > 0 ? categories : [];
    timeout.current = null;
    let arr = [];
    const totalOpportunities = totalOppsVal ? totalOppsVal : totalOpp;
    console.log(
      "totalOpportunities",
      totalOpportunities,
      categories,
      catsInSelect,
      current
    );

    // if (totalOpportunities === arr.length) {
    //   setLoaderDiv(false);
    //   // no more data
    // } else

    if (current && cats.length === 0) {
      if (catsInSelect && catsInSelect.length > 0) {
        console.log("handlechangecall1", catsInSelect, "catValcatVal=");
        handleChange(catsInSelect);
        return;
      }
      // setLoaderDiv(true)
      setActivePage(1);
      active.current = 1;
      secondCurrent.current = true;
      getAllOpportunities(perpage, resetlastVisible, active.current)
        .then((results) => {
          console.log("results", results);
          setIsOppLoading(false);
          setLoaderDiv(false);

          fetchOpportunitiesData(results);
          setApiLoader(false);
        })
        .catch((err) => {
          setIsOppLoading(false);
          setLoaderDiv(false);
          console.log("errerr", err);
        });
    }
    if (!current && cats.length === 0) {
      console.log("fetchCurrentOpportunities");

      fetchCurrentOpportunities(resetlastVisible, maxLimit, resetOpps);
    }
    if (!current && cats.length > 0) {
      console.log("1111", cats);
      filterOpportunities(cats, maxLimit, resetlastVisible);
    }
    if (current && cats.length > 0) {
      console.log("22222", cats);
      getCurrentFilteredOpps(cats, perpage, resetlastVisible);
    }
  };
  const filterOpportunities = async (categories, limit, resetlastVisible) => {
    const arr = [];
    // categories && categories.length &&
    // setApiLoader(false)
    console.log("categoriescategoriescategories", categories);
    const results = await getFilteredOpportunities(
      categories,
      limit,
      resetlastVisible,
      active.current
    );
    console.log("results66789", results);
    if (results) {
      setLoaderDiv(false);
      setIsOppLoading(false);
      if (results) {
        if (results.resultlength) {
          setTotalOpp(results.resultlength);
        }
        results.data &&
          results.data.docs.forEach(function (doc) {
            let data = doc.data();
            data = { ...data, opportunityId: doc.id };
            arr.push(data);
          });
        allOpportunitiesLocal.current = arr;
        setTotalCount(results.totaldata);
        setAllOpportunities(arr);
        setApiLoader(false);
      } else {
        allOpportunitiesLocal.current = [];
        setApiLoader(false);
        setAllOpportunities([]);
      }
    }
  };

  const getCategories = () => {
    const arr = allCategories.slice();
    getAllCategories().then((results) => {
      if (results) {
        results.forEach(function (doc) {
          const data = doc.data();
          let option = { value: doc.id, label: data.name };
          arr.push(option);
        });
        setAllCategories(arr);
      }
    });
  };

  useEffect(() => {
    getCategories();
  }, []);

  const handleChange = (val, getVal) => {
    console.log("valval=", val);
    if (!!getVal) {
      active.current = 1;
      setActivePage(1);
      params.set("pN", active.current);
      window.history.replaceState(null, null, "?" + params.toString());
    }

    const newValue = [];
    if (val) {
      newValue.push(val);
    } else {
      newValue = null;
    }
    console.log("newvalue", newValue);
    setApiLoader(true);
    if (newValue == null) {
      console.log("taabbb", tab);
      if (tab.current == false) {
        setSelectedCategories([]);
        setCatsInSelect([]);
        getAllOpportunities(perpage, "", active.current).then((results) => {
          console.log("results", results);
          setIsOppLoading(false);
          setLoaderDiv(false);
          setApiLoader(false);

          fetchOpportunitiesData(results);
        });

        // localStorage.setItem("catsInSelect", JSON.stringify([]));
      } else {
        setSelectedCategories([]);
        setCatsInSelect([]);
        setApiLoader(false);
        getAllOpportunitiesWithFilter(1);
        // localStorage.setItem("catsInSelect", JSON.stringify([]));
      }
    } else if (newValue && newValue.length >= 10) {
      setShowAlert(true);
    } else {
      setShowAlert(false);
      console.log("newValuenewValuenewValue=", newValue);
      let categoryIds = (newValue && newValue.map((el) => el.value)) || [];
      const resetTotalOpps = categoryIds.length > 0 ? totalOpp : 1;
      setSelectedCategories(categoryIds);
      const newarray = newValue && newValue.slice();
      setCatsInSelect(newarray);
      getOpportunities(
        true,
        toggleCurrent,
        categoryIds,
        perpage,
        "",
        resetTotalOpps
      );

      // localStorage.setItem("catsInSelect", JSON.stringify(newarray));
    }
  };
  const priceMoneySortIcon = sortBy.find((el) => {
    return el.sortingBy === "opportunityPrizeMoney";
  });
  const deadlineSortIcon = sortBy.find((el) => {
    return el.sortingBy === "opportunityDeadline";
  });
  const handleScroll = (e) => {
    console.log(e);
    // setLoaderDiv(false)
    const target = listElement.current;
    if (isOppLoading) {
      return;
    }
    if (!!target) {
      if (
        previousScroll < target.scrollTop &&
        target.scrollTop + target.clientHeight >= target.scrollHeight - 10
      ) {
        if (!isOppLoading) {
          setIsOppLoading(true);
          getOpportunities(false, toggleCurrent, selectedCategories, perpage);
        }
      }
      setPreviousScroll(target.scrollTop);
    }
  };

  const handlePagination = async (e) => {
    params.set("pN", e);
    window.history.replaceState(null, null, "?" + params.toString());
    active.current = e;
    setApiLoader(true);
    setActivePage(e);

    if (catsInSelect?.length > 0) {
      handleChange(catsInSelect[0]);
      setApiLoader(false);
      return;
    } else if (secondCurrent.current) {
      const fetchVal = await getAllOpportunities(perpage, "", active.current);
      fetchOpportunitiesData(fetchVal);
      setApiLoader(false);
      return;
    } else {
      getAllOpportunitiesWithFilter(e);

      return;
    }
  };
  const getAllOpportunitiesWithFilter = async (active) => {
    console.log("getAllOpportunitiesWithFilter");
    setApiLoader(true);
    try {
      console.log("12dfgdfgdf");
      setActivePage(active);
      var fetchOpp = await getLimitedOpportunities(perpage, active);
      setAllOpportunities(fetchOpp.data);
      setTotalCount(fetchOpp.totaldata);
      setApiLoader(false);
    } catch (e) {
      setApiLoader(false);
    }
  };
  console.log("indddd", tab);
  const fetchCurrentOpportunities = async (
    resetlastVisible,
    limit,
    resetOpps
  ) => {
    // const arr = resetOpps ? [] : allOpportunities.slice();
    if (catsInSelect && catsInSelect.length > 0) {
      console.log("handlechange3");
      handleChange(catsInSelect[0]);
      return;
    }
    const arr = [];
    setLoaderDiv(true);
    getCurrentOpportunities(resetlastVisible, limit, active.current).then(
      (results) => {
        setLoaderDiv(false);

        setIsOppLoading(false);
        if (results) {
          if (results.resultlength) {
            setTotalOpp(results.resultlength);
          }
          results.data.docs.forEach(function (doc) {
            let data = doc.data();
            data = { ...data, opportunityId: doc.id };
            arr.push(data);
          });

          initialCurrentOpps = arr;
          console.log(results);
          ///neww
          setTotalCount(results.totaldata);
          //new above
          setAllOpportunities(arr);
          console.log("getCurrentOpportunities",arr);
          setApiLoader(false);
        } else {
          setAllOpportunities([]);
        }
      }
    );
  };

  const CurrentAllButton = () => (
    <div className="current-buttons">
      <button
        className={`button ${toggleCurrent ? "active" : ""}`}
        onClick={() => {
          tab.current = !tab.current;
          setApiLoader(true);
          active.current = 1;
          getOpportunities(
            true,
            !toggleCurrent,
            selectedCategories,
            perpage,
            1,
            true
          );
          setToggleCurrent(!toggleCurrent);
        }}
      >
        Current
      </button>
      <button
        className={`button ml-2 ${!toggleCurrent ? "active" : ""}`}
        onClick={() => {
          tab.current = !tab.current;
          setApiLoader(true);
          active.current = 1;
          getOpportunities(true, !toggleCurrent, selectedCategories, null, 1);
          setToggleCurrent(!toggleCurrent);
        }}
      >
        All
      </button>
    </div>
  );

  return (
    <Section color={props.color} size={props.size}>
      {/* <div className="container"> */}
      <SectionHeader
        title={props.title}
        subtitle={props.subtitle}
        size={3}
        spaced={true}
        className="has-text-centered mobile-view-header "
      />
      {showAlert && (
        <FormAlert
          type="success"
          message="You can select maximum 10 categories"
          style={{ maxWidth: "450px" }}
        />
      )}
      <div className="opportunities-wrapper">
        <div class="buttons mb-0">
          {/* <button class="button is-info is-light">Category</button> */}
          <div className="cat-search">
            <Select
              // isMulti
              value={catsInSelect}
              options={allCategories}
              onChange={(e) => handleChange(e, true)}
            />
          </div>
          {/* sortingIcon.value */}
          <div className="current-mobile-view">
            <CurrentAllButton />
          </div>
          <SectionHeader
            title={props.title}
            subtitle={props.subtitle}
            size={3}
            spaced={true}
            className="has-text-centered desktop-view-header"
          />
          <div className="sort-btn-wrapper">
            <button
              class="button sort-btn"
              onClick={() => onSort("opportunityPrizeMoney")}
            >
              Prize Money
              {priceMoneySortIcon.value === 0 ? (
                <span>
                  <i className="fas fa-chevron-up" />
                  <i className="fas fa-chevron-down" />
                </span>
              ) : priceMoneySortIcon.value === 1 ? (
                <span>
                  {" "}
                  <i className="fas fa-chevron-down" />
                </span>
              ) : (
                <span>
                  <i className="fas fa-chevron-up" />
                </span>
              )}
            </button>
            <button
              class="button sort-btn"
              onClick={() => onSort("opportunityDeadline")}
            >
              Deadline
              {deadlineSortIcon.value === 0 ? (
                <span>
                  <i className="fas fa-chevron-up" />
                  <i className="fas fa-chevron-down" />
                </span>
              ) : deadlineSortIcon.value === 1 ? (
                <span>
                  {" "}
                  <i className="fas fa-chevron-down" />
                </span>
              ) : (
                <span>
                  <i className="fas fa-chevron-up" />
                </span>
              )}
            </button>

            {/* <button class="button is-info is-light ml-2" onClick ={()=>{setaccrendingDeadline(!accrendingDeadline)}}>Deadline <i className={`fas ml-2 ${accrendingDeadline ? " fa-chevron-down" : "fa-chevron-up" }  `} /></button> */}
          </div>
          {/* </div> */}
        </div>
        <div className="current-desktop-view">
          <div className="mb-3">
            <div className="py-3">
              <CurrentAllButton />
            </div>
          </div>
        </div>

        {/* <div
          onScroll={handleScroll}
          ref={listElement}
          className="card-scroll-view"
        >
           */}
        {apiLoader ? (
          <PageLoader />
        ) : (
          <Challenges
            content={allOpportunities}
            catsInSelect={catsInSelect}
            toggleCurrent={toggleCurrent}
            active={active.current}
          />
        )}
        {!allOpportunities.length && !loaderDiv && (
          <div className="text-center"> Not Found</div>
        )}
        {/* </div> */}
        {!apiLoader && loaderDiv ? (
          <PageLoader
            style={{
              height: "100px",
            }}
          />
        ) : null}
      </div>
      <Pagination
        perpage={perpage}
        totalCount={totalCount}
        handlePagination={handlePagination}
        activePage={activePage}
      />
    </Section>
  );
}
export default OpportunitiesSection;
