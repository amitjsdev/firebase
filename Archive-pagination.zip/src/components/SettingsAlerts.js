import React, { useState } from "react";
import FormField from "./FormField";
import SectionButton from "./SectionButton";
import { useAuth } from "../util/auth.js";
import { useForm } from "react-hook-form";
import AuthFooter from "./AuthFooter";

function SettingsAlerts (props) {
  const auth = useAuth();
  const [pending, setPending] = useState(false);

  const { register, handleSubmit, errors } = useForm();

  const onSubmit = (data) => {
    // Show pending indicator
    setPending(true);

    return auth
      .updateProfile(data)
      .then(() => {
        // Set success status
        props.onStatus({
          type: "success",
          message: "Your profile has been updated",
        });
      })
      .catch((error) => {
        if (error.code === "auth/requires-recent-login") {
          props.onStatus({
            type: "requires-recent-login",
            // Resubmit after reauth flow
            callback: () => onSubmit(data),
          });
        } else {
          // Set error status
          props.onStatus({
            type: "error",
            message: error.message,
          });
        }
      })
      .finally(() => {
        // Hide pending indicator
        setPending(false);
      });
  };


  return [
    <h1 class="title">Select the categories you'd like to receive email alerts for:</h1>,  
    <form onSubmit={handleSubmit(onSubmit)}>
        <FormField
        class="checkbox"
        name="healthcare"
        type="checkbox"
        label="Healthcare"
        defaultChecked={auth.user.healthcare}
        error={errors.healthcare}
        inputRef={register({
        })}
        />
        <FormField
        class="checkbox"
        name="sustainability"
        type="checkbox"
        label="Sustainability"
        defaultChecked={auth.user.sustainability}
        error={errors.sustainability}
        inputRef={register({
        })}
        />
       <div className="field">
        <div className="control">
          <SectionButton
            parentColor={props.parentColor}
            size="medium"
            state={pending ? "loading" : "normal"}
          >
            Save
          </SectionButton>
        </div>
    </div>
    </form>
  ];
}

export default SettingsAlerts;