import React, { useEffect, useState } from "react";
import Section from "../Section";
import SectionHeader from "../SectionHeader";
import { Link, useRouter } from "../../util/router.js";
import { useAuth } from "../../util/auth.js";
import Options from "./options";
import { connect } from "react-redux";
import { getAllCategories, getUserAlertCat } from "../../util/db.js";

function AlertsSection(props) {
  const auth = useAuth();
  const router = useRouter();
  const [categories, setCategories] = useState([]);
  const [selectedCats, setSelectedcats] = useState([]);
  const [isLoading, setLoading] = useState(false);
  useEffect(() => {
    getCategories();
    getSelectedAlerts();
  }, []);

  const getSelectedAlerts = () => {
    const userId = auth.user?.id;
    getUserAlertCat(userId).then((results) => {
      if (results) {
        let arr = [];
        results.forEach((doc) => {
          let data = doc.data();
          data = { ...data, id: doc.id};
          arr.push(data);
        });
        setSelectedcats(arr);
      }
    }).catch(err=>{
      console.log(err,"errr")
    });
  };

  const getCategories = async () => {
    let arr = [];
    const results = await getAllCategories();
    if (results) {
      results.forEach(function (doc) {
        const data = doc.data();
        let option = { value: doc.id, label: data.name };
        arr.push(option);
      });
    }
    setCategories(arr);
  };

  // let data = renderOptions.slice();

  return (
    <Section color={props.color} size={props.size}>
      <div className="container">
        <SectionHeader
          title={props.title}
          subtitle={props.subtitle}
          size={3}
          spaced={true}
          className="has-text-centered"
        />
        <div className="card mb-4">
          <div className="card-content">
            <div>
              <p>
                You can toggle alerts for categories you're interested in. When you have alerts turned on for a category, we'll send you an email when we find a new opportunity. Set as many alerts as you'd like!
              </p>
            </div>
          </div>
        </div>
        <Options allCategories={categories} oldSelectedCats={selectedCats} isLoading = {isLoading} setLoading = {setLoading}/>
      </div>
    </Section>
  );
}

const selector = (state) => {
  return {
    dbDataReducer: state.dbDataReducer,
  };
};

export default connect(selector, null)(AlertsSection);
