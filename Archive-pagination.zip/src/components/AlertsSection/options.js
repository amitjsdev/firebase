import React, { useState, useEffect } from "react";
import { usersAlert, getUserAlertCat } from "../../util/db.js";
import { useAuth } from "../../util/auth.js";
import PageLoader from "../PageLoader";
import FormAlert from "../../components/FormAlert";
import "bulma-switch";
import { toast } from "react-toastify";

// import useStateWithCallback from 'use-state-with-callback'
const ChecboxInput = (props) => {
  const { label = "", isChecked, idx } = props;
  // const checked = isChecked

  return (
    <>
      <div className="field pb-0" style={{ marginBottom: "5px" }} key={idx}>
        <input
          id={"switchExample" + idx}
          type="checkbox"
          name="switchExample"
          onChange={(e) => {
            props.onSelectCategory(e, props.category, idx);
          }}
          className="switch"
          checked={isChecked}
        />
        <label htmlFor={"switchExample" + idx}>{label}</label>
      </div>
    </>

    // <div>
    //   <label className="checkbox">
    //     <input
    //       onChange={(e) => props.onSelectCategory(e, props.category, idx)}
    //       type="checkbox"
    //       className="mr-1"
    //       checked={isChecked}
    //     />
    //     {label}
    //   </label>
    // </div>
  );
};

const Options = (props) => {
  const { allCategories, oldSelectedCats } = props;
  const [isLoading, setLoading] = useState(false);
  const data = [];

  allCategories.length &&
    allCategories.forEach((el) => {
      let obj = { value: el.value, label: el.label, isChecked: false };
      data.push(obj);
    });
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [renderOptions, setRenderOptions] = useState([]);
  const [InitialCat, setInitialCat] = useState([]);

  const [showAlert, setShowAlert] = useState(false);
  const [message, setmessage] = useState("");
  var auth = useAuth();
  let messageInterval = null;
  let count = 0;

  useEffect(() => {
    if (props.allCategories) {
      // setLoading(true)
      const data = [];
      props.allCategories.length &&
        allCategories.forEach((el) => {
          let obj = { value: el.value, label: el.label, isChecked: false };
          data.push(obj);
        });
      setRenderOptions(data);
      // setLoading(false)
    }

    if (props.oldSelectedCats) {
      // console.log("dgfghfhgfhfdghggfjg")
      let oldData = allCategories.slice() || [];
      setLoading(true);
      const newData = oldData.map((el) => {
        let isChecked = -1;
        isChecked =
          oldSelectedCats.length > 0
            ? oldSelectedCats.findIndex((val) => {
                return (
                  val.name.trim().toLowerCase() ===
                  el.label.trim().toLowerCase()
                );
              })
            : -1;
        return { ...el, isChecked: isChecked != -1 };
      });
      setRenderOptions(newData);
      const oldcats = oldSelectedCats.map((el) => {
        return el.id;
      });
      setSelectedCategories(oldcats);
      if (!messageInterval) {
        messageInterval = setInterval(() => {
          // console.log("renderOptionsrenderOptions=",renderOptions)
          if (renderOptions.length > 0) {
            setLoading(false);
            clearInterval(messageInterval);
          } else {
            setLoading(false);
            clearInterval(messageInterval);
          }
        }, 1000);
      } else {
        setLoading(false);
      }
    }
  }, [props]);
  // useEffect(()=>{
  //   messageInterval = setInterval(() => {
  //     console.log("renderOptionsrenderOptions=",renderOptions)
  //     if (renderOptions.length > 0) {
  //       setLoading(false)
  //       clearInterval(messageInterval)
  //     }
  //   }, 1000);
  // },[])

  const setUserAlerts = (categories) => {
    const userId = auth.user?.id;
    usersAlert(userId, categories);
  };

  const onSelectCategory = (cb, category, idx) => {
    const newData = renderOptions.slice();
    newData[idx].isChecked = cb.target.checked;
    setRenderOptions(newData);
    if (cb.target.checked) {
      toast.dismiss();
      const newArray = selectedCategories.slice();
      newArray.push(category.value);
      setSelectedCategories(newArray);
      setUserAlerts(newArray);
      toast.success("Saved Successfully");
      // setShowAlert(true);
      // setmessage("Saved");
      // setTimeout(() => {
      //   // setShowAlert(false);
      //   toast.dismiss()
      // }, 1000);
    } else {
      toast.dismiss();
      const categoryIndex = selectedCategories.findIndex((el) => {
        return el === category.value;
      });
      selectedCategories.splice(categoryIndex, 1);
      setSelectedCategories(selectedCategories);
      setUserAlerts(selectedCategories);
      // setShowAlert(true);
      // setmessage("UnSaved");
      toast.success("Removed Successfully");
      // setTimeout(() => {
      //   // setShowAlert(false);
      //   toast.dismiss()
      // }, 1000);
    }
  };
  return (
    <div className="card mb-4">
      {/* {showAlert && (
        <FormAlert
          type="success"
          message={message}
          style={{ maxWidth: "450px" }}
        />
      )} */}

      <div className="card-content position-relative card-checkboxes">
        <div className="custom-loader">{isLoading && <PageLoader />}</div>

        {renderOptions &&
          renderOptions.length > 0 &&
          renderOptions.map((cat, index) => {
            // let isChecked = -1;
            // isChecked =
            //   InitialCat.length &&
            //   InitialCat.findIndex((el, index) => {
            //     return el.name == cat.label;
            //   });
            return (
              <div className="card-checkboxes-inner" key={index}>
                <ChecboxInput
                  onSelectCategory={onSelectCategory}
                  category={cat}
                  label={cat.label}
                  isChecked={cat.isChecked}
                  idx={index}
                />
              </div>
            );
          })}
        <div></div>
      </div>
    </div>
  );
};

export default Options;
