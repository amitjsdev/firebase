import React, { useState, useEffect, forwardRef } from "react";
import { Link, withRouter, Redirect } from "react-router-dom";
import InfiniteScroll from "react-infinite-scroll-component";
import moment from "moment";
import PriceMoney from "../../assets/opportunity/price-money.png";
import Deadlines from "../../assets/opportunity/deadlines.png";
import Profile from "../../assets/opportunity/profile.png";

const Challenges = (props, ref) => {
  const { content, fetchData, catsInSelect } = props;
  const [card, setcard] = useState(false);
  const [path, setpath] = useState("");
  console.log("toggleCurrenttoggleCurrent", props.toggleCurrent, props.active);
  const handleClick = (opportunityIndex) => {
    const opportunity = content.length && content[opportunityIndex];
    console.log(
      "opportunityIndex",
      opportunityIndex,
      content,
      typeof opportunity.opportunityId
    );
    if (typeof opportunity.opportunityId != "undefined") {
      props.history.push({
        pathname: "opportunities/" + opportunity.opportunityId,
        search: `?pageBit=${props.toggleCurrent}&pN=${props.active}`,
      });
    }
  };

  return (
    <>
      <div class="columns challenges-cards" id="challenges">
        {content.map(
          (
            {
              opportunityName = "",
              type = "",
              opportunityPrizeMoney,
              opportunityDeadline,
              companyName,
              opportunityDescription,
              opportunityId,
            },
            index
          ) => (
            <div
              key={index}
              class="column "
              onClick={() => {
                handleClick(index);
              }}
            >
              <div className="card">
                <div className="card-content">
                  <div className="content is-small">
                    <div>
                      <h4>{opportunityName}</h4>
                      <p>{type}</p>
                      {opportunityPrizeMoney ? (
                        <p>
                          <div className="opportunies-icon">
                            <img src={PriceMoney} alt="PriceMoney" />
                          </div>

                          <b>Prize Money:</b>
                          {!isNaN(opportunityPrizeMoney)
                            ? "$" +
                            parseFloat(opportunityPrizeMoney)
                                .toFixed(2)
                                .replace(/\d(?=(\d{3})+\.)/g, "$&,")
                            : opportunityPrizeMoney}
                        </p>
                      ) : null}
                      {!!opportunityDeadline && (
                        <p>
                          <div className="opportunies-icon">
                            <img src={Deadlines} alt="Deadlines" />
                          </div>

                          <b>Deadline:</b>
                          {moment(opportunityDeadline).format("MM/DD/YYYY")}
                        </p>
                      )}
                      <p>
                        <div className="opportunies-icon">
                          <img src={Profile} alt="Profile" />
                        </div>

                        <b>{companyName}</b>
                      </p>
                    </div>
                    {opportunityId ? (
                      <Link to="/">
                        Learn More <i className="fas fa-arrow-right"></i>
                      </Link>
                    ) : null}
                  </div>
                </div>
              </div>
            </div>
          )
        )}

        {/* <p>loading ...</p> */}
      </div>
    </>
  );
};

export default withRouter(Challenges);
