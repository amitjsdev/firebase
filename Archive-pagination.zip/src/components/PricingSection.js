import React from "react";
import Section from "./Section";
import SectionHeader from "./SectionHeader";
import { Link } from "./../util/router.js";
import { useAuth } from "./../util/auth.js";
import "./PricingSection.scss";

function PricingSection(props) {
  const auth = useAuth();

  const items = [
    {
      id: "founding",
      name: "Founding Customers",
      price: "200",
      perks: [
        "Access to all current and past opportunities",
        "Unlimited automated alerts",
        "Search for opportunities by industry, prizes, deadline, and more"
      ]
    }
    /*
    {
      id: "startup",
      name: "Startup",
      price: "9",
      perks: [
        "Access to all current opportunities",
        "Automated alerts for up to three industries"
      ]
    },
    {
      id: "standard",
      name: "Standard",
      price: "29",
      perks: [
        "Access to all current and past innovation opportunities",
        "Unlimited automated alerts",
        "Search for opportunities by industry, prizes, deadline, and more",
      ],
    } */
  ];

  return (

    <Section
      id="pricing"
      color={props.color}
      size={props.size}
      backgroundImage={props.backgroundImage}
      backgroundImageOpacity={props.backgroundImageOpacity}
    >
      <div className="container">
        <div className="has-text-centered "><div className="PricingSection__label gradient-background is-flex"><p style={{margin:"auto"}}>OUR PRICE PLANE</p> <div style={{borderRadius:"50px", width:"33px"}} className="tag is-medium is-white"></div></div></div>
        <SectionHeader
          title={props.title}
          subtitle={props.subtitle}
          size={3}
          spaced={true}
          className="has-text-centered"
          style={{ paddingBottom: 50}}
          color="black"
        />
        <div className="columns is-centered is-variable is-4 is-desktop">
          {items.map((item, index) => (
            <div
              className="PricingSection__column column is-one-third-desktop"
              key={index}
            >
              <div
                className={
                  "PricingSection__card card" +
                  (item.emphasized === true ? " emphasized" : "")
                }
              >

                <div className="PricingSection__card-content">
                  <div className="gradient-background PricingSection__card-heading">
                    <div className="PricingSection__name is-size-5">
                      {item.name}
                    </div>
                    <div className="PricingSection__price has-text-weight-medium is-size-1 is-flex">
                      <span className="has-text-weight-light is-size-6">$</span>
                      <div>{item.price}<span className="PricingSection__period has-text-weight-light is-size-6" style={{ bottom: "0" }}>
                        /Year
                    </span></div>
                    </div>
                  </div>
                  {item.description && (
                    <p className="PricingSection__description">
                      {item.description}
                    </p>
                  )}
                  <div className="card-content">
                    {item.perks && (
                      <ul className="PricingSection__perks">
                        {item.perks.map((perk, index) => (
                          <li key={index} className="is-flex">
                            <div>
                              <i className="fas fa-circle is-size-7 has-text-primary" />
                            </div>
                            <div>
                              {perk}
                            </div>
                          </li>
                        ))}
                      </ul>
                    )}

                    <Link
                      className="PricingSection__button button is-medium is-rounded gradient-background"
                      to={
                        auth.user
                          ? `/purchase/${item.id}`
                          : `/auth/signup?next=/purchase/${item.id}`
                      }
                    >
                      Choose
                  </Link>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}

export default PricingSection;
