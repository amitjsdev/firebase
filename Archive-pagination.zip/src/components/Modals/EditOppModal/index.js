import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Modal from "@material-ui/core/Modal";

const useStyles = makeStyles((theme) => ({
  root: {
    height: 300,
    flexGrow: 1,
    minWidth: 300,
    transform: "translateZ(0)",
    "@media all and (-ms-high-contrast: none)": {
      display: "none",
    },
  },
  modal: {
    display: "flex",
    padding: theme.spacing(1),
    alignItems: "center",
    justifyContent: "center",
  },
  paper: {
    width: 360,
    backgroundColor: theme.palette.background.paper,
    boxShadow: theme.shadows[5],
    padding: "16px 20px 20px",
    borderRadius: 20,
  },
  paperRow: {
    background: "#fff",
    boxShadow: "0 2px 3px 1px #ccc",
    padding: "3px 10px",
    marginBottom: 10,
    borderRadius: 20,
    display: "flex",
    alignItems: "center",
  },
  title: {
    color: "#328573",
    fontWeight: 600,
    marginBottom: 10,
  },
  label: {
    fontSize: "13px",
    minWidth: "145px",
    fontWeight: "500",
  },
  alertLabel: {
    marginLeft: "5px",
    fontSize: "14px",
    fontWeight: "500",
  },
  input: {
    border: "0",
    color: "#797878",
    outline: "0",
  },

  btn: {
    background: "linear-gradient(to right, #62dc99, #44c1a0)",
    width: "80px",
    marginRight: "10px",
    border: "0",
    height: "22px",
    color: "#fff",
    borderRadius: "7px",
    textTransform: "capitalize",
  },
}));

export default function EditOppModal({
  onSave,
  open,
  opp,
  handleChange,
  close,
  editMode,
}) {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <Modal
        open={open}
        disableEnforceFocus
        disableAutoFocus
        className={classes.modal}
      >
        <div className={classes.paper}>
          <h2 className={classes.title}>Opportunity Details</h2>
          <div className={classes.paperRow}>
            <label className={classes.label}>Company Name:</label>
            <input
              value={opp?.data.companyName || ""}
              onChange={(e) => handleChange("companyName", e.target.value)}
              className={classes.input}
            />
          </div>
          <div className={classes.paperRow}>
            <label className={classes.label}>Opportunity Name</label>
            <input
              value={opp?.data.opportunityName || ""}
              onChange={(e) => handleChange("opportunityName", e.target.value)}
              className={classes.input}
            />
          </div>
          <div className={classes.paperRow}>
            <label className={classes.label}>Prize Money</label>
            <input
              value={opp?.data.opportunityPrizeMoney || ""}
              onChange={(e) =>
                handleChange("opportunityPrizeMoney", e.target.value)
              }
              className={classes.input}
            />
          </div>
          <div className={classes.paperRow}>
            <label className={classes.label}>Category</label>
            <input
              value={opp?.data.opportunityCategory || ""}
              onChange={(e) =>
                handleChange("opportunityCategory", e.target.value)
              }
              className={classes.input}
            />
          </div>
          <div className={classes.paperRow}>
            <label className={classes.label}>Opportunity Type</label>
            <input
              value={opp?.data.opportunityType || ""}
              onChange={(e) => handleChange("opportunityType", e.target.value)}
              className={classes.input}
            />{" "}
          </div>
          <div className={classes.paperRow}>
            <label className={classes.label}>Opportunity URL</label>
            <input
              value={opp?.data.opportunityURL || ""}
              onChange={(e) => handleChange("opportunityURL", e.target.value)}
              className={classes.input}
            />{" "}
          </div>
          <div className={classes.paperRow}>
            <label className={classes.label}>Opportunity Description</label>
            <input
              value={opp?.data.opportunityDescription || ""}
              onChange={(e) =>
                handleChange("opportunityDescription", e.target.value)
              }
              className={classes.input}
            />
          </div>
          <div className={classes.paperRow}>
            <label className={classes.label}>Opportunity Deadline</label>
            <input
              value={opp?.data.opportunityDeadline || ""}
              onChange={(e) =>
                handleChange("opportunityDeadline", e.target.value)
              }
              className={classes.input}
            />{" "}
          </div>
          <div className="ml-1">
            <input
              type="checkbox"
              checked={opp?.data.isChecked || false}
              onChange={(e) => handleChange("isChecked", e.target.checked)}
              className={classes.input}
            />
            <label className={classes.alertLabel}>Alert</label>
          </div>

          <div className="mt-3">
            <button onClick={onSave} className={classes.btn}>
              {editMode ? "save" : "add"}
            </button>
            <button onClick={close} className={classes.btn}>
              cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
