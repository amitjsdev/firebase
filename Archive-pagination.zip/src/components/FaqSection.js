import React, { useState } from "react";
import Section from "./Section";
import SectionHeader from "./SectionHeader";
import "./FaqSection.scss";

function FaqSection(props) {
  // Object to store expanded state for all items
  const [expanded, setExpanded] = useState({});
  // Set an item's expanded state
  const setExpandedItem = (index, isExpanded) => {
    setExpanded({
      ...expanded,
      [index]: isExpanded,
    });
  };

  const items = [
    {
      question: "How Does Open Innovation Leads Work?",
      answer:
        "There are hundreds of open innovation opportunities and innovation challenges launched by large companies every year. The problem is, unless you're a following a company very closely, you'd have no idea these opportunities exist. We search all over to aggregate innovation opportunities, past and present. You can search through these opportunities using filters and save the ones that interest you. You can also set alerts to receive a notification when we find an opportunity that's relevant to you.",
    },
    {
      question: "What Is Open Innovation?",
      answer:
        "Open innovation is a mindset and method that large companies use to access new ideas, technology, and resources from external sources and collaborators, rather than relying solely on internal innovation.",
    },
    {
      question: "Won't Big Companies Steal My Ideas?",
      answer:
        "While this is a common fear, corporates almost never steal startup ideas. It's just cheaper, easier, and more effective for them to work with you. In addition, many open innovation challenges explicitly allow startups to retain their IP. For more information, look at the challenge website as well as the terms and conditions.",
    },
    {
      question: "What Are the Prizes for These Innovation Opportunities?",
      answer:
        "Every opportunity is different. Many challenges offer prize money (sometimes $1,000,000+), others offer investment, pilot projects, PR, and more. Take a look at individual challenge pages and websites for more information.",
    },
    {
      question: "Does Open Innovation Leads work with large companies to develop open innovation programs?",
      answer:
        "Open Innovation Leads is an innovation data tool and opportunity aggregator and does not directly work with any of the companies listed. We do have partners who can assist you with designing your own open innovation program. Please contact us for more information.",
    },
    {
      question: "What Is Your Cancellation Policy?",
      answer:
        "You can cancel your Open Innovation Leads subscription any time. Your subscription will remain active until the end of the subscription period you've already paid for.",
    },
  ];

  return (
    <Section
      color={props.color}
      size={props.size}
      backgroundImage={props.backgroundImage}
      backgroundImageOpacity={props.backgroundImageOpacity}
    >
      <div className="container">
        <SectionHeader
          title={props.title}
          subtitle={props.subtitle}
          size={3}
          spaced={true}
          className="has-text-centered"
        />

        {items.map((item, index) => (
          <article
            className="FaqSection__faq-item"
            onClick={() => {
              setExpandedItem(index, !expanded[index]);
            }}
            key={index}
          >
            <div className="title is-spaced is-4">
              <span className="FaqSection__icon icon is-size-5 has-text-primary">
                <i
                  className={
                    "fas" +
                    (expanded[index] ? " fa-minus" : "") +
                    (!expanded[index] ? " fa-plus" : "")
                  }
                />
              </span>
              {item.question}
            </div>

            {expanded[index] && <div className="subtitle">{item.answer}</div>}
          </article>
        ))}
      </div>
    </Section>
  );
}

export default FaqSection;
