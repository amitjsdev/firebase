import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import {
  addOpportunitiesData,
  getAllOpportunities,
  updateOpportunity,
  getAllCategories,
  getCurrentOpportunities,
  AddDataFromCSV,
  trackingData,
} from "../../util/db.js";
import * as actions from "../../redux/actions/dbDataActions";

import Section from "../Section";
import SectionHeader from "../SectionHeader";
import { Link, useRouter } from "../../util/router.js";
import { useAuth } from "../../util/auth.js";
import Challenges from "../Challanges";
import "./DashboardSection.scss";
import PageLoader from "../PageLoader";
function DashboardSection(props) {
  const [allOpportunities, setAllOpportunitiesArr] = useState([]);
  const [isLoading, setLoading] = useState(false);
  const auth = useAuth();
  const router = useRouter();
  let allCategories = [];
  const addData = () => {
    // addOpportunitiesData()
  };

  const getOpportunities = async () => {
    const arr = allOpportunities.slice();
    setLoading(true)
    getCurrentOpportunities(true,4).then((results) => {
    setLoading(false)
      if (results) {
        results.data && results.data.forEach(function (doc) {
          let data = doc.data();
          data = { ...data, opportunityId: doc.id };
          arr.push(data);
        });
        setAllOpportunitiesArr(arr);
      }
    });
  };
  const updateData = () => {
    updateOpportunity();
  };
  const deleteData = () => {};
  const getCategories = async () => {
    const arr = allCategories.slice();
    getAllCategories().then((results) => {
      if (results) {
        results.forEach(function (doc) {
          const data = doc.data();
          let option = { value: doc.id, label: data.name };
          arr.push(option);
        });
        props.setAllCategories(arr);
      }
    });
  };

  useEffect(() => {
    if (auth.user) {
      getOpportunities();
      getCategories();
    }
  }, []);
  allOpportunities &&
    allOpportunities.length &&
    allOpportunities.sort((a, b) => {
      return a.opportunityDeadline - b.opportunityDeadline;
    });
  return (
    <Section color={props.color} size={props.size}>
      <div className="container">
        <SectionHeader
          title={props.title}
          subtitle={props.subtitle}
          size={3}
          spaced={true}
          className="has-text-centered"
        />

        {router.query.paid && auth.user.planIsActive && (
          <article className="DashboardSection__paid-message message is-success mx-auto">
            <div className="message-body">
              You are now subscribed
              <span className="ml-2" role="img" aria-label="party">
                🥳
              </span>
            </div>
          </article>
        )}
        <div className="card mb-4">
          <div className="card-content">
            <div className="text-center">
              <p>
                We’ll send you email alerts when we find a challenge that meets
                your criteria - go set some alerts!
              </p>
              <p>
                There are currently XXX Current Opportunities and YYY Past
                Opportunities
              </p>
              <p>Here are some current opportunities:</p>
            </div>
          </div>
        </div>

        {/* <div className="card mb-3">
          <div className="card-content py-3">
            <div className="buttons">
              <button onClick={() => addData()} className="button is-info is-light">Add Data</button>
              <button onClick={() => getOpportunities()} className="button is-info is-light">Get Data</button>
              <button onClick={() => updateData()} className="button is-info is-light">Update Data</button>
              <button onClick={() => deleteData()} className="button is-info is-light"> Deleted</button>
            </div>
          </div>
        </div> */}
         {isLoading? <PageLoader
          style={{
            height: "100px",
          }}
        /> : null}

      {allOpportunities && allOpportunities.length&&  <Challenges content={allOpportunities} /> || <p className="text-center mb-4">No Current Opportunities </p>}

        <div className="card">
          <div className="card-content py-3 text-right">
            <div className="content is-small">
              <Link to="/">
                Explore More Challenges <i className="fas fa-arrow-right"></i>
              </Link>
            </div>
          </div>
        </div>

        <div className="columns is-vcentered is-desktop mt-5">
          <div className="column is-6-desktop">
            <div className="content">
              <progress class="progress" value="15" max="100">
                15%
              </progress>
              {!auth.user.stripeCustomerId && (
                <Link to="/pricing">
                  Only subscribed users can see challenges. Subscribe NOW!
                </Link>
              )}
              <p>
                This would be a good place to build your custom product features
                after exporting your codebase.
              </p>
              <p>
                You can grab the current user, query your database, render
                custom components, and anything else you'd like.
              </p>
              <p>
                Divjoy sets you up with everything you need so that you can get
                right to work on building your web app.
              </p>
            </div>
          </div>
          <div className="column is-1" />
          <div className="column">
            <figure className="DashboardSection__image image">
              <img
                src="https://uploads.divjoy.com/undraw-personal_settings_kihd.svg"
                alt="Illustration"
              />
            </figure>
          </div>
        </div>
        <div
          className="mx-auto has-text-centered mt-5"
          style={{
            maxWidth: "460px",
          }}
        >
          <small>
            Some helpful debug info
            <span className="ml-1" role="img" aria-label="bug">
              🐛
            </span>
          </small>
          <nav className="panel mt-3">
            <div className="panel-block is-block">
              Logged in as&nbsp;<strong>{auth.user.email}</strong>
            </div>
            <div className="panel-block is-block">
              {auth.user.stripeSubscriptionId && (
                <>
                  Subscription data
                  <br />
                  ID: <strong>{auth.user.stripeSubscriptionId}</strong>
                  <br />
                  Price ID: <strong>{auth.user.stripePriceId}</strong>
                  <br />
                  Status: <strong>{auth.user.stripeSubscriptionStatus}</strong>
                </>
              )}

              {!auth.user.stripeSubscriptionId && (
                <Link to="/pricing">Subscribe to a plan</Link>
              )}
            </div>
            <div className="panel-block is-block">
              <Link to="/settings/general">Account settings</Link>
            </div>
          </nav>
        </div>
     
       
     </div>
    </Section>
  );
}

const mapDispatchToProps = (dispatch) => {
  return {
    setAllCategories: (data) => dispatch(actions.setAllCategories(data)),
  };
};

const selector = (state) => {
  return {
    // productData: { ...state.createProduct },
    // apisReducer: state.apisReducer,
  };
};

export default connect(selector, mapDispatchToProps)(DashboardSection);
