import React, {useEffect,useState }from "react";
import Section from "../Section";
import SectionHeader from "../SectionHeader";
import Challenges from "../Challanges";
import {getUserSavedOpportunities} from "../../util/db.js";
import { useAuth } from "../../util/auth.js";
import PageLoader from '../../components/PageLoader'
function SavedSection(props) {
  var  auth = useAuth();
  const [savedOpportunities, setSavedOpportunities] = useState([])
  const [isLoading,setLoading] = useState(false)

  const getSavedOpportunities = ()=>{
    setLoading(true)
    getUserSavedOpportunities(auth.user?.id).then(result=>{
      
      if (result) {
        let arr = []
        result.forEach(function (doc) {
          let data = doc.data();
          data = { ...data, opportunityId: doc.id };
          arr.push(data);
        });
        setSavedOpportunities(arr)
        setLoading(false)
      } 
      else{
        setLoading(false)
      }
    })
  }

  useEffect(() => {
    getSavedOpportunities()
  }, [])
  return (
    <Section color={props.color} size={props.size}>
      <div className="container">
        <SectionHeader
          title={props.title}
          subtitle={props.subtitle}
          size={3}
          spaced={true}
          className="has-text-centered"
        />
        <div className="custom-loader mt-5">
      {isLoading &&  <PageLoader/>}
        </div> 
        <Challenges content={savedOpportunities} />
        {!savedOpportunities.length && !isLoading &&<div className="text-center"> Not Found</div>}
      </div>
    </Section>
  );
}

export default SavedSection;
