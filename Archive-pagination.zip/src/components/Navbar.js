import React, { useState } from "react";
import NavbarContainer from "./NavbarContainer";
import { Link, useLocation } from "./../util/router.js";
import { useAuth } from "./../util/auth.js";
import Opportunities from "../assets/menu/opportunities.png";
import Saved from "../assets/menu/saved.png";
import Alert from "../assets/menu/alert.png";
import Settings from "../assets/menu/settings.png";
import SignOut from "../assets/menu/sign-out.png";
import SettingsBlue from "../assets/menu/settings-blue.png";
import LogoutBlue from "../assets/menu/logout-blue.png";
import OpportunitiesBlue from "../assets/menu/opportunities-blue.png";
import AlertBlue from "../assets/menu/alert-blue.png";
import SavedBlue from "../assets/menu/saved-blue.png";
import Company from "../assets/menu/company-black.svg";
import CompanyBlue from "../assets/menu/company-blue.png";

const MenuItems = () => {
  const auth = useAuth();
  const location = useLocation();
  const menuData = [
    // {
    //   name: "Dashboard",
    //   link: "/dashboard",
    // },
    {
      name: "Companies",
      link: "/companies",
      icon: Company,
      iconBlue: CompanyBlue,
    },
    {
      name: "Opportunities",
      link: "/opportunities",
      icon: Opportunities,
      iconBlue: OpportunitiesBlue,
    },
    {
      name: "Saved",
      link: "/saved",
      icon: Saved,
      iconBlue: SavedBlue,
    },
    {
      name: "Alerts",
      link: "/alerts",
      icon: Alert,
      iconBlue: AlertBlue,
    },
    // {
    //   name: "Leads",
    //   link: "/leads",
    // },
    {
      name: "Settings",
      link: "/settings/general",
      icon: Settings,
      iconBlue: SettingsBlue,
    },
    {
      name: "Sign out",
      link: "/auth/signout",
      type: "sign-out",
      icon: SignOut,
      iconBlue: LogoutBlue,
    },
  ];
  return (
    <ul className="navbar-item has-dropdown is-hoverable">
      {menuData.map(
        (
          { name = "", link = "/", type = "", icon = "", iconBlue = "" },
          index
        ) => {
          const activeLink =
            location.pathname !== "/" && location.pathname === link
              ? true
              : false;
          return (
            <li key={index}>
              <Link
                className={`nav-link ${activeLink ? "active" : ""}`}
                to={link}
                onClick={(e) => {
                  type === "sign-out" && auth.signout();
                }}
              >
                <span className="nav-icon">
                  <img src={icon} alt={icon} className="icon" />
                  <img src={iconBlue} alt={icon} className="icon-blue" />
                </span>
                {name}
              </Link>
            </li>
          );
        }
      )}
    </ul>
  );
};

function Navbar(props) {
  const auth = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <NavbarContainer spaced={props.spaced} color={props.color}>
      <div className="container">
        <div className="navbar-brand">
          <div className="navbar-item">
            <Link to="/">
              <img
                className="image"
                src={props.logo}
                alt="Logo"
                className="logo"
              />
            </Link>
          </div>
          <div
            className={"navbar-burger burger" + (menuOpen ? " is-active" : "")}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            <span />
            <span />
            <span />
          </div>
        </div>
        <div className={"navbar-menu" + (menuOpen ? " is-active" : "")}>
          <div className="navbar-end">
            {auth.user && <MenuItems />}

            {!auth.user && (
              <Link className="navbar-item" to="/auth/signin">
                Sign in
              </Link>
            )}
          </div>
        </div>
        {/* {auth.user && (
              <div className="navbar-item has-dropdown is-hoverable">
                <Link className="navbar-link" to="/">
                  Account
                </Link>
                <div className="navbar-dropdown is-boxed">
                  <Link className="navbar-item" to="/dashboard">
                    Dashboard
                  </Link>
                  <Link className="navbar-item" to="/leads">
                    Leads
                  </Link>
                  <Link className="navbar-item" to="/settings/general">
                    Settings
                  </Link>
                  <hr className="dropdown-divider" />
                  <Link
                    className="navbar-item"
                    to="/auth/signout"
                    onClick={(e) => {
                      e.preventDefault();
                      auth.signout();
                    }}
                  >
                    Sign out
                  </Link>
                </div>
              </div>
            )} */}
      </div>
    </NavbarContainer>
  );
}

export default Navbar;
