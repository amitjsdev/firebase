import React from "react";
import { withRouter } from "react-router-dom";
import Companies from "../../assets/companies/company.svg";
const Challenges = (props) => {
  const { content , title } = props;

  const handleClick = (item) => {
    props.history.push({
      pathname: "companies/details",
      state: { data: item },
    });
  };

  return (
    <>
      <div class="companies-cards">
        <div className="card">
          <div className="card-content py-2">
            <h3>
              Companies <span>{title}</span>
            </h3>
          </div>
        </div>
        <div className="card">
          <div className="card-content py-4">
            <div className="content is-small">
              {content.map((item, index) => (
                <div
                  key={index}
                  onClick={() => {
                    handleClick(item);
                  }}
                  className="name"
                >
                  <h4>
                    <img src={Companies} alt="Companies" className="mr-3" />
                    {item.companyName}
                  </h4>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default withRouter(Challenges);
