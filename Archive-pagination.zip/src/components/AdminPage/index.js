import React, { useEffect, useState } from "react";
import {
  AddDataFromCSV,
  getAllOpportunities,
  updateOpportunitiesById,
  deleteOpportunitiesById,
  addOpportunities,
  searchOpportunityByName,
  getLimitedOpportunities,
  getNumberOfOpportunities,
} from "../../util/db.js";
import { uploadFile, FILE_STORAGE_PATH, fetchFile } from "../../util/storage";
import PageLoader from "../PageLoader";
import FormAlert from "../FormAlert";
import moment from "moment";
import EditOppModal from "../../components/Modals/EditOppModal/index";
import Edit from "../../assets/admin/edit.svg";
import Delete from "../../assets/admin/delete.svg";
import Pagination from "../Pagination";
let file;

function AdminPageSection() {
  const [isloading, setLoading] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [recentCSV, setRecentCSV] = useState([]);
  const [opportunities, setOpportunities] = useState([]);
  const [oppToEdit, setOppToEdit] = useState({});
  const [isEditModal, setIsEditModal] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const OpportunitiesPerPage = 10;
  const [totalCount, setTotalCount] = useState(20);
  const [activePage, setActivePage] = useState(1);
  const [file, setFile] = useState(1);

  useEffect(() => {
    getRecentCSV();
    getOpportunities();
    getNumberOfOpp();
  }, []);

  const getNumberOfOpp = async () => {
    let data = await getNumberOfOpportunities();
    setTotalCount(data);
  };

  const getOpportunities = async () => {
    const allOpportunities = await getAllOpportunities(10);
    const OppArr = [];
    allOpportunities.docs.forEach((doc) => {
      let data = { id: doc.id, data: doc.data() };
      OppArr.push(data);
    });
    setOpportunities(OppArr);
  };

  const addData = async () => {
    if (!file) {
      return;
    }
    setLoading(true);
    const result = await processCSV();
    if (result && result.data && result.data.length > 0) {
      const data = result.data;
      await AddDataFromCSV(data, "opportunities");
      setLoading(false);
      setShowAlert(true);
      setTimeout(() => {
        setShowAlert(false);
      }, 2000);
    }
  };

  const getRecentCSV = async () => {
    setLoading(true);
    await fetchFile(FILE_STORAGE_PATH.CSV).then((res) => {
      let arrayOfFiles = [];
      res.items.forEach((item) => {
        let obj = {};
        let timeStamp = item.name.split(".")[0].split("temp")[1];
        obj.name = item.name;
        obj.time = moment(parseInt(timeStamp)).format("h:mm");
        obj.date = moment(parseInt(timeStamp)).format("MM/DD/YYYY");
        obj.timeStamp = parseInt(timeStamp);
        arrayOfFiles.push(obj);
      });
      arrayOfFiles = arrayOfFiles.sort(function (x, y) {
        return y.timeStamp - x.timeStamp;
      });
      setRecentCSV(arrayOfFiles);
      setLoading(false);
    });
  };

  const processCSV = () => {
    setLoading(true);
    return new Promise((resolve, reject) => {
      uploadFile({
        file,
        filePath: FILE_STORAGE_PATH.CSV,
        fileName: "temp" + Date.now() + ".csv",
      })
        .then((url) => {
          getRecentCSV();
          document.getElementById("fileSelect").value = null;
          setFile(null);
          fetch("/api/readcsv/readCSV", {
            method: "post",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ url }),
          })
            .then((res) => res.json())
            .then((res) => {
              let fileName = url.split("?");
              fileName = fileName[0].split("%2F").pop();
              setLoading(false);
              resolve({ data: res.data });
            })
            .catch((err) => {
              setLoading(false);
              resolve({ data: [] });
            });
        })
        .catch((err) => {
          setLoading(false);
          resolve({ data: [] });
        });
    });
  };

  const handleFileUpload = (e) => {
    setFile(e.target.files[0]);
  };

  const onSave = () => {
    if (isEditMode) {
      updateOpportunitiesById(oppToEdit.id, oppToEdit.data);
    } else {
      addOpportunities(oppToEdit.data);
    }
    setIsEditModal(false);
    getOpportunities();
  };

  const handleOpp = (type, opp) => {
    if (type === "edit") {
      setIsEditMode(true);
      setOppToEdit(opp);
      setIsEditModal(true);
    } else {
      deleteOpportunitiesById(opp.id);
      getOpportunities();
    }
  };

  const handleOppEdit = (type, value) => {
    let data = {};
    if (oppToEdit?.data) {
      data = { ...oppToEdit.data };
    }
    data[type] = value;
    setOppToEdit({ ...oppToEdit, data: data });
  };

  const addOpportunity = () => {
    setIsEditMode(false);
    setIsEditModal(true);
    setOppToEdit(null);
  };

  const handleSearch = async () => {
    if (searchValue) {
      const data = await searchOpportunityByName(searchValue);
      let searchedData = [];
      data.docs.forEach((doc) => {
        let data = { id: doc.id, data: doc.data() };
        searchedData.push(data);
      });
      setOpportunities(searchedData);
    } else {
      getOpportunities();
    }
  };

  const handlePagination = async (e) => {
    setActivePage(e);
    getAllOpportunitiesWithFilter(e);
  };

  const getAllOpportunitiesWithFilter = async (active) => {
    var fetchOpp = await getLimitedOpportunities(
      OpportunitiesPerPage,
      active,
      true
    );
    setOpportunities(fetchOpp.data);
  };

  return (
    <>
      {isEditModal && (
        <EditOppModal
          onSave={onSave}
          open={isEditModal}
          opp={oppToEdit}
          handleChange={handleOppEdit}
          close={() => setIsEditModal(false)}
          editMode={isEditMode}
        />
      )}

      <section className="SectionComponent is-white">
        <div className="admin-page">
          <div className="container">
            <div className="search-wrapper">
              <input
                id="text"
                onChange={(e) => setSearchValue(e.target.value)}
                placeholder="Search..."
              />
              <button onClick={handleSearch}>
                <i class="fas fa-chevron-down" />
              </button>
            </div>
            <div className="csv-upload-wrapper">
              <div className="csv-upload-content">
                <div className="csv-upload">
                  <label className="mb-0"> Add Opportunity CSV: </label>
                  <div className="csv-input">
                    <input
                      id="fileSelect"
                      type="file"
                      accept=".csv"
                      onChange={(e) => handleFileUpload(e)}
                    />

                    <button onClick={() => addData()} className="button">
                      Add Data
                    </button>
                  </div>
                </div>
                <button
                  onClick={addOpportunity}
                  className="button add-opportunities"
                >
                  Add a Opportunities <span>+</span>
                </button>
                {/* <button onClick={() => getOpportunities()} className="button is-info is-light">Get Data</button>
        <button onClick={() => updateData()} className="button is-info is-light">Update Data</button>
        <button onClick={() => deleteData()} className="button is-info is-light"> Deleted</button> */}
              </div>
            </div>
            {
              <table>
                <thead>
                  <tr>
                    <th>Company Name</th>
                    <th>Opportunity Name</th>
                    <th>PrizeMoney</th>
                  </tr>
                </thead>
                <tbody>
                  {opportunities.map((opp) => (
                    <tr>
                      <td>{opp.data.companyName}</td>
                      <td>{opp.data.opportunityName}</td>
                      <td>${opp.data.opportunityPrizeMoney}</td>
                      <td>
                        <button
                          onClick={() => handleOpp("edit", opp)}
                          className="mr-2"
                        >
                          <img src={Edit} alt="edit" />
                        </button>
                      </td>
                      <td>
                        <button onClick={() => handleOpp("delete", opp)}>
                          <img src={Delete} alt="delete" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            }
            <Pagination 
             perpage={OpportunitiesPerPage}
             totalCount={totalCount}
             handlePagination={handlePagination}
             activePage={activePage}/>
            <div className="mt-5">
              {recentCSV.map((item) => {
                return (
                  <div className="card mb-3">
                    <div className="csv-file">
                      <p>{`Name: ${item.name}`}</p>
                      <p>{`Time: ${item.time}`}</p>
                      <p>{`Date: ${item.date}`}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {isloading && (
            <div className="admin-overlay">
              {" "}
              <PageLoader />{" "}
            </div>
          )}
          {showAlert && (
            <FormAlert
              type="success"
              message="CSV added Successfully"
              style={{ maxWidth: "450px" }}
            />
          )}
        </div>
      </section>
    </>
  );
}

export default AdminPageSection;
