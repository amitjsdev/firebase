import React from 'react';

const LeadsTableRow = props => {
    const { companyName, challengeName, cashPrize, tags, url } = props;
    let tagsList = []

    for (var i=0; i < tags.length; i++) {
        tagsList.push(<span class="tag" style={{margin: 5}}>{tags[i]}</span>)
    }

    return (
        <div class="tile is-child is-4 box" style={{display: "inline-flex"}}>
            <a href={url} target="_blank"><article class="tile is-child notification is-primary">
                <p class="title">{companyName}</p>
                <p class="subtitle">{challengeName}</p>
                <p>Prize Money: ${cashPrize}</p>
                <p>{tagsList}</p>
            </article></a>
        </div>
    )
}

export default LeadsTableRow;