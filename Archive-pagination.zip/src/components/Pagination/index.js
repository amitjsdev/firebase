import React, { useState, } from "react";
import Pagination from "react-js-pagination";
function CommonPagination(props){
  const {totalCount,handlePagination,activePage,perpage} = props
// const [activePage,setActivePage ] = useState(1);
//  const  handlePageChange = (pageNumber) =>{
//     setActivePage(pageNumber)
//   }
  return (
    <div className="mt-4">
      <Pagination
        innerClass="pagination-list justify-content-center"
        itemClass="page-item"
        linkClass="pagination-link"
        activeLinkClass="pagination-link is-current"
        activePage={activePage}
        itemsCountPerPage={perpage}
        totalItemsCount={totalCount||5}
        pageRangeDisplayed={5}
        onChange={handlePagination}
      />
    </div>
  );

}

export default CommonPagination;
