import React, { useState, useEffect } from "react";
import Section from "../Section";
import { getOpportunity, saveUsersOpportunity } from "../../util/db.js";
import moment from "moment";
import FormAlert from "../../components/FormAlert";
import { useAuth } from "../../util/auth.js";
import { withRouter } from "react-router-dom";
import PrizeMoney from "../../assets/opportunity/price-money.png";
import Deadlines from "../../assets/opportunity/deadlines.png";
import Category from "../../assets/opportunity/category.svg";

function ViewOpportunitiesSection(props) {
  var auth = useAuth();
  const [opportunity, setOpportunity] = useState();
  const [isSaved, setSaved] = useState(false);
  const [back, setback] = useState(false);
  const toggleBit = props.location.search;
  const getOpportunityById = () => {
    const url = window.location.pathname;
    const Id = url.split("/").pop();
    getOpportunity(Id).then((results) => {
      if (results) {
        setOpportunity(results);
      }
    });
  };

  let params = new URLSearchParams(toggleBit);
  let value = params.get("pageBit");
  let pageNumber = params.get("pN");
  console.log("asdadadsad", props, toggleBit, params, value, pageNumber);

  useEffect(() => {
    getOpportunityById();
  }, []);

  const saveOpportunity = () => {
    const userId = auth.user?.id;
    const opp = opportunity.opportunityId;
    saveUsersOpportunity(userId, opp);
    setSaved(true);
  };
  const goback = () => {
    setback(true);
    if(pageNumber==="company"){
    props.history.push("/companies")
    }else{
      props.history.push({
      pathname: "/opportunities",
      search: `?pageBit=${value}&pN=${pageNumber}`,
    });
    }
  };

  return (
    <Section color={props.color} size={props.size}>
      <div className="container">
        <div className="learn-more-wrapper">
          <div className="card mb-3">
            <div className="card-content py-3">
              <div className="content is-small">
                <button className="button icon-btn is-small" onClick={goback}>
                  <i className="fas fa-arrow-left mr-2" />
                  Go Back
                </button>
              </div>
            </div>
          </div>
          {isSaved && (
            <FormAlert
              type="success"
              message="Opportunity Saved Succesfully"
              style={{ maxWidth: "450px" }}
            />
          )}
          <div className="card">
            <div className="card-content">
              {opportunity && (
                <div className="content ">
                  <h2>{opportunity.opportunityName}</h2>
                  <h4>{opportunity.companyName}</h4>
                  <p>{opportunity.opportunityDescription}</p>
                  <div className="o-content">
                    <p>
                      <img src={PrizeMoney} alt="PrizeMoney" />
                      <b>Prize Money : </b>$
                      {opportunity &&
                        typeof opportunity.opportunityPrizeMoney == "number" &&
                        opportunity.opportunityPrizeMoney
                          .toFixed(2)
                          .replace(/\d(?=(\d{3})+\.)/g, "$&,")}
                    </p>
                    {/* <p>
    Other Rewards: Mentorship, Invitation to General Motors offices
  </p> */}
                    {!!opportunity.opportunityDeadline && (
                      <p>
                        <img src={Deadlines} alt="Deadlines" />
                        <b>Deadline: </b>
                        {moment(opportunity.opportunityDeadline).format(
                          "MM/DD/YYYY"
                        )}
                      </p>
                    )}

                    {opportunity.categories.length !== 0 ? (
                      <p>
                        <img src={Category} alt="category" />
                        <b>Categories: </b>
                        {opportunity.categories.map((el, idx) => {
                          // cate-colr${idx}
                          return (
                            <span key={idx} className={`categories`}>
                              {el.name}
                            </span>
                          );
                        })}
                      </p>
                    ) : null}
                  </div>
                  {/* <p>Learn more about this challenge</p>
                <p>Learn more about General Motors</p> */}
                  <button
                    className="button icon-btn is-small"
                    onClick={saveOpportunity}
                  >
                    Save Challenge
                  </button>
                  <a
                    href={opportunity.opportunityURL}
                    className="button icon-btn is-small ml-4"
                    target="_blank"
                  >
                    Visit Challenge Website{" "}
                    <i className="fas fa-arrow-right ml-2"></i>
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}
export default withRouter(ViewOpportunitiesSection);
