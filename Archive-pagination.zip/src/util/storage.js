import 'firebase/storage';
import firebase from "./firebase";
import { toast } from "react-toastify";

const storage = firebase.storage();

export const FILE_STORAGE_PATH = {
  CSV: 'csv_files/'
}


export const uploadFile = async ({ file, filePath, fileName }) => {
  return new Promise(async (resolve, reject) => {
    const uploadFile = storage
      .ref(filePath + fileName)
      .put(file);

    await uploadFile.on(
      "state_changed",
      null,
      (err) => {
        reject(err);
      },
      () => {
        // To get the download url then sets the image from firebase as the value for the imgage url :
        storage
          .ref(filePath)
          .child(fileName)
          .getDownloadURL()
          .then((url) => {
            toast.success("File Uploaded");
            resolve(url);
          })
          .catch(() => {
            reject(null);
          });
      }
    );


  })
}

export const deleteFile = (filePath) => {
  storage
    .ref(
      filePath
    )
    .delete()
    .then(() => { })
    .catch((error) => { });
}
export const fetchFile = async(filePath) => {
  return new Promise(resolve => {
      storage
     .ref(
       filePath
     ).listAll().then((res)=>{
       if(res){
         resolve(res)
       }
     })
 
   })
 
 }