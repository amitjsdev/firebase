import { useReducer, useEffect, useRef } from "react";
import firebase from "./firebase";
import app from "firebase/app";
import { tsConstructorType } from "@babel/types";
import { asyncForEach } from "./util";
import moment from "moment";
import store from "../redux/store/index";
import { sendNewEmail } from "../redux/actions/userEmail";
let lastVisible;
let resultlength = 0;
// import { useAuth } from "./auth.js";
// this.database = app.database();
const firestore = firebase.firestore();
// const  auth = useAuth();
// const userId = auth.user?.id;
 const getOpportunitiesCollection = () =>
  app.firestore().collection("opportunities");
  const getCompanieesCollection = () =>
  app.firestore().collection("companies");
const getCategoriesCollection = () => app.firestore().collection("categories");
const getUserAlerts = () => app.firestore.collection("user_alerts");
/**** USERS ****/

// Fetch user data (hook)
// This is called automatically by auth.js and merged into auth.user
export function useUser(uid) {
  return useQuery(uid && firestore.collection("users").doc(uid));
}

export function getUserDetail(email) {
  let dbRef = firestore
    .collection("users")
    .where("email", "==", email)
    .limit(1);
  return dbRef.get().then((result) => {
    if (!result.empty) {
      const userData = result.docs[0];
      return userData.data();
    }
  });
}

const checkInUserCats = async (categories, userId) => {
  let found = false;
  const result = await firestore
    .collection("user_alerts")
    .where("userId", "==", userId)
    .limit(1)
    .get();
  if (!result.empty) {
    let arr = [];
    result.docs.forEach((doc) => {
      const data = doc.data();
      arr.push(data);
    });
    const userAlertCats = arr[0].categories;
    categories.forEach((el) => {
      let catIndex = -1;
      catIndex = userAlertCats.findIndex((cat) => {
        return cat === el;
      });
      if (catIndex != -1) {
        console.log("category found");
        found = true;
      }
    });
  }
  return found;
};

export function trackingData(userId) {
  let docRef = getOpportunitiesCollection();

  // docRef.onSnapshot(function(snapshot) {
  //  snapshot.docChanges().asyncForEach(docChanges, async function(change) {
  // console.log("snapshotsnapshot=",snapshot)
  // snapshot.docChanges().forEach(async function(change) {
  //     if (change.type === "added") {
  //         console.log("Added data: ", change.doc.data());
  //         const addedData = change.doc.data()
  //         const categories = addedData.categories
  //         console.log("categoriescategories=",categories)
  //         const catFound = await checkInUserCats(categories,userId)
  //         console.log("catFoundcatFound=",catFound)
  //     }
  //     if (change.type === "modified") {
  //         console.log("Modified data: ", change.doc.data());
  //     }
  //     if (change.type === "removed") {
  //         console.log("Removed tada: ", change.doc.data());
  //     }
  // });
  // });
}

// Update an existing user
export function updateUser(uid, data) {
  return firestore.collection("users").doc(uid).update(data);
}

// Create a new user
export function createUser(uid, data) {
  return firestore
    .collection("users")
    .doc(uid)
    .set({ uid, ...data }, { merge: true });
}

/**** ITEMS ****/
/* Example query functions (modify to your needs) */

// Fetch all items by owner (hook)
export function useItemsByOwner(owner) {
  return useQuery(
    owner && firestore.collection("items").where("owner", "==", owner)
  );
}

// Fetch item data
export function useItem(id) {
  return useQuery(id && firestore.collection("items").doc(id));
}

// Update an item
export function updateItem(id, data) {
  return firestore.collection("items").doc(id).update(data);
}

// Create a new item
export function createItem(data) {
  return firestore.collection("items").add(data);
}

/**** HELPERS ****/

// Reducer for useQuery hook state and actions
const reducer = (state, action) => {
  switch (action.type) {
    case "idle":
      return { status: "idle", data: undefined, error: undefined };
    case "loading":
      return { status: "loading", data: undefined, error: undefined };
    case "success":
      return { status: "success", data: action.payload, error: undefined };
    case "error":
      return { status: "error", data: undefined, error: action.payload };
    default:
      throw new Error("invalid action");
  }
};

// Custom React hook that subscribes to a Firestore query
function useQuery(query) {
  // Our initial state
  // Start with an "idle" status if query is falsy, as that means hook consumer is
  // waiting on required data before creating the query object.
  // Example: useQuery(uid && firestore.collection("profiles").doc(uid))
  const initialState = {
    status: query ? "loading" : "idle",
    data: undefined,
    error: undefined,
  };

  // Setup our state and actions
  const [state, dispatch] = useReducer(reducer, initialState);

  // Gives us previous query object if query is the same, ensuring
  // we don't trigger useEffect on every render due to query technically
  // being a new object reference on every render.
  const queryCached = useMemoCompare(query, (prevQuery) => {
    // Use built-in Firestore isEqual method to determine if "equal"
    return prevQuery && query && query.isEqual(prevQuery);
  });

  useEffect(() => {
    // Return early if query is falsy and reset to "idle" status in case
    // we're coming from "success" or "error" status due to query change.
    if (!queryCached) {
      dispatch({ type: "idle" });
      return;
    }

    dispatch({ type: "loading" });

    // Subscribe to query with onSnapshot
    // Will unsubscribe on cleanup since this returns an unsubscribe function
    return queryCached.onSnapshot(
      (response) => {
        // Get data for collection or doc
        const data = response.docs
          ? getCollectionData(response)
          : getDocData(response);

        dispatch({ type: "success", payload: data });
      },
      (error) => {
        dispatch({ type: "error", payload: error });
      }
    );
  }, [queryCached]); // Only run effect if queryCached changes

  return state;
}

// Get doc data and merge doc.id
function getDocData(doc) {
  return doc.exists === true ? { id: doc.id, ...doc.data() } : null;
}

// Get array of doc data from collection
function getCollectionData(collection) {
  return collection.docs.map(getDocData);
}

// Used by useQuery to store Firestore query object reference
function useMemoCompare(next, compare) {
  // Ref for storing previous value
  const previousRef = useRef();
  const previous = previousRef.current;

  // Pass previous and next value to compare function
  // to determine whether to consider them equal.
  const isEqual = compare(previous, next);

  // If not equal update previousRef to next value.
  // We only update if not equal so that this hook continues to return
  // the same old value if compare keeps returning true.
  useEffect(() => {
    if (!isEqual) {
      previousRef.current = next;
    }
  });

  // Finally, if equal then return the previous value
  return isEqual ? previous : next;
}

/**** OPPORTUNITIES ****/

export function updateOpportunity() {
  // let opportunitiesRef = firestore.collection("opportunities").doc("CVCNGfZNZpWYuMjIaBOg");
  // let arrUnion = opportunitiesRef.set({
  //   categories: firebase.firestore.FieldValue.arrayUnion('abc')
  // });
  // const docRef = firestore.collection("opportunities").where("categories", "array-contains-any", ["zegu4y6vVTX8Ej2YIV9c"])
  //   return docRef.get().then(function (results) {
  //     console.log("arrarr monika=",results)
  //     if (!results.empty) {
  //       return results;
  //     }
  //   }).catch(function (error) {
  //     console.log("Error updateOpportunity documents:", error);
  //     return [];
  //   });
  // let data = {
  //   companyName: "General Motors",
  //   companyURL: "General_url"
  // }
  // const db = firestore.collection("company").doc("CVCNGfZNZpWYuMjIaBOg" + "/").set(data)
  // db.doc("opp" + "CVCNGfZNZpWYuMjIaBOg" + "/").set(data);
  // 'in', ["1231","222","2131"]
  // console.log("auth.user?.idauth.user?.id=",userId)
  const docRef = firestore.collection("users_Opportunity");
  // let data = {
  //    userId : "dgdf",
  //    savedCategories : ["dfdsg",'dsfdg','sdfdg']
  // }
  // docRef.add(data)
  // firestore.collection("opportunities" + "/").add(data);
}

export function usersAlert(userId, categories) {
  firestore
    .collection("user_alerts")
    .where("userId", "==", userId)
    .limit(1)
    .get()
    .then((results) => {
      const thing = results.docs[0];
      if (thing && thing.ref) {
        thing.ref.update({
          categories: categories,
        });
      } else {
        let data = {
          userId,
          categories,
        };
        firestore.collection("user_alerts").add(data);
      }
    });
}

export async function getUserAlertCat(userId) {
  const results = await firestore
    .collection("user_alerts")
    .where("userId", "==", userId)
    .limit(1)
    .get();

  if (results) {
    let alerts = [];
    let arr = [];
    if (!results.empty) {
      results.docs.forEach((doc) => {
        const data = doc.data();
        arr.push(data);
      });
      if (arr.length > 0 && arr[0].categories.length > 0) {
        const cats = arr[0].categories;

        await asyncForEach(cats, async (cat) => {
          const results = await firestore
            .collection("categories")
            .where(firebase.firestore.FieldPath.documentId(), "==", cat)
            .get();
          if (!results.empty) {
            alerts.push(...results.docs);
          }
        });
        return alerts;
      }
    }
  }
}

export function getUserSavedOpportunities(userId) {
  return firestore
    .collection("users_opportunity")
    .where("userId", "==", userId)
    .limit(1)
    .get()
    .then(async (results) => {
      let arr = [];
      if (results) {
        results.forEach(function (doc) {
          const data = doc.data();
          arr.push(data);
        });

        if (arr && arr.length > 0) {
          const opps = arr[0].opportunities || [];
          let savedOpps = [];
          await asyncForEach(opps, async (opp) => {
            const results = await firestore
              .collection("opportunities")
              .where(firebase.firestore.FieldPath.documentId(), "==", opp)
              .get();
            if (!results.empty) {
              savedOpps.push(...results.docs);
            }
          });
          return savedOpps;
        } else {
          return false;
        }
      }
    });
}

export function saveUsersOpportunity(userId, opportunity) {
  firestore
    .collection("users_opportunity")
    .where("userId", "==", userId)
    .limit(1)
    .get()
    .then((results) => {
      const thing = results.docs[0];
      if (thing && thing.ref) {
        thing.ref.update({
          opportunities: firebase.firestore.FieldValue.arrayUnion(opportunity),
        });
      } else {
        let data = {
          userId,
          opportunities: [opportunity],
        };
        firestore.collection("users_opportunity").add(data);
      }
    });
}

export function getOpportunity(id) {
  return new Promise((resolve) => {
    const docRef = firestore.collection("opportunities").doc(id);
    docRef.get().then(async (results) => {
      if (!results.empty) {
        let data = results.data();
        let arr = [];
        const cateIds = data.categories;
        if (cateIds && cateIds.length > 0) {
          const res1 = await firestore
            .collection("categories")
            .where(firebase.firestore.FieldPath.documentId(), "in", cateIds)
            .get();
          if (!res1.empty) {
            res1.docs.forEach((doc) => {
              const data = doc.data();
              arr.push(data);
            });
          }
        }
        data = { ...data, opportunityId: results.id, categories: arr };
        // console.log("categoriescategories=", data);
        resolve(data);
      } else {
        resolve(null);
      }
    });
  });
}
export async function getFilteredOpportunities(
  categories,
  limit,
  resetlastVisible,
  activepage
) {
  lastVisible = resetlastVisible ? undefined : lastVisible;
  console.log(limit);
  let doc = [];
  let totaldata;
  let dataval;
  console.log("limitlimitlimit", limit);
  if (limit == 16) {
    // console.log("getFilteredOpportunities =",)
    let docRef = firestore.collection("opportunities");
    // const data = categories && categories.map(async (el)=>{
    //   const res =  await docRef.where("categories", "array-contains", el).get()
    //   return res
    // })
    // console.log("datadatadatadata =",data)
    // resultlength = data.length
    docRef = docRef
      .where("categories", "array-contains-any", categories)
      .orderBy("companyName");

    await docRef.get().then((snap) => {
      console.log("snap1247", snap);
      doc.push(snap.docs);
      totaldata = snap.size;
      resultlength = snap.size;
      let size = snap.size; // will return the collection size
    });
    if (doc[0]?.length) {
      console.log(doc[0], activepage);
      let index = activepage * limit - limit;
      let startVal = doc[0][index];

      dataval = startVal
        ? await docRef.startAt(startVal).limit(limit).get()
        : null;
      console.log("dataval1111", startVal, limit);
    }

    return { data: dataval, totaldata };

    // let next = lastVisible
    //   ? docRef.where("categories", "array-contains-any", categories).orderBy("companyName").startAfter(lastVisible).limit(limit)
    //   : null;
    // var first = docRef.where("categories", "array-contains-any", categories).orderBy("companyName").limit(limit);
    // if (lastVisible === "Fetched") {
    //   return;
    // }
    // if (!lastVisible) {

    //   return first
    //     .get().then(function (documentSnapshots) {
    //       lastVisible = documentSnapshots.docs[documentSnapshots.docs.length - 1];
    //       next = lastVisible ? docRef.where("categories", "array-contains-any", categories).orderBy("companyName").startAfter(lastVisible).limit(limit) : null;
    //       if (!documentSnapshots.empty) {
    //         return { data: documentSnapshots, resultlength };
    //       }
    //     }).catch(err => {
    //       console.log("errerrerr=", err)
    //     });
    // } else {
    //   return next
    //     .get().then((result) => {
    //       if (result.docs && !result.docs.length) {
    //         lastVisible = "Fetched";
    //         return;
    //       } else {
    //         lastVisible = result.docs[result.docs.length - 1];
    //         if (!result.empty) {
    //           return { data: result, resultlength };
    //         }
    //       }
    //     });
    // }
  } else {
    let docRef = getOpportunitiesCollection();
    let dbRef = firestore
      .collection("opportunities")
      .where("categories", "array-contains-any", categories)
      .orderBy("companyName")
      .limit(8)
      .get()
      .then((result) => {
        return { data: result, resultlength };
      });
    return dbRef;
  }
}

export function addOpportunitiesData() {
  let data = {
    // name:"Green Innovation2"
    companyName: "Bank of Pfizer Monika",
    companyURL: "Pfizer_url",
    opportunityName: "Healthcare Innovation Challenge",
    opportunityDescription: "",
    opportunityPrizeMoney: 20000,
    opportunityDeadline: Date.now(),
    opportunityURL: "Healthcare_url",
    categories: ["2SSaWhWB80T9lgEW19pu"],
  };
  firestore.collection("opportunities" + "/").add(data);
  // firestore.collection("categories" + "/").add(data);
}
export async function getCurrentOpportunities(resetlastVisible, limit, active) {
  lastVisible = resetlastVisible ? undefined : lastVisible;

  let docRef;
  if (limit == 4) {
    return firestore
      .collection("opportunities")
      .where("opportunityDeadline", ">", Date.now())
      .limit(4)
      .get()
      .then((result) => {
        console.log("current opps 4 =", result);
        return { data: result };
      });
  } else {
    if (limit == 16) {
      docRef = getOpportunitiesCollection();
      let dbRef = firestore
        .collection("opportunities")
        .orderBy("opportunityDeadline", "desc");
      dbRef.get().then((snap) => {
        resultlength = snap.size;
        let size = snap.size; // will return the collection size
        console.log("sizesize", size);
      });
      let next = lastVisible
        ? docRef
            .orderBy("opportunityDeadline", "desc")
            .startAfter(lastVisible)
            .limit(limit)
        : null;
      var first = docRef.orderBy("opportunityDeadline", "desc").limit(limit);
      if (lastVisible === "Fetched") {
        return;
      }
      if (!lastVisible) {
        return first.get().then(function (documentSnapshots) {
          lastVisible =
            documentSnapshots.docs[documentSnapshots.docs.length - 1];
          next =
            (lastVisible &&
              docRef
                .orderBy("opportunityDeadline", "desc")
                .startAfter(lastVisible)
                .limit(limit)) ||
            null;
          if (!documentSnapshots.empty) {
            return { data: documentSnapshots, resultlength };
          }
        });
      } else {
        return next.get().then((result) => {
          if (result.docs && !result.docs.length) {
            lastVisible = "Fetched";
            return;
          } else {
            lastVisible = result.docs[result.docs.length - 1];
            if (!result.empty) {
              return { data: result, resultlength };
            }
          }
        });
      }
    } else {
      let doc = [];
      let dataval;
      let totaldata;
      console.log("11156");
      let docRef = getOpportunitiesCollection();
      // const totaldata = await docRef.get().then((item) => item.docs.length);
      await docRef
        .orderBy("opportunityDeadline", "desc")
        .get()
        .then((res) => {
          console.log("resresres111", res);
          totaldata = res.size;
          doc.push(res.docs);
        });

      if (doc[0]?.length) {
        let index = active * 16 - 16;
        let startVal = doc[0][index];
        console.log("startValstartVal", startVal);
        dataval = startVal
          ? await docRef
              .orderBy("opportunityDeadline", "desc")
              .startAt(startVal)
              .limit(16)
              .get()
          : null;
      }
      return { data: dataval, totaldata };
      // .orderBy("opportunityDeadline", "desc")
      // .limit(16)
      // .get()
      // .then((result) => {
      //   return { data: result, resultlength, totaldata };
      // });
      // return dbRef;
    }
  }
  // return docRef.get().then((results) => {
  //   console.log("getCurrentOpportunities results=", results);
  //   if (!results.empty) {
  //     return results;
  //   }
  // });
}

// const setCategories = async (categoryarr) => {
//   let noRepeatCat = [];
//   console.log("firstcat", categoryarr);
//   return new Promise(async (resolve) => {
//     const categories = [];
//     const newCategories = [];
//     const ref1 = await firestore.collection("categories");
//     const queryRef = await ref1.get();
//     if (!queryRef.empty) {
//       queryRef.docs.forEach((el) => {
//         categories.push(el.id);
//       });
//     }
//     for (const cat of categoryarr) {
//       if (!categories.includes(cat)) {
//         newCategories.push(cat);
//         categories.push(cat);
//       }
//     }
//     const batch = firestore.batch();
//     newCategories.forEach((doc) => {
//       const docRef = db.collection("categories").doc(); //automatically generate unique id
//       batch.set(docRef, { name: doc });
//     });
//     batch.commit()
//     resolve(categories);
//   });
// };
let noRepeat=[]
const setCategories = async (categoryarr) => {
  console.log("firstcat", categoryarr,noRepeat);
  
  return await new Promise(async (resolve) => {
    const categories = [];
    for (let cat of categoryarr) {
      cat =cat.replace("\"","")
      const ref1 = await firestore.collection("categories");
      const queryRef = await ref1.where("name", "==", cat).get();
      if (!queryRef.empty) {
        queryRef.docs.forEach((el) => {
          categories.push(el.id);
        });
        resolve(categories);
      } else {
        
        if(!noRepeat.includes(cat))
        {
          console.log('insidecat',cat)
          let data = {
            name: cat,
          };
          firestore.collection("categories").add(data);
          noRepeat.push(cat);
        }
        const ref1 = await firestore.collection("categories");
        const queryRef = await ref1.where("name", "==", cat).get();
        if (!queryRef.empty) {
          queryRef.docs.forEach((el) => {
            categories.push(el.id);
          });
          resolve(categories);
        }
      }
    }
  });
};

const getOldOpportunities = async () => {
  return new Promise(async (resolve) => {
    await getAllOpportunities("all")
      .then((results) => {
        let arr = [];
        if (results) {
          results.forEach(async (doc) => {
            let data = await doc.data();
            data = { data, opportunityId: doc.id };
            return arr.push(data);
          });
        }
        resolve(arr);
      })
      .catch((err) => {
        resolve([]);
      });
  });
};
const getSubscribedUsers = async (data) => {
  const categories = data.categories;
  let resultArray = [];
  await asyncForEach(categories, async (cat) => {
    let users = [];
    let isChecked = -1;
    isChecked = resultArray.findIndex((el) => {
      return el.category === cat;
    });
    if (isChecked == -1) {
      let result = await firestore
        .collection("user_alerts")
        .where("categories", "array-contains", cat)
        .get();
      if (!result.empty) {
        result.docs.forEach((doc) => {
          let data = doc.data();
          users.push(data.userId);
        });
      }
    }
    users.length && resultArray.push({ category: cat, users, data });
  });
  return resultArray;
};

const checkDataToUpdate = async (updatedOpportunities, oldOpportunities) => {
  console.log("oldOpportunities",oldOpportunities , updatedOpportunities)
  let opportunities = updatedOpportunities.slice();
  let oppTobeUpdate = [];
  await asyncForEach(oldOpportunities, async (opp, idx) => {
    let oppIndex = -1;
    oppIndex = opportunities.findIndex((el) => {
      const checkOpp =
      el.companyName && opp.data.companyName &&  el.companyName.toLocaleLowerCase().trim() === opp.data.companyName.toLocaleLowerCase().trim()
      if (checkOpp) {
        if( el.opportunityName === opp.data.opportunityName){
        return true
        }else{
          return false
        }
      } else {
        if(el.opportunityName && opp.data.opportunityName && el.opportunityName.toLocaleLowerCase().trim() ===  opp.data.opportunityName.toLocaleLowerCase().trim()){
          return true;
        }
        if(el.label && opp.data.label && el.label === opp.data.label){
          return true;
        }
        if(el.Name && opp.data.Name && el.Name === opp.data.Name){
          return true;
        }
        else{
          return false;
        }
      }
    });
    if (oppIndex !== -1) {
      let opps = opportunities.splice(oppIndex, 1);
      let dataToUpdate = {
        data: opps[0],
        opportunityId: oldOpportunities[idx].opportunityId,
      };
      oppTobeUpdate.push(dataToUpdate);
    }
  });
  return { oppTobeUpdate, oppToAdd: opportunities };
};

const updateOpportunitiesData = async (data, table) => {
  var batch = firestore.batch();
  if (data.length) {
    await asyncForEach(data, async (doc) => {
      let id = doc.opportunityId,
      data = doc.data;
      var docRef = await firestore.collection(table).doc(id);
      await batch.update(docRef, data);
    });
    batch.commit();
  }
};

const addOpportunityData = async (data, table) => {

  var batch = firestore.batch();
  if (data.length) {
    await asyncForEach(data, async (doc) => {
      var docRef = await firestore.collection(table).doc(); //automatically generate unique id
      await batch.set(docRef, doc);
    });
    batch.commit();
  }
};

const sendMail = async (doc, userId) => {
  var result = await firestore
    .collection("users")
    .where("uid", "==", userId)
    .limit(1)
    .get();
  if (!result.empty) {
    const data = result.docs[0];
    const userDetail = data.data();
    let dataObj = {
      to: userDetail.email,
      subject: "subject",
      textbody: "textbody",
      parameters: doc,
    };
    store.dispatch(sendNewEmail(dataObj));
  }
};

const sendEmailToUsers = async (subscribeUsers) => {
  asyncForEach(subscribeUsers, async (data) => {
    await asyncForEach(data.users, async (userId) => {
      // const checkDate = data.opportunityDeadline
      await sendMail(data.data, userId);
    });
  });
};

export async function AddDataFromCSV(array, table) {
  let count = 0;
  if (table == "opportunities") {
    const oldOpportunities = await getOldOpportunities();
    let newOportunitiesArray = [];
    let subscribeUsers = [];
    //// modify data from CSV
 
    await asyncForEach(array, async (doc) => {
      let categories = [];
      count = count + 1;
      if (doc) {
        const categoryarr =
          (doc.opportunityCategory &&
            doc.opportunityCategory.split(",").map((el) => {
              return el.trim();
            })) ||
          [];
        let result;
       
        if (categoryarr.length > 0) {       
            result = await setCategories(categoryarr)     
        }
     

        const date = moment(doc.opportunityDeadline).isValid()
          ? new Date(doc.opportunityDeadline).getTime()
          : "";
        const prize =
          !doc.opportunityPrizeMoney
            ? "Other prizes"
            : doc.opportunityPrizeMoney.replace(/[$,]/g, "").trim();
        doc = {
          ...doc,
          categories: result || [],
          opportunityDeadline: date,
          opportunityPrizeMoney: isNaN(prize) ? prize : Number(prize),
        };
        newOportunitiesArray.push(doc);
     
      }
   
  });
    console.log('newOportunitiesArray',newOportunitiesArray)
    const data = await checkDataToUpdate(
      newOportunitiesArray.slice(),
      oldOpportunities
    );
    data && (await updateOpportunitiesData(data.oppTobeUpdate, table));
    data && (await addOpportunityData(data.oppToAdd, table));
    const newOppsArray = data.oppToAdd;
    if (newOppsArray.length) {
      await asyncForEach(newOppsArray, async (doc) => {
        if (subscribeUsers.length !== 0 && doc.categories.length !== 0) {
          await asyncForEach(subscribeUsers, async (users) => {
            let catIndex = doc.categories.findIndex((cat) => {
              return users.category === cat;
            });
            catIndex != -1 && doc.categories.splice(catIndex, 1);
            const result = await getSubscribedUsers(doc);
            result.length && subscribeUsers.push(...result);
          });
        } else {
          const result = await getSubscribedUsers(doc);
          result.length && subscribeUsers.push(...result);
        }
      });
    }
    sendEmailToUsers(subscribeUsers);
    return true;
   }
}

export async function getAllOpportunities(
  limitVal,
  resetlastVisible,
  activepage,
  current,
  cats
) {
  lastVisible = resetlastVisible ? undefined : lastVisible;
  let doc = [];
  let totaldata;
  let dataval;
  if (limitVal == 16) {
    let docRef = getOpportunitiesCollection().where(
      "opportunityDeadline",
      ">",
      Date.now()
    );
    let dbRef = firestore.collection("opportunities").orderBy("companyName");
    await docRef.get().then((snap) => {
      // resultlength = snap.size;
      doc.push(snap.docs);
      totaldata = snap.size;
      let size = snap.size; // will return the collection size
    });

    if (doc[0].length) {
      console.log(doc[0]);
      let index = activepage * limitVal - limitVal;
      let startVal = doc[0][index];
      dataval = startVal
        ? await docRef.startAt(startVal).limit(limitVal).get()
        : null;
    }

    return { data: dataval, resultlength, totaldata };
  } else {
    // if(limitVal === "all"){
    //   let dbRef = firestore.collection("opportunities").get()
    //   return dbRef;
    // }
    if(limitVal === 10){
      let dbRef = firestore.collection("opportunities").orderBy("opportunityDeadline", "desc").limit(limitVal).get();
      return dbRef;
    }
    let docRef = getOpportunitiesCollection();
    let dbRef = firestore.collection("opportunities").limit(limitVal).get();
    return dbRef;
  }
}

export const getLimitedOpportunities = async (limit, activePage , isAdminPage) => {
  let arr = [];
  let finalArray = [];
  let totaldata;
  let valRef = getOpportunitiesCollection();
  const fetchdata = await valRef
    .orderBy("opportunityDeadline", "desc")
    .get()
    .then((ress) => {
      return { doc: ress.docs, totaldata: ress.size };
    });

  for (let i = 0; i < activePage * limit; i++) {
    if (!!fetchdata.doc[i]) {
      arr.push(fetchdata.doc[i].data());
    }
  }
  var lastvalue = fetchdata.doc[arr.length - limit];
  console.log("lastvalue",lastvalue);
  if (arr.length) {
    let docRef = getOpportunitiesCollection();
    docRef = docRef
      .orderBy("opportunityDeadline", "desc")
      .startAt(lastvalue)
      .limit(limit);
    await docRef.get().then((res) => {
      if(isAdminPage){
        return res.docs.map((item) =>
        finalArray.push({ id: item.id, data: item.data() })
      );
      }
      return res.docs.map((item) =>
        finalArray.push({ opportunityId: item.id, ...item.data() })
      );
    });
  }

  return { data: finalArray, totaldata: fetchdata.totaldata };
};

export async function getAllCategories() {
  let docRef = getCategoriesCollection();
  return docRef
    .get()
    .then(function (results) {
      if (!results.empty) {
        return results;
      }
    })
    .catch(function (error) {
      return [];
    });
}

export async function getCurrrentOppsWithFilter(
  categories,
  limit,
  resetlastVisible,
  activepage
) {
  console.log(categories, limit, resetlastVisible);
  let doc = [];
  let dataval;
  let totaldata;
  lastVisible = resetlastVisible ? undefined : lastVisible;
  let docRef = firestore.collection("opportunities");
  // console.log("categoriescategories=", categories);
  docRef = docRef.where("categories", "array-contains-any", categories);
  docRef = docRef
    .where("opportunityDeadline", ">", Date.now())
    .orderBy("opportunityDeadline");
  if (limit == 16) {
    await docRef.get().then((snap) => {
      // console.log("doc", snap.size);
      doc.push(snap.docs);
      totaldata = snap.size;
      let size = snap.size; // will return the collection size
    });

    if (doc[0].length) {
      console.log(doc[0]);
      let index = activepage * limit - limit;
      let startVal = doc[0][index];

      dataval = startVal
        ? await docRef.startAt(startVal).limit(limit).get()
        : null;
      // console.log("dataval", startVal, limit);
    }

    return { data: dataval, totaldata };

    // let next = lastVisible
    //   // ? docRef.orderBy("opportunityDeadline").startAfter(lastVisible).limit(limit)
    //   ? docRef.orderBy("opportunityDeadline").startAt(lastVisible).limit(limit)
    //   : null;
    // var first = docRef.orderBy("opportunityDeadline").limit(limit);
    // if (lastVisible === "Fetched") {
    //   return;
    // }
    // if (!lastVisible) {
    //   return first
    //     .get().then(function (documentSnapshots) {
    //       lastVisible = documentSnapshots.docs[documentSnapshots.docs.length - 1];
    //       next = lastVisible
    //               // ? docRef.orderBy("opportunityDeadline").startAfter(lastVisible).limit(limit) : null;
    //               ?docRef.orderBy("opportunityDeadline").startAt(lastVisible).limit(limit) : null;
    //       if (!documentSnapshots.empty) {
    //         return { data: documentSnapshots, resultlength };
    //       }
    //     }).catch(err => {
    //       console.log("monika  errerrerr=", err)
    //     });
    // } else {
    //   return next
    //     .get().then((result) => {
    //       if (result.docs && !result.docs.length) {
    //         lastVisible = "Fetched";
    //         return;
    //       } else {
    //         lastVisible = result.docs[result.docs.length - 1];
    //         if (!result.empty) {
    //           return { data: result, resultlength };
    //         }
    //       }
    //     });
    // }
  } else {
    const data = docRef
      .limit(limit)
      .get()
      .then((result) => {
        return { data: result, resultlength };
      });
    return data;
  }
}


export function getOpportunitiesById(id) {
  return new Promise((resolve)=>{
    firestore
    .collection("opportunities")
    .doc(id)
    .get()
    .then((results) => {
      resolve(results.data())
    }).catch((err)=>{
      resolve(err)
          })
  })
}
export function getKeyPeopleById(id) {
  return new Promise((resolve)=>{
    firestore
    .collection("keyPerson")
    .doc(id)
    .get()
    .then((results) => {
      console.log("resultsresultsresultsresultsresults" , results.data() , id , results)
      resolve(results)
    }).catch((err)=>{
resolve(err)
    })
  })
}


// docRef = docRef
// .orderBy("opportunityDeadline", "desc")
// .startAt(lastvalue)
// .limit(limit);
// await docRef.get().then((res) => {
// if(isAdminPage){
//   return res.docs.map((item) =>
//   finalArray.push({ id: item.id, data: item.data() })
// );
// }
// return res.docs.map((item) =>
//   finalArray.push({ opportunityId: item.id, ...item.data() })
// );
// });


export async function getAllCompanies(
  limitVal , filterBy,activePage
) {
  let dbRef
  if(limitVal === "all"){
  
    let limit = 1;
    let arr = [];
    let valRef = getCompanieesCollection();
    const fetchdata = await valRef
      .orderBy(filterBy, "desc")
      .get()
      .then((ress) => {
        return { doc: ress.docs, totaldata: ress.size };
      });
  
    for (let i = 0; i < activePage * limit; i++) {
      if (!!fetchdata.doc[i]) {
        arr.push(fetchdata.doc[i].data());
      }
    }
    var lastvalue = fetchdata.doc[arr.length - limit];
    console.log()

    dbRef = firestore.collection("companies").orderBy(filterBy, "desc").startAt(lastvalue).limit(1).get();
  }else{
     dbRef = firestore.collection("companies").orderBy(filterBy, "desc").limit(limitVal).get();

  }
    return dbRef;
}

export async function getCompaniesByName(name) {
      let dbRef = firestore.collection("companies").where("companyName", "==", name).get();
    return dbRef
}
export async function updateOpportunitiesById(id , dataToUpdate) {
  console.log("id and dataToUpdate=====>" , id, dataToUpdate)
  let collectionRef = firestore.collection("opportunities");
  collectionRef.doc(id).set(dataToUpdate).then((res)=>{
  console.log("res afte opp update" , res)
  })
}

export async function deleteOpportunitiesById(id) {
  let collectionRef = firestore.collection("opportunities");
  collectionRef.doc(id).delete().then(() => {
    console.log("Document successfully deleted!");
}).catch((error) => {
    console.error("Error removing document: ", error);
});

}

export  function addOpportunities(data) {
  const opportunities = firestore.collection("opportunities").doc();
  console.log("opportunities to add " , opportunities ,data)
  opportunities.set(data);
}

export  async function searchOpportunityByName(name) {
  const opportunities = firestore.collection("opportunities")
    const data =  opportunities.where("opportunityName", "==", name).get()
      return data
 }

export  async function getNumberOfOpportunities() {
  let valRef = getOpportunitiesCollection();
  const fetchdata = await valRef.get().then((ress) => {
    return { totaldata: ress.size };
  });
      return fetchdata.totaldata
 }

 export  async function getNumberOfCompaniees() {
  let valRef = getCompanieesCollection();
  const fetchdata = await valRef.get().then((ress) => {
    return { totaldata: ress.size };
  });
      return fetchdata.totaldata
 }
