
import { SET_ALL_CATEGORIES,SET_USER_DETAIL,SET_OPPORTUNITIES } from "../constants";
  
  const defaultState = {
    allCategories: [],
    allOpportunities:[],
  };
  
  const dbDataReducer = (state = defaultState, action) => {
    switch (action.type) {
      case SET_ALL_CATEGORIES: {
        console.log("SET_ALL_CATEGORIES",action.payload)
      
        return {
          ...state,
          allCategories: action.payload
        };
      }
      case SET_OPPORTUNITIES: {
        console.log("SET_OPPORTUNITIES",action.payload)
        // let newOpps = allOpportunities.slice()
        return {
          ...state,
          allOpportunities: action.payload
        };
      }
      case SET_USER_DETAIL: {
        console.log("SET_USER_DETAIL",action.payload)
        return {
          ...state,
          userData: action.payload
        };
      }
      default:
        return state;
    }
  };
  
  export default dbDataReducer;
  