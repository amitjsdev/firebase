import action from "../action";

export const sendNewEmail = (data) => {
  return action({
    type: 'SEND_EMAIL',
    payload: {
      request: {
        url: `/api/email/send-email`,
        method: "POST",
        data,
      },
    },
  });
};