import action from "../action";

export const sendNewEmail = (data) => {
  console.log("sendNewEmaildatadatadatadata",data)
  return action({
    type: 'SEND_EMAIL',
    payload: {
      request: {
        url: `/api/email/send-email`,
        method: "POST",
        data,
      },
    },
  });
};






