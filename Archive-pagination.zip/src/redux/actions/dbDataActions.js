import action from "../action";
import {
    SET_OPPORTUNITIES, SET_ALL_CATEGORIES,SET_USER_DETAIL} from '../constants'


export const setAllOpportunities = (payload) => ({
    
    type: SET_OPPORTUNITIES,
    payload: payload,
});


export const setAllCategories = (payload) => ({
    type: SET_ALL_CATEGORIES,
    payload: payload,
});

export const setUserData = (payload)=>({
    type :SET_USER_DETAIL,
    payload: payload,
})