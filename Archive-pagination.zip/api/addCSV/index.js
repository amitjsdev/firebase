const csv = require('csvtojson');
const request=require('request')

const convertCSVData = async function (req, res) {

  // const url = 'https://firebasestorage.googleapis.com/v0/b/open-innovation-leads.appspot.com/o/InnocentiveChallengesDbUpload%20-%20Sheet1.csv?alt=media&token=bd59aff3-fab7-451f-b4ec-480d2e23de37';
  const url = req.body.url
  const arrayJson = [];
  csv()
  .fromStream(request.get(url))
  .subscribe((jsonObj) => {
    arrayJson.push({...jsonObj})
  
  }, (e => {
    console.log("catchcatch ==1", e)
    res.status(400).send({
      message: "Error converting CSV to JSON",
      error: e, status: 400
    });
  }), (result => {
        res.status(200).send({
      message: "Json for CSV File",
      data: arrayJson, status: 200
    });
  }))
};


module.exports.convertCSVData = convertCSVData;






