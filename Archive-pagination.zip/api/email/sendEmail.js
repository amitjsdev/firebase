const express = require("express");

const router = express.Router();
const emailControler = require("./index")

router.post("/send-email", emailControler.sendMailToUsers);
router.get("/test", async function (req, res) {
  res.send(JSON.stringify(process.env))
});

module.exports = router;


