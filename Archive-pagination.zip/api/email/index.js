var moment = require("moment");
var postmark = require("postmark");
var client = new postmark.Client("412a0f42-da90-40f8-909c-33307b2307a7");

// var client = new postmark.Client("ef980f52-fe7d-43a3-b105-d178e85a18ee");//mehak

const sendMailToUsers = async function (req, res) {
  const { parameters } = req.body;
  console.log("reqreqreqreq", req.body, req.body.subject, req.body.textbody);
  const opportunityDeadline =parameters &&  parameters.opportunityDeadline && moment(parameters.opportunityDeadline).format("MM/DD/YYYY") || ''
  // sendEmailWithTemplate
  client.sendEmailWithTemplate(
    {
      From: "neil@openinnovationleads.com",
      To: req.body.to,
      TemplateId: 21515542,//client
      // TemplateId: 21531402,//mehak
      TemplateAlias: "New Opportunity",
      TemplateModel: {
        user_name: "",
        companyName: parameters.companyName,
        opportunityName: parameters.opportunityName,
        opportunityCategory: parameters.opportunityCategory,
        opportunityDescription: parameters.opportunityDescription,
        opportunityPrizeMoney: parameters.opportunityPrizeMoney,
        opportunityURL: parameters.opportunityURL,
        opportunityDeadline:opportunityDeadline ,
        
      },
    },
    function (error, success) {
      if (error) {
        console.log("errorerror", error);
      } else {
        console.log("successsuccess", success);
      }
    }
  );
//   let result =await  client.sendEmail({
//     "From": "mkapoor@innow8apps.com",
//     "To": "mkapoor@innow8apps.com",
//     "Subject": "new mail",
//     "TextBody": "hello from postmark"
// });
// console.log("resultresult",result)
  // res.send("Successfully send");
};

module.exports.sendMailToUsers = sendMailToUsers;
