require("dotenv").config();
const express = require("express");
const path = require('path');

const stripeCreateBillingSession = require("./stripe-create-billing-session.js");
const stripeWebhook = require("./stripe-webhook.js");
const emailController = require("./email/sendEmail");
const csvController = require("./addCSV/readCSV");
var cors = require('cors')

const stripeCreateCheckoutSession = require("./stripe-create-checkout-session.js");

const app = express();

app.use(cors()) 
// // Get the raw body which is needed by Stripe webhook
const jsonOptions = {
  verify: (req, res, buf) => {
    if (buf && buf.length) {
      req.rawBody = buf.toString("utf8");
    }
  },
};

app.use(express.json(jsonOptions));
app.use(express.urlencoded({ extended: true }));

app.use("/api/stripe-create-billing-session", stripeCreateBillingSession);
app.use("/api/stripe-webhook", stripeWebhook);
app.use("/api/email", emailController);
app.use("/api/stripe-create-checkout-session", stripeCreateCheckoutSession);
app.use("/api/readcsv",csvController);
app.use(express.static(path.join(__dirname, '../build')));

app.get("*", function(request, response) {
  response.sendFile(path.join(__dirname + "/../build/index.html"));
});
app.listen(process.env.PORT || 8080, function () {
  console.log("Server listening on port 8080");
});
