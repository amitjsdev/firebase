import React, { Component } from 'react'
import PartnarWithUs from '../components/PartnerWithUs';

export class List extends Component {
  render() {
    return (
      <div>
        <PartnarWithUs/>
      </div>
    )
  }
}

export default List
