import React from "react";
import "../assets/style/main.scss";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Container, FormGroup, Label, Input } from "reactstrap";
import HomePage from "../components/Home";
import { Router as Route, Switch } from "@reach/router";
import login from "../pages/login";
import Layout from "../components/LayoutPage";
import List from "../pages/List";
import WishList from "../components/WishList";
import RoomDetails from "../components/RoomDetails";
import { navigate } from "gatsby";
import PartnerWithUs from "../components/PartnerWithUs";
import Admin from "../components/Admin/Index";
import AddRoom from "../components/Admin/addroom";
import EditData from "../components/Admin/Edit";
import CallBackRequest from "../components/CallBackRequest";
import Filters from "../components/RoomList/Filters";
import Register from "../components/Register";
import adminlogin from "../components/Admin/adminLogin.js";
import OTP from "../components/Login/otp";
import Detail from "../components/RoomList/Detail";
import AdminLogin from "../components/Admin/adminLogin.js";
// markup
const IndexPage = () => {
  const PrivateRoute = ({ component: Component, location, ...rest }) => {
    if (
      !localStorage.getItem("authentication") &&
      location.pathname !== "/login"
    ) {
      navigate("/login");
      return null;
    }
    return <Component {...rest} />;
  };
  const AdminPrivateRoute = ({ component: Component, location, ...rest }) => {
    if (
      !localStorage.getItem("isAdmin") &&
     // false &&
      location.pathname !== "/adminlogin"
    ) {
      navigate("/adminlogin");
      return null;
    }
    return <Component {...rest} />;
  };
  const PublicRoute = ({ component: Component, location, ...rest }) => {
    if (localStorage.getItem("authentication") && location.pathname !== "/") {
      navigate("/");
      return null;
    }
    return <Component {...rest} />;
  };

  return (
    <div>
      <Route>
        <HomePage path="/"></HomePage>
        <PublicRoute exact path="/login" component={login} />
        <AdminPrivateRoute path="/admin" component={Admin}></AdminPrivateRoute>
        {/* <Admin exact path ='/admin'></Admin> */}
        <AdminLogin exact path="/adminlogin"></AdminLogin>
        <AdminPrivateRoute
          path="/admin/Room"
          component={AddRoom}
        ></AdminPrivateRoute>
        <AdminPrivateRoute
          path="/admin/edit/:id"
          component={EditData}
        ></AdminPrivateRoute>
        <OTP exact path="/otp"></OTP>
        <RoomDetails path="/roomdetails"></RoomDetails>
        <PartnerWithUs exact path="/partner-with-us"></PartnerWithUs>
        <PublicRoute exact path="/register" component={Register}></PublicRoute>
        <CallBackRequest exact path="/requestCallBack"></CallBackRequest>
        <Detail exact path="/detail/:id"></Detail>
        <PrivateRoute path="/wishlist" component={WishList}></PrivateRoute>
        <List exact path="/:id" />
      </Route>
    </div>
  );
};

export default IndexPage;
