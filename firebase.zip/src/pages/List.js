import React, { Component } from "react";
import RoomList from "../components/RoomList";
import Layout from "../components/LayoutPage";

export class List extends Component {
  render() {
    return (
      <Layout>
        <RoomList {...this.props} />
      </Layout>
    );
  }
}

export default List;
