import React from "react";
import Login from "../components/Login";

function login() {
  return (
    <div className="login-page">
      <Login></Login>
    </div>
  );
}

export default login;
