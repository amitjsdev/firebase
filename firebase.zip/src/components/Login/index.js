import React, { useState,useHistory } from "react";
import { FormGroup, Input } from "reactstrap";
import axios from "axios";
import Otp from "../Login/otp.js";
import VerifyOtp from "./verifyOtp";
import LoginIcon from "../../assets/images/signin/login-icon.png";
import url from "../../Services/PostData";
import Close from "../../assets/images/admin/close.svg";
import { navigate } from "@reach/router";
import constant from "../../Services/constant.json"

function Login(props) {
   const history = useHistory();
  const [phone, setPhone] = useState("");
  const [phoneExists, setPhoneExists] = useState(false);
  const [val, setVal] = useState(false);

  const handleChange = (e) => {
    e.preventDefault();
    setPhone(e.target.value);
  };

  const verifyNumber = (event) => {
    if (phone) {
      localStorage.setItem("number", phone);
      navigate("/otp");
    }
  };

  const handleCloseOtp=()=>{
    navigate("/");
  }
  const handleEnterSubmit = (event) => {
    console.log("fffqw");
    if (event.key === "Enter") {
      if (phone) {
        localStorage.setItem("number", phone);
        navigate("/otp");
      }
    }
  };



  return (
    <>
      <div className="login-wrapper">
      <button className="close-btn" onClick={handleCloseOtp}>
          <img src={Close} />
        </button>
        <div className="icon">
          <img src={LoginIcon} />
        </div>

        <h2> {constant.Verification}</h2>
        <p>
          We will send you a <b>One time password</b> on your phone number{" "}
        </p>

        <div id="recaptcha-container"></div>
        <FormGroup className="mb-4">
          <Input
            type="number"
            placeholder="Enter your phone number"
            value={phone}
            onChange={handleChange}
            onKeyDown={handleEnterSubmit}
          />
        </FormGroup>

        <button onClick={verifyNumber} className="verify-btn">
          {" "}
          Get Otp
        </button>
      </div>
    </>
  );
}

export default Login;
