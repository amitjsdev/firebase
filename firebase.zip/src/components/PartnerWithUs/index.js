import React, { Component } from "react";
import {
  Button,
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Input,
  Label,
  DropdownButton,
  Dropdown,
} from "reactstrap";
// import { validateEmail } from "../../utils";
import InputComponent from "../InputComponent";
import useFirebase from "../../Services/firebase";
import imageToUpload from "../../assets/images/home/amenities-bg.png";
import Emailapi from "../PartnerWithUs/emailapi";
import { navigate } from "gatsby";
import Layout from "../LayoutPage";
import RightArrow from "../../assets/images/rooms/right-arrow.svg";
import FAQImage from "../../assets/images/rooms/faq-image.png";
import { validateEmail,mobileValidate } from "../../utils";
import constant from"../../Services/constant.json"


const firebase  = useFirebase();
export class Details extends Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      BedroomsProperty: "",
      PropertyAddress: "",
      GoogleLinkoftheproperty: "",
      username: "",
      email: "",
      mobilenumber: "",
      errorType: "",
      errorText: "",
      furnished: "Fully Furnished",
      location: "Chandigarh",
    };
  }
  clearError = () => {
    this.setState({
      errorType: "",
      errorText: "",
    });
  };

  inputHandler = (e) => {
    this.clearError();
    this.setState({ [e.target.name]: e.target.value });
  };
  handleSubmit = () => {
    const {
      username,
      BedroomsProperty,
      PropertyAddress,
      mobilenumber,
      email,
      GoogleLinkoftheproperty,
      furnished,
      location,
      text
    } = this.state;

    if (username === "") {
      this.setState({
        errorType: "username",
        errorText: "Please fill username",
      });
      return false;
    }
   
    if (email === "") {
      this.setState({
        errorType: "email",
        errorText: "Please enter email",
      });
      return false;
    }
    if (!validateEmail(email)) {
      this.setState({
        errorType: "email",
        errorText: "Invalid email",
      });
      return false;
    }
    if (mobilenumber === "") {
      this.setState({
        errorType: "mobilenumber",
        errorText: "Please fill mobilenumber",
        mobileValidate: ""
      });
      return false;
    }

    if (mobilenumber.length < 10) {
      this.setState({
        errorType: "mobilenumber",
        errorText: "mobilenumber should be of minimum 10 characters",
        mobileValidate: ""

      });
      return false;
    }
    if (!mobileValidate(text)) {
      this.setState({
        errorType: "mobilenumber",
        errorText: "Invalid mobilenumber",
        mobileValidate: ""
      });
      return false;
    }


    if (PropertyAddress === "") {
      this.setState({
        errorType: "PropertyAddress",
        errorText: "Please fill PropertyAddress",
      });
      return false;
    }

    if (BedroomsProperty === "") {
      this.setState({
        errorType: "BedroomsProperty",
        errorText: "please fill BedroomsProperty",
      });
      return false;
    }
    // if (GoogleLinkoftheproperty === "") {
    //   this.setState({
    //     errorType: "GoogleLinkoftheproperty",
    //     errorText: "please fill GoogleLinkoftheproperty",
    //   });
    //   return false;
    // }

    Emailapi({
      to: [{ name: username, email: "mohitmahajan020@gmail.com" }],
      subject: "Frequently Asked Questions",
      content: `<strong>Frequently Asked Questions</strong>
        <table>
        <tr><td><strong>Username:</strong></td><td>${username}</td></tr>
        <tr><td><strong>mobilenumber:</strong></td><td>${mobilenumber}</td></tr>
        <tr><td><strong>BedroomsProperty:</strong></td><td>${BedroomsProperty}</td></tr>
        <tr><td><strong>PropertyAddress:</strong></td><td>${PropertyAddress}</td></tr>
        <tr><td><strong>GoogleLinkoftheproperty:</strong></td><td>${
          GoogleLinkoftheproperty || ""
        }</td></tr>
        <tr><td><strong>furnished:</strong></td><td>${furnished}</td></tr>
        <tr><td><strong>location:</strong></td><td>${location}</td></tr>`,
    });
    return true;
  };

  handleChange = (event) => {
    this.setState({
      [event.target.name]: event.target.value,
      errorText: "",
    });
  };
  uploadImage = () => {
    const fileRef = !!firebase && firebase.storage().ref();
    var file = fileRef.child(imageToUpload);
    file
      .put(imageToUpload)
      .then(function (snapshot) {
        console.log("Uploaded a blob or file!", snapshot);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  render() {
    const { errorType, errorText } = this.state;
    console.log("this.state11", this.state);
    return (
      <Layout>
        <section className="FAQ-page-wrapper">
          <Container>
            <div className="FAQ-wrapper">
              <Row className="align-items-center">
                <Col lg={5}>
                  <div className="px-3 mb-lg-0 mb-4 faq-image">
                    <img src={FAQImage} className="img-fluid" />
                  </div>
                </Col>
                <Col lg={7}>
                  <h1>{constant.FrequentlyAskedQuestions}</h1>
                  <div>
                    <Row>
                      <Col md={6}>
                        <InputComponent
                          placeholder="Username"
                          type="username"
                          name="username"
                          label="Username"
                          onChange={this.handleChange}
                          value={this.state.username}
                          errorType={errorType}
                          errorText={errorText}
                        />
                      </Col>
                      <Col md={6}>
                        <InputComponent
                          placeholder="Email"
                          type="text"
                          name="email"
                          label="Email"
                          onChange={this.handleChange}
                          value={this.state.email}
                          errorType={errorType}
                          errorText={errorText}
                        />
                      </Col>
                      <Col md={6}>
                        <InputComponent
                          placeholder="Mobile Number"
                          type="number"
                          name="mobilenumber"
                          label="Mobile Number"
                          onChange={this.handleChange}
                          value={this.state.mobilenumber}
                          errorType={errorType}
                          errorText={errorText}
                        />
                      </Col>
                      <Col md={6}>
                        <InputComponent
                          placeholder="Bedrooms in the Property"
                          type="text"
                          name="BedroomsProperty"
                          label="Bedrooms Property"
                          onChange={this.handleChange}
                          value={this.state.BedroomsProperty}
                          errorType={errorType}
                          errorText={errorText}
                        />
                      </Col>
                      <Col md={6}>
                        <InputComponent
                          placeholder="Property Address"
                          type="PropertyAddress"
                          name="PropertyAddress"
                          label="Property Address"
                          onChange={this.handleChange}
                          value={this.state.PropertyAddress}
                          errorType={errorType}
                          errorText={errorText}
                        />
                      </Col>
                      <Col md={6}>
                        <Label>Google Link of the property</Label>
                        <Input
                          placeholder="Google Link of the property (OPTIONAL)"
                          type="GoogleLinkoftheproperty"
                          name="GoogleLinkoftheproperty"
                          label="Google Link of the property"
                          onChange={this.handleChange}
                          value={this.state.GoogleLinkoftheproperty}
                          errorType={errorType}
                          errorText={errorText}
                        />
                      </Col>
                      <Col md={6}>
                        <label>Location</label>
                        <div className="d-flex">
                          <Input
                            type="select"
                            City
                            name="location"
                            value={this.state.location}
                            onChange={this.handleChange}
                          >
                            <option value="Chandigarh">Chandigarh</option>
                          </Input>
                        </div>
                      </Col>
                      <Col md={6}>
                        <label>Occupancy</label>
                        <div>
                          <Input
                            type="select"
                            name="furnished"
                            value={this.state.furnished}
                            onChange={this.handleChange}
                          >
                            <option name="furnished" value="Fully Furnished">
                              Fully Furnished
                            </option>
                            <option name="furnished" value="Semi Furnished">
                              Semi Furnished
                            </option>
                          </Input>
                        </div>
                      </Col>
                    </Row>

                    <div className="form-group mt-5 text-center">
                      {this.state.error ? (
                        <p className="text-danger mb-3">{this.state.error}</p>
                      ) : null}
                      {this.state.error ? (
                        <p className=" mb-3">{this.state.error}</p>
                      ) : null}
                      <Button
                        onClick={this.handleSubmit}
                        color="theme"
                        className="submitBtn"
                      >
                        submit <img src={RightArrow} className="ml-2" />
                      </Button>
                    </div>
                  </div>
                </Col>
              </Row>
            </div>
          </Container>
        </section>
      </Layout>
    );
  }
}
export default Details;
