import React, { Component } from 'react';
import { navigate } from '@reach/router';
import axios from 'axios';

let baseUrl = require("../../Services/PostData").BaseUrl;

const Mailer = (data) => {
  try {
    if (!data) return;
    console.log("Mailer-data", data);
    // const body = {
    //   personalizations: [
    //     {
    //       // to: [
    //       //   {
    //       //     name: data.to.name,
    //       //     email: data.to.email,
    //       //   },
    //       //   //  {
    //       //   //   name: data.to.name,
    //       //   //   email: data.to.email,
    //       //   // },
    //       //   // {
    //       //   //   name: data.to.name,
    //       //   //   email: data.to.email,
    //       //   // }
    //       // ],
    //       to: data.to,
    //       subject: data.subject || '',
    //     },
    //   ],
    //   from: {
    //     name: 'mohit',
    //     email: 'mmahajaninnow8@gmail.com',
    //   },
    //   from: {
    //     name: 'mohit',
    //     email: 'mmahajaninnow8@gmail.com',
    //   },
    //   content: [
    //     {
    //       type: 'text/html',
    //       value: data.content || '',
    //     },
    //   ],
    // }

    const body = {
      personalizations: [
        {
          // to: [
          //   {
          //     name: data.to.name,
          //     email: data.to.email,
          //   },
          //   //  {
          //   //   name: data.to.name,
          //   //   email: data.to.email,
          //   // },
          //   // {
          //   //   name: data.to.name,
          //   //   email: data.to.email,
          //   // }
          // ],
          to: data.to,
          subject: data.subject || '',
        },
      ],
      from:'mmahajaninnow8@gmail.com',
      to: data.to,
      subject: data.subject || '',
      text: data.content,
    }

     axios.post(baseUrl + "/sendEmail",body ).then(
      (response) => {
        console.log("sendEmail response ", response);
      }
    ).catch((error) => {
      console.log('sendEmail errr:',error )
    });
    
    // console.log('Mailer-body', body);
    // axios.post('https://api.sendgrid.com/v3/mail/send', JSON.stringify(body), {
    //   headers: {
    //     'Content-Type': 'application/json',
    //     Authorization:
    //       'Bearer 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',
    //   },
    // }).then((res) => {
    //   console.log('axios res : ', res)
    //   //navigate('/')

    // }).catch(err => {
    //   console.log('axios err : ', err)
    // })
    // fetch('https://api.sendgrid.com/v3/mail/send', {
    //   method: 'POST',
      // headers: {
      //   'Content-Type': 'application/json',
      //   Authorization:
      //     'Bearer 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',
      // },
    //   body: JSON.stringify(body),
    // }).then(response => {
    //   console.log("responseresponse", response)
    //   navigate('/')

    // }).catch((error) => {
    //   console.log('send mail api error', error);
    // });
  } catch (error) {
    console.log('send mail try catch error', error);
  }
};

export default Mailer;


