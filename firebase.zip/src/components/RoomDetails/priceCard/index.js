import React from 'react';
import constant from "../../../Services/constant.json"

function priceCard(props) {
  const priceInfo = [{
    noOfSharings : 2,
    price : 5299,
  }]
  return (
    <>
    <div className="d-flex align-items-center justify-content-between" style={{maxWidth: "600px"}}>
      <h1> {constant.Pricing }</h1> 
      <h6> {constant.SeeAdditionalCharges</h6> 
    </div>
    {

    }
    <div> 

    </div>
    </>
  );
}

export default priceCard;