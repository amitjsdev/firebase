import React, { Component } from "react";
import { Button, CardBody, Container } from "reactstrap";
import { validateEmail } from "../../utils";
import InputComponent from "../InputComponent";
import { Card } from "reactstrap";
import Layout from "../LayoutPage";
import TeleCaller from "../../assets/images/telecaller.svg";
import constant from "../../Services/constant.json"
export class Details extends Component {
  render() {
    return (
      <Layout>
        <Container>
          <section>
            <Card>
              <CardBody>
                <div className="phone-wrapper">
                  <img src={TeleCaller} />
                  <div className="ml-3">
                    <h5 className="mb-0">
                      {constant.Callustoknowmore}</h5>
                    <p className="mb-0">
                      <a href="">123456789</a>
                    </p>
                  </div>
                </div>
              </CardBody>
            </Card>
          </section>
        </Container>
      </Layout>
    );
  }
}
export default Details;
