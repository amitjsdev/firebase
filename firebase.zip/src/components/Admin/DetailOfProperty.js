import React from "react";
import { Row, Col } from "reactstrap";
import Property from "./Property";
import InputComponent from "../InputComponent";

function DetailOfProperty(props) {
  const { handleProperty, PropertyDetail, errorType, errorText } = props;
  return (
    <Row>
      {Object.keys(PropertyDetail).map((item) => {
        console.log("item.NoofFloors", item, PropertyDetail[item]);
        return (
          <Col md={4}>
            <Property
              name={item}
              value={PropertyDetail[item] || ""}
              type="text"
              handleProperty={handleProperty}
              placeholder={item + "..."}
              errorType={errorType}
              errorText={errorText}
            />
          </Col>
        );

        // return (
        //   <>
        //     <Col md={4}>
        //       <Property
        //         name="NoofFloors"
        //         value={item.NoofFloors}
        //         type="number"
        //         handleProperty={handleProperty}
        //         placeholder="No. of floors..."
        //       />
        //     </Col>
        //     <Col md={4}>
        //       <Property
        //         name="LiftFacility"
        //         value={item.LiftFacility}
        //         type="text"
        //         handleProperty={handleProperty}
        //         placeholder="Lift Facility..."
        //       />
        //     </Col>
        //     <Col md={4}>
        //       <Property
        //         name="ParkingFacility"
        //         value={item.ParkingFacility}
        //         type="text"
        //         handleProperty={handleProperty}
        //         placeholder="Parking Facility..."
        //       />
        //     </Col>
        //     <Col md={4}>
        //       <Property
        //         name="CommonKitchen"
        //         value={item.CommonKitchen}
        //         type="text"
        //         handleProperty={handleProperty}
        //         placeholder="Common Kitchen..."
        //       />
        //     </Col>
        //     <Col md={4}>
        //       <Property
        //         name="No.ofSeparateCupboardsineachroom"
        //         value={item.NoofSeparateCupboardsineachroom}
        //         type="number"
        //         handleProperty={handleProperty}
        //         placeholder="No. of Separate Cupboards in each room..."
        //       ></Property>
        //     </Col>
        //     <Col md={4}>
        //       <Property
        //         name="LaundaryService"
        //         value={item.LaundaryService}
        //         type="text"
        //         handleProperty={handleProperty}
        //         placeholder="Laundary Service..."
        //       />
        //     </Col>
        //     <Col md={4}>
        //       <Property
        //         name="PropertyCaretaker"
        //         value={item.PropertyCaretaker}
        //         type="text"
        //         handleProperty={handleProperty}
        //         placeholder="Property Caretaker..."
        //       />
        //     </Col>
        //     <Col md={4}>
        //       <Property
        //         name="HouseKeepinginBedroom"
        //         value={item.HouseKeepinginBedroom}
        //         type="text"
        //         handleProperty={handleProperty}
        //         placeholder="House Keeping in Bedroom..."
        //       />
        //     </Col>
        //     <Col md={4}>
        //       <Property
        //         name="HouseKeepinginCommonarea"
        //         value={item.HouseKeepinginCommonarea}
        //         type="text"
        //         handleProperty={handleProperty}
        //         placeholder="House Keeping in common area..."
        //       />
        //     </Col>
        //     <Col md={4}>
        //       <Property
        //         name="ZomatoSwiggyServices"
        //         value={item.ZomatoSwiggyServices}
        //         type="text"
        //         handleProperty={handleProperty}
        //         placeholder="Zomato/Swiggy services..."
        //       />
        //     </Col>
        //     <Col md={4}>
        //       <Property
        //         name="UberOlaServices"
        //         value={item.UberOlaServices}
        //         type="text"
        //         handleProperty={handleProperty}
        //         placeholder="Uber/Ola services..."
        //       />
        //     </Col>
        //   </>
        // );
      })}
    </Row>
  );
}

export default DetailOfProperty;
