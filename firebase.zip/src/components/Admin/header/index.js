import React from "react";
import { Button } from "reactstrap";
import { Link, navigate } from "gatsby";

function Header(props) {
  const adminlogout = () => {
    localStorage.removeItem("isAdmin");
    navigate("/adminlogin");
  };
  return (
    <div className="admin-header">
      <Button onClick={adminlogout}>logout</Button>
    </div>
  );
}

export default Header;
