import React from 'react'
import CheckBox from "./CheckBox";
function Gender(props) {
  const { genderVal,handleAllChecked, handleCheckChieldElement } = props;
  console.log("DateSlotDateSlot", props);
  return (
    <div>
      <input
        type="checkbox"
        name="genderVal"
        value="genderVal"
        className="mr-2"
        onClick={handleAllChecked}
      />
      Gender: Check / Uncheck All
      <ul className="pl-0 list-unstyled">
        {genderVal && genderVal.map((Building) => {
          return (
            <CheckBox
              name="genderVal"
              handleCheckChieldElement={handleCheckChieldElement}
              {...Building}
            />
          );
        })}
      </ul>
    </div>
  );
}

export default Gender
