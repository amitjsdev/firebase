import React, { Component } from "react";
import { Button, Container, Card, CardBody } from "reactstrap";
import { validateEmail } from "../../../utils";
import InputComponent from "../../InputComponent";
import Axios from "axios";
import url from "../../../Services/PostData";
import { navigate } from "@reach/router";
import Layout from "../../LayoutPage";
import Loader from "../../Loader";
import constant from  "../../../Services/constant.json"
class AdminLogin extends Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      email: "",
      password: "",
      phonenumber: "",
      errorType: "",
      errorText: "",
      loader:false,
    };
  }
  clearError = () => {
    this.setState({
      errorType: "",
      errorText: "",
    });
  };

  inputHandler = (e) => {
    this.clearError();
    this.setState({ [e.target.name]: e.target.value });
  };
  handleSubmit = () => {
    console.log("15613132")
    const { password, email, phonenumber } = this.state;
    if (email === "") {
      this.setState({
        errorType: "email",
        errorText: "Please fill email id",
      });
      return false;
    }
    if (!validateEmail(email)) {
      this.setState({
        errorType: "email",
        errorText: "Invalid email",
      });
      return false;
    }
    if (password === "") {
      this.setState({
        errorType: "password",
        errorText: "Please fill password",
      });
      return false;
    }
    if (password.length < 6) {
      this.setState({
        errorType: "password",
        errorText: "Password should be of minimum 6 characters",
      });
      return false;
    }
    if (password === "") {
      this.setState({
        errorType: "password",
        errorText: "Please fill password",
      });
      return false;
    }
    if (password.length < 6) {
      this.setState({
        errorType: "password",
        errorText: "Password should be of minimum 6 characters",
      });
      return false;
    }
    this.setState({
      loader:true
    })
    this.apiHandle();
    return true;
  };

  handleChange = (event) => {
    this.setState({
      [event.target.name]: event.target.value,
      errorText: "",
    });
  };

  apiHandle = () => {
    const {loader}=this.state;
    Axios.get(url.BaseUrl + "/getadminCredentials").then((response) => {
      console.log("responsevuwevdul", response)
      response.data.map((data) => {
        if (
          data.email == this.state.email &&
          data.password == this.state.password
        ) {
          localStorage.setItem("isAdmin", true);
          this.setState({
            loader:false
          })
          navigate("/admin");
        }
      });
    });
  };

  render() {
    const { errorType, errorText ,loader} = this.state;
    return (
      <>
      {!loader ? (
      <Layout>
        <Container>
          <div className="admin-wrapper">
            <Card>
              <CardBody>
                <h1>{constant.AdminLogin}</h1>
                <div>
                  <InputComponent
                    placeholder="Email"
                    type="text"
                    name="email"
                    label="Email"
                    onChange={this.handleChange}
                    value={this.state.email}
                    errorType={errorType}
                    errorText={errorText}
                  />
                  <InputComponent
                    placeholder="Password"
                    type="password"
                    name="password"
                    label="Password"
                    onChange={this.handleChange}
                    value={this.state.password}
                    errorType={errorType}
                    errorText={errorText}
                  />
                  <div className="form-group mt-4">
                    {this.state.error ? (
                      <p className="text-danger mb-3">{this.state.error}</p>
                    ) : null}
                    {this.state.error ? (
                      <p className=" mb-3">{this.state.error}</p>
                    ) : null}
                    <Button
                      color="theme"
                      onClick={this.handleSubmit}
                      className="submit-btn"
                    >
                      Login
                    </Button>
                  </div>
                </div>
              </CardBody>
            </Card>
          </div>
        </Container>
      </Layout>):(<Loader/>)}
      </>
    );
  }
}

export default AdminLogin;
