import React from "react";
import CheckBox from "./CheckBox";
function Date(props) {
  const { DateSlot, handleAllChecked, handleCheckChieldElement } = props;
  console.log("DateSlotDateSlot", props);
  return (
    <div>
      <input
        type="checkbox"
        name="DateSlot"
        value="DateSlot"
        className="mr-2"
        onClick={handleAllChecked}
      />
      DateSlot: Check / Uncheck All
      <ul className="pl-0 list-unstyled">
        {DateSlot && DateSlot.map((Building) => {
          return (
            <CheckBox
              name="DateSlot"
              handleCheckChieldElement={handleCheckChieldElement}
              {...Building}
            />
          );
        })}
      </ul>
    </div>
  );
}

export default Date;
