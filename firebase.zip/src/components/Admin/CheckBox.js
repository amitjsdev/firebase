import React from "react";

const CheckBox = (props) => {
  return (
    <li>
      <input
        className="mr-2"
        key={props.id}
        name={props.name}
        onClick={props.handleCheckChieldElement}
        type="checkbox"
        checked={props.isChecked}
        value={props.value}
      />{" "}
      {props.value}
    </li>
  );
};

export default CheckBox;
