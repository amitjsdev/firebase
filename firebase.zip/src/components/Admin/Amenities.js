import React from "react";
import CheckBox from "./CheckBox";
import { Col, Row } from "reactstrap";

function Amenities(props) {
  const {
    BuildingLevel,
    Kitchen,
    Bedroom,
    Washroom,
    handleAllChecked,
    handleCheckChieldElement,
  } = props;
  return (
    <Row>
      <Col md={6}>
        <input
          type="checkbox"
          name="BuildingLevel"
          value="BuildingLevel"
          className="mr-2"
          onClick={handleAllChecked}
        />
        BuildingLevel: Check / Uncheck All
        {BuildingLevel.length > 0 && (
          <ul className="list-unstyled">
            {BuildingLevel && BuildingLevel.map((Building) => {
              return (
                <CheckBox
                  name="BuildingLevel"
                  handleCheckChieldElement={handleCheckChieldElement}
                  {...Building}
                />
              );
            })}
          </ul>
        )}
      </Col>
      <Col md={6}>
        <input
          type="checkbox"
          name="Bedroom"
          value="BuildingLevel"
          className="mr-2"
          onClick={handleAllChecked}
        />
        Bedroom: Check / Uncheck All
        {Bedroom&&Bedroom.length > 0 && (
          <ul className="list-unstyled">
            {Bedroom.map((Building) => {
              return (
                <CheckBox
                  name="Bedroom"
                  handleCheckChieldElement={handleCheckChieldElement}
                  {...Building}
                />
              );
            })}
          </ul>
        )}
      </Col>
      <Col md={6}>
        <input
          type="checkbox"
          name="Kitchen"
          value="BuildingLevel"
          className="mr-2"
          onClick={handleAllChecked}
        />
        Kitchen: Check / Uncheck All
        {Kitchen&&Kitchen.length > 0 && (
          <ul className="list-unstyled">
            {Kitchen.map((Building) => {
              return (
                <CheckBox
                  name="Kitchen"
                  handleCheckChieldElement={handleCheckChieldElement}
                  {...Building}
                />
              );
            })}
          </ul>
        )}
      </Col>
      <Col md={6}>
        <input
          type="checkbox"
          name="Washroom"
          value="BuildingLevel"
          className="mr-2"
          onClick={handleAllChecked}
        />
        Washroom: Check / Uncheck All
        {Washroom && Washroom.length > 0 && (
          <ul className="list-unstyled">
            {Washroom.map((Building) => {
              return (
                <CheckBox
                  name="Washroom"
                  handleCheckChieldElement={handleCheckChieldElement}
                  {...Building}
                />
              );
            })}
          </ul>
        )}
      </Col>
    </Row>
  );
}

export default Amenities;
