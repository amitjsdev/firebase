import React, { useEffect, useState } from "react";
import { Button, Row, Col, Table, Container, Card, CardBody } from "reactstrap";
import adminlogin from "../Admin/adminLogin.js";
import { Link, navigate } from "gatsby";
import axios from "axios";
import url from "../../Services/PostData";
import Edit from "../../assets/images/admin/edit.svg";
import Delete from "../../assets/images/admin/delete.svg";
import Slider from "react-slick";
import Header from "./header";
import Loader from "../Loader";

function Index() {
  const [data, setData] = useState("");
  const [loader,setLoader]=useState(false)
  let count = 1;
  const settings = {
    dots: false,
    arrow: false,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };
  useEffect(() => {
    setLoader(true)
    axios
      .get(url.BaseUrl + "/roomData")
      .then((response) => {
        console.log("ponse", response.data);
        setData(response.data);
        setLoader(false)
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const handleDelete = (item, index) => {
    axios.delete(url.BaseUrl + "/room/delete/" + item).then((response) => {
      console.log(response);
      let newArray = data.slice();
      newArray.splice(index, 1);
      setData(newArray);
    });
  };

  const handleEdit = (index) => {
    navigate("/admin/edit/" + data[index][0]);
  };

  return (
    <>
      <Header />
      <Container>
        {!loader ?(<div className="admin-wrapper">
          <Card>
            <CardBody>
              <div className="text-right">
                <Link to="/admin/Room" className="btn btn-theme">
                  Add Room  
                </Link>
              </div>

              <div>
                      
                <Table className="add-room-wrapper" responsive striped> 
                  <thead>
                    <tr>
                      <th>id</th>
                      <th>image</th>
                      <th>address</th>
                      <th>city</th>
                      {/* <th>price</th> */}
                      <th>createdAt</th>
                      <th>enable/disable</th>
                      <th>delete</th>
                      <th>edit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {!!data &&
                      data.map((item, index) => {
                        console.log("item :: ", item[1]);
                        console.log("item index:: ", index);
                        return (
                          <tr>
                            <td>{index + 1}</td>
                            <td>
                              <Slider {...settings}>
                                {item[1]?.image.map((value) => {
                                  // console.log("item[1]? .imag : ", item[1]?.image);
                                  // console.log("item[1]? value : ", value);

                                  if (!value.image) {
                                    return null;
                                  }

                                  return (
                                    <div>
                                      <img
                                        src={value.image}
                                        className="room-image img-fluid"
                                      />
                                    </div>
                                  );
                                })}
                              </Slider>
                            </td>
                            <td>{item[1]?.address}</td>
                            <td>{item[1]?.city}</td>
                            {/* <td>{item[1]?.price}</td> */}
                            <td>{item[1]?.createdAt}</td>
                            <td>{JSON.stringify(item[1].enable)}</td>
                            <td>
                              <Button
                                className="icon"
                                onClick={() => handleDelete(item[0], index)}
                              >
                                <img src={Delete} />
                              </Button>
                            </td>
                            <td>
                              <Button
                                className="icon"
                                onClick={() => handleEdit(index)}
                              >
                                <img src={Edit} />
                              </Button>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </Table>
                <Row>{}</Row>
              </div>
            </CardBody>
          </Card>
        </div>):(<Loader/>)}
      </Container>
    </>
  );
}

export default Index;
