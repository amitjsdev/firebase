import React, { Component } from "react";
import {
  Button,
  FormGroup,
  Label,
  FormText,
  Container,
  Row,
  Col,
  Input,
  CardBody,
  Card,
} from "reactstrap";
import { navigate } from "gatsby";
import { Redirect } from "@reach/router";
import Switch from "react-switch";
// import { validateEmail } from "../../utils";
import InputComponent from "../InputComponent";
import useFirebase from "../../Services/firebase";
import axios from "axios";
import Layout from "../LayoutPage";
import MinusIcon from "../../assets/images/admin/minus.svg";
import PlusIcon from "../../assets/images/admin/plus.svg";
import DetailOfProperty from "./DetailOfProperty";
import DateSlot from "./Date";
import Amenities from "./Amenities";
import Gender from "./Gender";
import Loader from "../Loader";
import firebaseComponent from "@firebase/app";
import { introspectionFromSchema } from "graphql";
import {validateEmail} from "../../utils"
import constant from "../../Services/constant.json"

var DatePicker = require("reactstrap-date-picker");
const firebase = useFirebase();

let url = require("../../Services/PostData");
class addRoom extends Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      BedroomsProperty: "",
      address: "",
      loader: false,
      GoogleLinkoftheproperty: "",
      username: "",
      price: "",
      errorImage: "",
      RoomCompleteDetail: [],
      errorType: "",
      errorText: "",
      email: "",
      Male: false,
      Female: false,
      formattedValue:"",
      errorname: "",
      loader:true,
      firebaseImageURl: [],
      city: "",
      inputValues: [{ id: 1, image: "" }],
      DateSlot: [
        { id: 1, value: "9 AM-12 PM", isChecked: false },
        { id: 2, value: "12 PM-3 PM", isChecked: false },
        { id: 3, value: "3 PM-6 PM", isChecked: false },
        { id: 4, value: "6 PM-9 PM", isChecked: false },
      ],
      genderVal: [
        { id: 1, value: "Male", isChecked: false },
        { id: 2, value: "Female", isChecked: false },
      ],
      priceValues: [
        {
          id: 1,
          NoOfRoom: "",
          RoomType: "",
          NoofBed: "",
          BedType: "",
          ACType: "NON- AC ROOM",
          price: "",
        },
      ],
      occupancy: "Single",
      val: false,
      value:"",
      checked: true,
      formattedValue: "",
      BuildingLevel: [
        { id: 1, value: "Free wifi", isChecked: false },
        { id: 2, value: "washing Machine", isChecked: false },
        { id: 3, value: "Fire Extinguisher", isChecked: false },
        { id: 4, value: "Limited Power Backup", isChecked: false },
        { id: 5, value: "CCtv", isChecked: false },
      ],
      Bedroom: [
        { id: 1, value: "AC", isChecked: false },
        { id: 2, value: "Bed & Metress", isChecked: false },
      ],
      Kitchen: [
        { id: 1, value: "Refrigerator", isChecked: false },
        { id: 2, value: "Microwave", isChecked: false },
        { id: 3, value: "Induction Plate", isChecked: false },
        { id: 4, value: "Cookware", isChecked: false },
      ],
      Washroom: [{ id: 1, value: "Geyser", isChecked: false }],
      PropertyDetail: {
        "Property Type": "",
        "No. of Floors": "",
        "Lift Facility": "",
        "Parking Facility": "",
        "Common Kitchen": "",
        "No. of Separate Cupboards in each room": "",
        "Laundary Service": "",
        "Property Caretaker": "",
        "House Keeping in Bedroom": "",
        "House Keeping in common area": "",
        "Zomato/Swiggy services": "",
        "Uber/Ola services": "",
      },
    };
  }

  componentDidMount=()=>{
    this.setState({
      loader:false
    })
  }
  clearError = () => {
    this.setState({
      errorType: "",
      errorText: "",
    });
  };

  inputHandler = (e) => {
    this.clearError();
    this.setState({ [e.target.name]: e.target.value });
  };
  handleSubmit = async (id) => {
    const {
      username,
      address,
      price,
      priceValues,
      inputValues,
      value,
      city,
      email,
      PropertyDetail,
    } = this.state;
    console.log(
      "231321231",
      priceValues,
      PropertyDetail["Property Type"] === ""
    );

    if (username === "") {
      this.setState({
        errorType: "username",
        errorText: "Please fill username",
      });
      return false;
    }
    if (address === "") {
      this.setState({
        errorType: "address",
        errorText: "Please fill address",
      });
      return false;
    }
    if (city === "") {
      this.setState({
        errorType: "city",
        errorText: "Please fill city",
      });
      return false;
    }
    if (price === "") {
      this.setState({
        errorType: "price",
        errorText: "Please fill price",
      });
      return false;
    }
    if (email === "") {
      this.setState({
        errorType: "email",
        errorText: "Please enter email",
        validateEmail:""

      });
      return false;
    }
    if (!validateEmail(email)) {
      this.setState({
        errorType: "email",
        errorText: "Invalid email",
        validateEmail:""
      });
      return false;
    }
    if (inputValues[0].image === "") {
      this.setState({
        errorImage: "Please upload Image",
      });
      return false;
    }
    if (value == "") {
      this.setState({
        errorname: "formattedValue",
        errorText: "Select the Date",
      });
      return;
    }
    this.handleApi();
    return true;
  };

  handleApi = async () => {
    const {
      username,
      address,
      price,
      city,
      priceValues,
      occupancy,
      PropertyDetail,
      BuildingLevel,
      inputValues,
      firebaseImageURl,
      Kitchen,
      Bedroom,
      email,
      Male,
      Female,
      Washroom,
      DateSlot,
      genderVal,
      value,
      checked,
    } = this.state;
    console.log("priceValues1111", inputValues);
    let data = {
      username: username,
      address: address,
      city: city,
      price:Number(price),
      priceValues: priceValues,
      image: inputValues,
      occupancy: occupancy,
      Property: PropertyDetail,
      BuildingLevel: BuildingLevel,
      Kitchen: Kitchen,
      Bedroom: Bedroom,
      Washroom: Washroom,
      Male,
      Female,
      DateSlot: DateSlot,
      gender: genderVal,
      value,
      email,
      checked,
      wishlist: [],
    };
    console.log(data);
    await axios
      .post(url.BaseUrl + "/addRooms/" + city, data)
      .then((response) => {
        console.log("diycticdyicdiyew", response);
        console.log("response", response);
        navigate("/admin");
      })
      .catch((error) => {
        console.log("error", error);
      });
  };

  imageUpload = () => {
    const { inputValues, firebaseImageURl } = this.state;
    inputValues.map((item) => {
      console.log("inputElement====", inputElement);
      const inputElement = document.getElementById(`${item.id}`).files[0];
      return <>{inputElement && this.uploadImage(inputElement)}</>;
    });
    this.setState({
      firebaseImageURl: firebaseImageURl,
    });
    console.log("dss", firebaseImageURl);
  };

  handleChange = (event) => {
    this.setState({
      [event.target.name]: event.target.value,
      errorText: "",
    });
  };

  handleCardChange = (event, index) => {
    console.log("eventevent", event.target.name, index, event.target.value);
    let arra = this.state.priceValues;
    arra[index][event.target.name] = event.target.value;
    console.log("arrarr", arra[index][event.target.name], arra);
    this.setState({
      priceValues: arra,
    });
  };

  handleDate(value1, formattedValue) {
    this.setState({
      value: value1, // ISO String, ex: "2016-11-19T12:00:00.000Z"
      //formattedValue: formattedValue // Formatted String, ex: "11/19/2016"
      errorname:""
    });
  }

  handleSwitch() {
    this.setState({ checked: !this.state.checked });
  }

  uploadImage = async (imagefile, index) => {
    console.log(imagefile);
    const { firebaseImageURl, inputValues } = this.state;
    let arr = [...inputValues];
    const fileRef = !!firebase && firebase.storage().ref();
    var file = await fileRef.child(imagefile.name);
    await file
      .put(imagefile)
      .then(function (snapshot) {
        console.log("Uploaded a blob or file!", snapshot);
      })
      .catch((error) => {
        console.log(error);
      });
    !!firebase &&
      firebase
        .storage()
        .ref()
        .child(imagefile.name)
        .getDownloadURL()
        .then((fireBaseUrl) => {
          arr[index]["image"] = fireBaseUrl;
          console.log("kkk", arr);
          this.setState({ inputValues: arr, disable: false });
        });
  };

  handleInputAdd = () => {
    const { inputValues } = this.state;
    const newId = Math.max(...inputValues.map((o) => o.id), 0) + 1;
    let tempArray = [...inputValues];
    tempArray.push({ id: newId });
    this.setState({ inputValues: tempArray });
  };

  handleInputRemove = (id) => {
    const { inputValues, RoomCompleteDetail } = this.state;
    let tempArray = [...inputValues].filter((previous) => previous.id !== id);
    this.setState({ inputValues: tempArray });
  };

  handlePriceAdd = () => {
    const { priceValues } = this.state;
    const newPrice = Math.max(...priceValues.map((o) => o.id), 0) + 1;
    let tempPrice = [...priceValues];
    tempPrice.push({
      id: newPrice,
      NoOfRoom: "",
      RoomType: "",
      NoofBed: "",
      BedType: "",
      ACType: "",
      price: "",
    });
    this.setState({ priceValues: tempPrice });
  };

  handlePriceRemove = (id) => {
    const { priceValues } = this.state;
    let tempArray = [...priceValues].filter((previous) => previous.id !== id);
    //let RoomDetail=[...RoomCompleteDetail].filter((item)=>item.id !== id)
    console.log("RoomDetail", tempArray);
    this.setState({ priceValues: tempArray });
  };

  handleAllChecked = (event) => {
    console.log(
      "event.target.checked",
      event.target.checked,
      event.target.name
    );
    let BuildingLevel = this.state[event.target.name];
    BuildingLevel.forEach(
      (Building) => (Building.isChecked = event.target.checked)
    );
    this.setState({ [event.target.name]: BuildingLevel });
    if (event.target.name == "genderVal") {
      this.setState({
        Male: event.target.checked,
        Female: event.target.checked,
      });
    }
  };
  handleCheckChieldElement = (event) => {
    console.log("zxcv", event.target.value, event.target.checked);
    let BuildingLevel = this.state[event.target.name];
    BuildingLevel.forEach((Building) => {
      if (Building.value === event.target.value)
        Building.isChecked = event.target.checked;
    });
    this.setState({ [event.target.name]: BuildingLevel });
    if (event.target.name == "genderVal") {
      this.setState({
        [event.target.value]: event.target.checked,
      });
    }
  };

  handleProperty = (event) => {
    let Property = { ...this.state.PropertyDetail };
    Property[event.target.name] = event.target.value;
    console.log("Property====", Property);
    this.setState({
      PropertyDetail: Property,
    });
  };

  imageHandle = (id, index) => {
    this.setState({
      disable:true,
      errorImage:""
    });
    const inputElement = document.getElementById(`${id}`).files[0];
    console.log("dddd231", inputElement, index);
    this.uploadImage(inputElement, index);
  };

  render() {
    const {
      errorType,
      errorText,
      inputValues,
      val,
      loader,
      priceValues,
      PropertyDetail,
      errorname,
      errorImage,
    } = this.state;
    console.log("priceValues", this.state);
    if (val) {
      debugger;
      return <Redirect path="/admin"></Redirect>;
    }
    return (
      // <Layout>
        <Container>
          {!loader?(<div className="admin-wrapper">
            {/* {true && <Loader />} */}
            <Card>
              <CardBody>
                <h1>{constant.Owner}</h1>
                <Row>
                  <Col md={6}>
                    <InputComponent
                      placeholder="owner"
                      type="username"
                      name="username"
                      label="Owner"
                      onChange={this.handleChange}
                      value={this.state.username}
                      errorType={errorType}
                      errorText={errorText}
                    />
                  </Col>
                  <Col md={6}>
                    <InputComponent
                      placeholder="Email"
                      type="Text"
                      name="email"
                      label="Email"
                      onChange={this.handleChange}
                      value={this.state.email}
                      errorType={errorType}
                      errorText={errorText}
                    />
                  </Col>
                  <Col md={6}>
                    <InputComponent
                      placeholder="address"
                      type="text"
                      name="address"
                      label="Address"
                      onChange={this.handleChange}
                      value={this.state.address}
                      errorType={errorType}
                      errorText={errorText}
                    />
                  </Col>
                  <Col md={6}>
                    <InputComponent
                      placeholder="city"
                      type="city"
                      name="city"
                      label="City"
                      onChange={this.handleChange}
                      value={this.state.city}
                      errorType={errorType}
                      errorText={errorText}
                    />
                  </Col>
                  <Col sm={6}>
                    <InputComponent
                      placeholder="price"
                      label="Price"
                      type="Number"
                      name="price"
                      onChange={this.handleChange}
                      value={this.state.price}
                      errorType={errorType}
                      errorText={errorText}
                    />
                  </Col>
                  <Col md={6}>
                    <FormGroup>
                      <Label>{constant.Calender}</Label>
                      <DatePicker
                        id="example-datepicker"
                        value={this.state.value}
                        onChange={(v, f) => this.handleDate(v, f)}
                      />
                      {errorname == "formattedValue" && (
                        <span className="form-error text-danger">
                          {this.state.errorText}
                        </span>
                      )}
                    </FormGroup>
                  </Col>
                  <Col md={6}>
                    <Row>
                      <Col md={9}>
                        <label>{constant.Occupancy}</label>
                        <Input
                          type="select"
                          name="occupancy"
                          value={this.state.occupancy}
                          onChange={this.handleChange}
                        >
                          <option name="Single">Single</option>
                          <option name="Double">Double</option>
                          <option name="Triple">Triple</option>
                          <option name="Quadraple">Quadraple</option>
                        </Input>
                      </Col>
                    </Row>
                  </Col>
                  <Col md={6}>
                    {inputValues.map((item, index) => {
                      console.log("iii", item.id);
                      return (
                        <>
                          <div className="image-upload-wrapper mb-2">
                            <div className="image-upload">
                              <input
                                type="file"
                                id={item.id}
                                name="avatar"
                                accept="image/png, image/jpeg"
                                onChange={() =>
                                  this.imageHandle(item.id, index)
                                }
                              ></input>
                              <Button
                                id="button"
                                disabled={this.state.disable}
                                onClick={this.handleInputAdd}
                                className="icon"
                              >
                                <img src={PlusIcon} />
                              </Button>
                              {index > 0 && (
                                <Button
                                  id="button"
                                  disabled={this.state.disable}
                                  className="icon ml-2"
                                  onClick={() =>
                                    this.handleInputRemove(item.id, index)
                                  }
                                >
                                  <img src={MinusIcon} />
                                </Button>
                              )}
                            </div>
                            <div className="uploaded-image">
                              <img src={item.image || ""} />
                            </div>
                          </div>
                          {errorImage && (
                            <span className="form-error text-danger">
                              {errorImage}
                            </span>
                          )}
                        </>
                      );
                    })}
                  </Col>
                </Row>
                <Row className="mt-4">
                  <Col md={12}>
                    <h1>{constant.RoomInformationForDailyPackages}</h1>
                    {priceValues.map((item, index) => {
                      return (
                        <>
                          <div
                            id={item.id}
                            className="room-information-wrapper"
                          >
                            <Row>
                              <Col md={4}>
                                <InputComponent
                                  placeholder="No. of Rooms"
                                  type="Number"
                                  name="NoOfRoom"
                                  label="No. of Rooms"
                                  onChange={(e) =>
                                    this.handleCardChange(e, index)
                                  }
                                  value={item.NoOfRoom}
                                  errorType={errorType}
                                  errorText={errorText}
                                />
                              </Col>
                              <Col md={4}>
                                <InputComponent
                                  placeholder="Rooms"
                                  type="text"
                                  name="RoomType"
                                  label="Room Type"
                                  onChange={(e) =>
                                    this.handleCardChange(e, index)
                                  }
                                  value={item.RoomType}
                                  errorType={errorType}
                                  errorText={errorText}
                                />
                              </Col>
                              <Col md={4}>
                                <InputComponent
                                  placeholder="No. of Rooms"
                                  type="Number"
                                  name="NoofBed"
                                  label="No. of beds"
                                  onChange={(e) =>
                                    this.handleCardChange(e, index)
                                  }
                                  value={item.NoofBed}
                                  errorType={errorType}
                                  errorText={errorText}
                                />
                              </Col>
                              <Col md={4}>
                                <InputComponent
                                  type="select"
                                  name="BedType"
                                  label="Bed Type"
                                  value={item.BedType}
                                  onChange={(e) =>
                                    this.handleCardChange(e, index)
                                  }
                                  errorType={errorType}
                                  errorText={errorText}
                                >
                                  <option name="Single">Single</option>
                                  <option name="Large Bed">Large Bed</option>
                                </InputComponent>
                              </Col>
                              <Col md={4}>
                                <InputComponent
                                  placeholder="Price per bed"
                                  type="Number"
                                  name="price"
                                  label="Price per bed"
                                  onChange={(e) =>
                                    this.handleCardChange(e, index)
                                  }
                                  value={item.price}
                                  errorType={errorType}
                                  errorText={errorText}
                                />
                              </Col>
                              <Col md={4}>
                                <InputComponent
                                  type="select"
                                  name="ACType"
                                  label="AC ROOM/NON- AC ROOM"
                                  value={item.ACType}
                                  onChange={(e) =>
                                    this.handleCardChange(e, index)
                                  }
                                  errorType={errorType}
                                  errorText={errorText}
                                >
                                  <option name="NON- AC ROOM">
                                    NON- AC ROOM
                                  </option>
                                  <option name="AC ROOM">AC ROOM</option>
                                </InputComponent>
                              </Col>
                              <Col md={12}>
                                <Button
                                  id="button"
                                  onClick={() => this.handlePriceAdd()}
                                  className="icon"
                                >
                                  <img src={PlusIcon} />
                                </Button>
                                {index > 0 && (
                                  <Button
                                    id="button"
                                    className="icon ml-2"
                                    onClick={() =>
                                      this.handlePriceRemove(item.id)
                                    }
                                  >
                                    <img src={MinusIcon} />
                                  </Button>
                                )}
                              </Col>
                            </Row>
                          </div>
                        </>
                      );
                    })}
                  </Col>
                </Row>

                <Row className="mt-4">
                  <Col md={12}>
                    <h1>{constant.DateSchedule}</h1>
                    <DateSlot
                      handleAllChecked={this.handleAllChecked}
                      handleCheckChieldElement={this.handleCheckChieldElement}
                      DateSlot={this.state.DateSlot}
                    ></DateSlot>
                  </Col>
                </Row>
                <Row className="mt-4">
                  <Col md={12}>
                    <h1>{constant.Gender}</h1>
                    <Gender
                      handleAllChecked={this.handleAllChecked}
                      handleCheckChieldElement={this.handleCheckChieldElement}
                      genderVal={this.state.genderVal}
                    ></Gender>
                  </Col>
                </Row>

                <Row>
                  <Col md={12}>
                    <h1>{constant.Amenties}</h1>
                    <Amenities
                      handleAllChecked={this.handleAllChecked}
                      handleCheckChieldElement={this.handleCheckChieldElement}
                      BuildingLevel={this.state.BuildingLevel}
                      Kitchen={this.state.Kitchen}
                      Bedroom={this.state.Bedroom}
                      Washroom={this.state.Washroom}
                    />
                  </Col>
                </Row>

                <Row>
                  <Col md={12}>
                    <h1>{constant.Abouttheproperty}</h1>
                    <DetailOfProperty
                      PropertyDetail={PropertyDetail}
                      handleProperty={this.handleProperty}
                      errorType={errorType}
                      errorText={errorText}
                    />
                  </Col>
                </Row>

                <Row>
                  <Col md={3}>
                    <label>
                      <p className="mb-2">Enable</p>
                      <Switch
                        onChange={() => this.handleSwitch()}
                        checked={this.state.checked}
                      />
                    </label>
                  </Col>
                </Row>

                <div className="form-group mt-4">
                  {this.state.error ? (
                    <p className="text-danger mb-3">{this.state.error}</p>
                  ) : null}
                  {this.state.error ? (
                    <p className="mb-3">{this.state.error}</p>
                  ) : null}
                  <Button
                    color="theme"
                    className="submit-btn"
                    onClick={() => this.handleSubmit()}
                  >
                    submits
                  </Button>
                </div>
              </CardBody>
            </Card>
          </div>):(<Loader/>)}
        </Container>
      // </Layout>
    );
  }
}
export default addRoom;
