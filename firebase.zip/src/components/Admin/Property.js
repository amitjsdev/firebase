import React from 'react'
import {Input} from 'reactstrap'
function Property(props) {
  const {name,type,handleProperty,placeholder,value}=props;
  return (
    <div>
      <label>{name}</label>
     <Input name={name}  value={value} type={type} onChange={handleProperty} placeholder={placeholder}></Input><br/>
    
    </div>
  )
}

export default Property
