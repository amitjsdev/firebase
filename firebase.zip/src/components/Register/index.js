import React, { Component } from "react";
import { Button, Input } from "reactstrap";
import { validateEmail } from "../../utils";
import InputComponent from "../InputComponent";
import axios from "axios";
import { navigate } from "gatsby";
import Loader from "../Loader";
import url from "../../Services/PostData";
import constant from "../../Services/constant.json"
class Register extends Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      email: "",
      username: "",
      phonenumber: "",
      loader:true,
      errorType: "",
      errorText: "",
    };
  }

  componentDidMount=()=>{
    this.setState({
      loader:false
    })
  }

  clearError = () => {
    this.setState({
      errorType: "",
      errorText: "",
    });
  };

  inputHandler = (e) => {
    this.clearError();
    this.setState({ [e.target.name]: e.target.value });
  };
  handleSubmit = () => {
    const { username, email, phonenumber } = this.state;

    if (username === "") {
      this.setState({
        errorType: "username",
        errorText: "Please fill username",
      });
      return false;
    }
    if (email === "") {
      this.setState({
        errorType: "email",
        errorText: "Please fill email id",
      });
      return false;
    }
    if (!validateEmail(email)) {
      this.setState({
        errorType: "email",
        errorText: "Invalid email",
      });
      return false;
    }
    if (phonenumber === "") {
      this.setState({
        errorType: "phonenumber",
        errorText: "Please fill phonenumber",
      });
      return false;
    }
    if (phonenumber.length < 10) {
      this.setState({
        errorType: "phonenumber",
        errorText: "phonenumber should be of minimum 10 characters",
      });
      return false;
    }
    let phone = `+91${phonenumber}`;
    let data = { id: phone, name: username, email: email, phoneNumber: phone };

    axios
      .post(url.BaseUrl + "/api/create", data)
      .then((response) => {
        localStorage.setItem("authentication", true);
        localStorage.setItem("name", username);
        localStorage.setItem("email", email);
        //localStorage.setItem("number",phone)
        navigate("/");
        return true;
      })
      .catch((error) => {
        console.log(error);
      });
  };
  handleChange = (event) => {
    this.setState({
      [event.target.name]: event.target.value,
      errorText: "",
    });
  };

  render() {
    const { errorType, errorText,loader } = this.state;
    return (
      <div className="login-page">
        {!loader?(<div className="login-wrapper">
          <h2 className="mb-4">Registration page</h2>
          <InputComponent
            placeholder="Username"
            type="username"
            name="username"
            onChange={this.handleChange}
            value={this.state.username}
            errorType={errorType}
            errorText={errorText}
          />

          <InputComponent
            placeholder="Email"
            type="text"
            name="email"
            onChange={this.handleChange}
            value={this.state.email}
            errorType={errorType}
            errorText={errorText}
          />

          <InputComponent
            placeholder="phonenumber"
            type="number"
            name="phonenumber"
            onChange={this.handleChange}
            value={this.state.phonenumber}
            errorType={errorType}
            errorText={errorText}
            // onKeyDown={(e) => {
            //   this.enterSubmit(e);
            // }}
          />

          {this.state.error ? (
            <p className="text-danger">{this.state.error}</p>
          ) : null}
          {this.state.error ? <p>{this.state.error}</p> : null}
          <Button onClick={this.handleSubmit} className="verify-btn">
            Register
          </Button>
        </div>):(<Loader/>)}
      </div>
    );
  }
}
export default Register;
