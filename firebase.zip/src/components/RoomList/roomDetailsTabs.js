import React, { useEffect, useState } from "react";
import {
  Button,
  Container,
  Contaner,
  Row,
  Col,
  Card,
  CardBody,
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
  CardTitle,
  CardText,
} from "reactstrap";
import classnames from "classnames";
import constant from "../../Services/constant.json"

function RoomDetailsTabs(props) {
  const [activeTab, setActiveTab] = useState("1");

  const toggle = (tab) => {
    if (activeTab !== tab) setActiveTab(tab);
  };
  return (
    <div>
      <Nav tabs className="room-details-tabs">
        <NavItem>
          <NavLink
            className={classnames({ active: activeTab === "1" })}
            onClick={() => {
              toggle("1");
            }}
          >
            Commute
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            className={classnames({ active: activeTab === "2" })}
            onClick={() => {
              toggle("2");
            }}
          >
            Food
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            className={classnames({ active: activeTab === "3" })}
            onClick={() => {
              toggle("3");
            }}
          >
            Essentials
          </NavLink>
        </NavItem>
        <NavItem>
          <NavLink
            className={classnames({ active: activeTab === "4" })}
            onClick={() => {
              toggle("4");
            }}
          >
            Lifestyle
          </NavLink>
        </NavItem>
      </Nav>
      <TabContent activeTab={activeTab}>
        <TabPane tabId="1">
          <Row>
            <Col sm="12">
              <div className="nearby-content">
                <div className="d-flex justify-content-between address-row">
                  <p className="name">{constant.PatelNagar}</p>
                  <div className="address-distance">
                    <p className="distance position-relative">0.93 kms</p>
                    <p className="show">{constant.ShowonMap}</p>
                  </div>
                </div>
                <div className="d-flex justify-content-between address-row">
                  <p className="name">{constant.chandigarh} </p>
                  <div className="address-distance">
                    <p className="distance position-relative">0.93 kms</p>
                    <p className="show">{constant.ShowonMap}</p>
                  </div>
                </div>
                <div className="d-flex justify-content-between address-row">
                  <p className="name">{constant.PatelNagar}</p>
                  <div className="address-distance">
                    <p className="distance position-relative">0.93 kms</p>
                    <p className="show">{constant.ShowonMap}</p>
                  </div>
                </div>
                <div className="d-flex justify-content-between address-row">
          <p className="name">{constant.PatelNagar}</p>
                  <div className="address-distance">
                    <p className="distance position-relative">0.93 kms</p>
                    <p className="show">{constant.ShowonMap}</p>
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </TabPane>
        <TabPane tabId="2">
          <Row>
            <Col sm={12}>
              <div className="nearby-content">
                <div className="d-flex justify-content-between address-row">
                  <p className="name">{constant.PatelNagar}</p>
                  <div className="address-distance">
                    <p className="distance position-relative">0.93 kms</p>
                    <p className="show">{constant.ShowonMap}</p>
                  </div>
                </div>
                <div className="d-flex justify-content-between address-row">
                  <p className="name">{constant.PatelNagar}</p>
                  <div className="address-distance">
                    <p className="distance position-relative">0.93 kms</p>
                    <p className="show">{constant.ShowonMap}</p>
                  </div>
                </div>
                <div className="d-flex justify-content-between address-row">
                  <p className="name">{constant.PatelNagar}</p>
                  <div className="address-distance">
                    <p className="distance position-relative">0.93 kms</p>
                    <p className="show">{constant.ShowonMap}</p>
                  </div>
                </div>
                <div className="d-flex justify-content-between address-row">
                  <p className="name">{constant.PatelNagar}</p>
                  <div className="address-distance">
                    <p className="distance position-relative">0.93 kms</p>
                    <p className="show">{constant.ShowonMap}</p>
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </TabPane>
        <TabPane tabId="3">
          <Row>
            <Col sm={12}>
              <div className="nearby-content">
                <div className="d-flex justify-content-between address-row">
                  <p className="name">{constant.PatelNagar}</p>
                  <div className="address-distance">
                    <p className="distance position-relative">0.93 kms</p>
                    <p className="show">{constant.ShowonMap}</p>
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </TabPane>
        <TabPane tabId="4">
          <Row>
            <Col sm={12}>
              <div className="nearby-content">
                <div className="d-flex justify-content-between address-row">
                  <p className="name">{constant.PatelNagar}</p>
                  <div className="address-distance">
                    <p className="distance position-relative">0.93 kms</p>
                    <p className="show">{constant.ShowonMap}</p>
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </TabPane>
      </TabContent>
    </div>
  );
}

export default RoomDetailsTabs;
