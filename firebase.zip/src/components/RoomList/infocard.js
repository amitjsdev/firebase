import React, { useState, useEffect } from "react";
import Wishlist from "../../assets/images/home/wishlist.png";
import { Button } from "reactstrap";
import { navigate } from "gatsby";
import Axios from "axios";
import url from "../../Services/PostData";
import Slider from "react-slick";
import UnLike from "../../assets/images/rooms/heart.svg";
import Like from "../../assets/images/rooms/like.svg";
let value = [];
let btnName = [];
let ScheduledFreeVisit = "";
let Paytobook = "";
function Infocard(props) {
  let setButton = props.data[0].wishlist.includes(
    localStorage.getItem("number")
  );
  console.log(setButton);
  const [toggle, setToggle] = useState(setButton);
  const [value, setValue] = useState([]);
  const [btnHide, setbtnhide] = useState(false);
  const [loader,setloader]=useState(false)
  const settings = {
    dots: false,
    arrow: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    // centerMode: true,
  };

  const sendData = async (getid, getdata) => {
    
    if (!toggle) {
      let newlist = props.data[0].wishlist;
      newlist && newlist.push(localStorage.getItem("number"));
      console.log("newlist", !!newlist, !!getdata.wishlist);
      let data = {
        wishlist: newlist,
      };
      console.log("dsad", data);
      Axios.put(url.BaseUrl + "/wishlist/remove/add/" + getid, data)
        .then((response) => {
          console.log(response);
          setToggle(!!newlist);
          
        })
        .catch((error) => console.log(error));
    } else {
      let newdel = props.data[0].wishlist.slice();
      const newArr = newdel.filter(
        (item) => item != localStorage.getItem("number")
      );
      console.log("df", newArr);
      let data={
        wishlist: newArr
      }
      console.log("df", newArr,getid);
      await Axios.put(url.BaseUrl + "/wishlist/remove/add/" + getid, data)
      .then((response) => {
        let valToggle = JSON.parse(response.config.data).wishlist.includes(
          localStorage.getItem("number")
        );
        setToggle(valToggle);
      })
      .catch((error) => console.log(error));
    }
  };
 

  ScheduledFreeVisit = (data) => {
    navigate(`/detail/${data[1]}`);
  };

  const handleData = (data) => {
    console.log("datadata", data);
  };

  let arr = props.data[0]?.wishlist;
  console.log("!!props.data[0].wishlist", props.gender,props.data[0], props.data[0].price);
  return (
    <>
      <div className="rooms-information">
        <Slider {...settings}>
          {props.data[0].image.map((item) => {
            return (
              <div onClick={() => ScheduledFreeVisit(props.data)}>
                <img src={item.image || ""} className="img-fluid room-image" />
              </div>
            );
          })}
        </Slider>
        <div className="p-4">
          <div className="room-content">
          {props.data[0].Male && "Male"}
          {props.data[0].Female && "Female"}
            <div className="d-flex justify-content-between align-items-center mb-1">
            
              <h3 className="mb-0"> {props.data[0]?.id}</h3>
              {localStorage.getItem("authentication") && (
                <Button
                  color="theme"
                  className="icon"
                  onClick={() => sendData(props.data[1], props.data[0])}
                >
                  {toggle ? <img src={Like} /> : <img src={UnLike} />}
                </Button>
              )}
            </div>
            <p>
              {" "}
              {props.data[0]?.address},{props.data[0]?.occupancy + " Bed"}
            </p>
            <div className="price-wrap">
              <h4>
                <sup className="price-symbol">₹</sup>
                {props.data[0]?.price}
              </h4>
              <p>
                <span className="text-uppercase discount">30% Off</span>
                <span>/monthly</span>
              </p>
            </div>

            <div className="room-buttons">
              <Button
                color="bordered"
                onClick={() => ScheduledFreeVisit(props.data)}
                // className="ml-1"
              >
                Scheduled Free Visit
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Infocard;
