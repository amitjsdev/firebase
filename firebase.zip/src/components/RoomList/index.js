import React, { useEffect, useState } from "react";
import { Container, Row, Col } from "reactstrap";
import Infocard from "./Infocard";
import Filters from "./Filters";
import Axios from "axios";
import { async } from "q";
// import UnLike from "../../assets/images/rooms/heart.svg";
// import Like from "../../assets/images/rooms/like.svg";
// import Room from "../../assets/images/rooms/room.jpg";
// import MarkerPin from "../../assets/images/rooms/pin.png";
// import ListView from "../../assets/images/rooms/list-view.svg";
// import GridView from "../../assets/images/rooms/grid-view.svg";
import filter from "../../assets/images/rooms/filter.png"
import constant from "../../Services/constant.json"
import Loader from "../Loader/index";
let url = require("../../Services/PostData");

const occupancyListDefaults = {
  Single: false,
  Double: false,
  Triple: false,
  Quadraple: false,
};
const genderDefault={
  Male: false,
  Female: false,
}
let occupancy = [];

let MaleVal=false;
let FemaleVal=false;
function RoomList(props) {
  const [item, setItem] = useState([]);
  const [lowestPrice, setLowestPrice] = useState("");
  const [highestPrice, setHighestPrice] = useState("");
  const [maleVal, Male] = useState(false);
  const [femaleVal, Female] = useState(false);
  const[isGender,setIsGender]=useState(genderDefault)
  const [isChecked, setIsChecked] = useState(occupancyListDefaults);
  const [range, setrange] = useState(0);
  const [loader,setLoader]=useState(true);
  //const [occupancy,setOccupancy]=useState('')
  let data = { lowest: lowestPrice, highest: highestPrice, range: range,Male:maleVal,Female:femaleVal,occupancy };
  useEffect(() => {
    console.log('data111',data,props)
    Axios.get(url.BaseUrl + "/get/" + props.id.toLowerCase()).then(
      (response) => {
        console.log("eee----", response, response.data);
        setItem(response.data);
        setLoader(false);
      }
    );
  }, []);

  const handleCheck = async (name, isActive) => {
    setLoader(true)
    console.log(name, isActive);
   // setLoader(false);
    setIsChecked((previous) => {
      return { ...previous, ...(previous[name] = isActive) };
    });
    if (isActive) {
      occupancy.push(name);
    } else {
      occupancy = occupancy.filter((item) => item != name);
    }
    data = {
      lowest: lowestPrice,
      highest: highestPrice,
      range: range,
      occupancy,
      Male:maleVal,Female:femaleVal
    };
    console.log("check", data, !!occupancy);
    await Axios.post(url.BaseUrl + "/filter/" + props.id, data).then(
      (response) => {
        console.log("mmm", response);
        setItem(response.data);
        setLoader(false)
      }
    );
  };

  const LowestPriceHandle = async () => {
    setLoader(true)
    setLowestPrice(true);
    setHighestPrice(false);
    data = { lowest: true, highest: false, range: range, occupancy,Male:maleVal,Female:femaleVal };
    await Axios.post(url.BaseUrl + "/filter/" + props.id, data).then(
      (response) => {
        console.log("nnn", response);
        setItem(response.data);
        setLoader(false);
      }
    );
  };

  const HighestPriceHandle = async () => {
    setHighestPrice(true);
    setLowestPrice(false);
    data = { lowest: false, highest: true, range: range, occupancy,Male:maleVal,Female:femaleVal };
    await Axios.post(url.BaseUrl + "/filter/" + props.id, data).then(
      (response) => {
        console.log("</label>", response);
        setItem(response.data);
        setLoader(false)
      }
    );
  };

  const GenderSearch=async(name, isActive)=>{
    setLoader(true)
    console.log("vvb",name, isActive);
    setIsGender((previous) => {
      return { ...previous, ...(previous[name] = isActive) };
    });
    if(name=='Male')
    {
      Male(isActive)
      MaleVal=isActive;
    }
    if(name=='Female')
    {
      Female(isActive)
      FemaleVal=isActive;
    }
    data = { lowest: lowestPrice, highest: highestPrice, range: range, occupancy,Male:MaleVal,Female:FemaleVal};
    console.log('sdads',data)
    await Axios.post(url.BaseUrl + "/filter/" + props.id, data).then(
      (response) => {
        console.log("gender111", response);
        setItem(response.data);
        setLoader(false);
      }
    );
  }

  const monthlyRent = async (range1) => {
    setLoader(true)
    setrange(range1);
    console.log("dsss", range1);
    data = {
      lowest: lowestPrice,
      highest: highestPrice,
      range: range1,
      occupancy,
      Male:maleVal,Female:femaleVal
    };
    console.log("daaaaa", data);
    await Axios.post(url.BaseUrl + "/filter/" + props.id, data).then(
      (response) => {
        console.log(response.data, 'response.data...');
        setItem(response.data);
        setLoader(false)
      }
    );
  };

  console.log("item.enable", maleVal,femaleVal);
  return (
    
    <div className="room-listing-wrapper">
     <button className="fltr-img"><img src={filter} /></button>
      <div className="sidebar-wrapper">
     
        <Filters
          LowestPriceHandle={LowestPriceHandle}
          HighestPriceHandle={HighestPriceHandle}
          // Distance={DistancefromLandmark}
          monthlyRent={monthlyRent}
          handleCheck={handleCheck}
          isChecked={isChecked}
          isGender={isGender}
          GenderSearch={GenderSearch}
          filterPage={""}
        />
      </div>

      {!loader  && <div className="rooms-listing-wrap">
        <div className="rooms-listing">
          <Row>
            <Col md={12}>
              <h2 className="city-title">{props.id}</h2>
              {/* <p className="sub-title">Showing 20 houses out of 50 houses</p> */}
            </Col>
          </Row>
          <Row>
            {item.length ? (
              item.map((data) => {
                return (
                  <Col md={4} className="mb-3">
                    <Infocard data={data} />
                    {/* cardData={cardData} */}
                  </Col>
                );
              })
            ) : (
              <Col md={12}>
                <h2 className="no-results">No Results found</h2>
              </Col>
            )}
          </Row>
        </div>
      </div>}
      {/* {
       loader  && <Loader/>
      } */}
    </div>
  );
}

export default RoomList;
