import React, { useState, useEffect } from "react";
import { Button, Label, Input, FormGroup } from "reactstrap";
import LowestGray from "../../../assets/images/rooms/lowest-gray.png";
import HighestRed from "../../../assets/images/rooms/highest-red.png";
import DistanceGray from "../../../assets/images/rooms/distance-gray.png";
import BoyGray from "../../../assets/images/rooms/boy-gray.png";
import BoyRed from "../../../assets/images/rooms/girl-red.png";
import Gender3 from "../../../assets/images/rooms/gender3-gray.png";
import Axios from "axios";
import url from "../../../Services/PostData";
import cx from 'classnames';
import constant from "../../../Services/constant.json"

const CheckBoxInput = (props) => {
  const { isActive = false, name, label, onClick } = props;
  return (
    <FormGroup check>
      <Label check className={cx({active:isActive})}>
        <Input
          type="checkbox"
          checked={isActive}
          name={name}
          onChange={onClick}
        />
        {/* <span className="checkmark"></span> */}
        {label}
      </Label>
    </FormGroup>
  );
};

function Filters(props) {
  const minRange = "1000";
  const maxRange = "10000";
  const [range, setRange] = useState(minRange);
  const { filterPage } = props;
  const { Single, Double, Triple, Quadraple } = props.isChecked;
  const { Male, Female } = props.isGender;
  const [genderData, setGenderData] = useState([]);

  const handleSlider = (e) => {
    setRange(e.target.value);
  };

  const handleMouse = (e) => {
    props.monthlyRent(Number(range));
  };
  const renderRangeSlider = () => {
    return (
      <div className="mb-3 price-range-wrap">
        <label>{constant.MonthlyRent}</label>
        <div>
          <input
            type="range"
            min={minRange}
            max={maxRange}
            value={range}
            onChange={handleSlider}
            onMouseUp={() => handleMouse()}
          />
        </div>
        <div className="price-range">
          <p>
            {"<"}₹{range}
          </p>
          <p>
            {">"}₹{maxRange}
          </p>
        </div>
      </div>
    );
  };

  const renderPriceFilters = () => {
    return (
      <div className="filter-price mb-3">
        <label>{constant.Price}</label>
        <div className="filter-price-btns">
          <Button color="bordered" onClick={props.LowestPriceHandle}>
            <img src={LowestGray} className="mr-2" />
            {/* <img src={LowestRed} className="mr-2" /> */}
            Lowest price First
          </Button>
          <Button color="bordered selected" onClick={props.HighestPriceHandle}>
            {/* <img src={HighestGray} className="mr-2" /> */}
            <img src={HighestRed} className="mr-2" />
            Highest price First
          </Button>
        </div>
      </div>
    );
  };
  const renderOffers = () => {
    return (
      <div className="mb-3">
        {" "}
        <label>Offers</label>{" "}
        <div className="genders-wrap">
          <button className="circle">
            <img src={BoyGray} />
          </button>
        </div>
      </div>
    );
  };
  useEffect(() => {
    let id = localStorage.getItem("id");
    console.log("props======", props);
    Axios.get(url.BaseUrl + "/room/read/" + id).then((res) => {
      console.log("res111111", res);
      setGenderData(res.data.gender);
      console.log("resresres", res.data.DateSlot);
    });
  }, []);
  const renderGenderFilters = () => {
    return (
      <div className="mb-3">
        <label>Gender</label>
        <div className="occupancy-wrapper">
          <CheckBoxInput
            name="Male"
            label="Male"
            isActive={Male}
            onClick={() => {
              props.GenderSearch("Male", !Male);
            }}
          />
          <CheckBoxInput
            name="Female"
            label="Female"
            isActive={Female}
            onClick={() => {
              props.GenderSearch("Female", !Female);
            }}
          />
        </div>
        {/* <div className="mb-3">
          <label>Gender</label>
         <button name='Male' className="circle " onClick={(e)=>props.GenderSearch(e)}><img src={BoyGray}/> Male</button>
         <button name='Female' className="circle " onClick={(e)=>props.GenderSearch(e)}><img src={BoyRed} />Female </button>
      </div> */}
      </div>
    );
  };

  return (
    <div className="filters-wrapper">
      {filterPage != "wishlist" && (
        <>
          <h3 className="mb-3">Filters</h3>
          <div>{renderPriceFilters()}</div>
          {/* <div>{renderOffers()}</div> */}
          <div>{renderRangeSlider()}</div>
          {/* <div>{renderOccupancyFilters()}</div> */}
          <div>{renderGenderFilters()}</div>
          <div className="mb-3 ">
            <label> Occupancy</label>
            <div className="occupancy-wrapper">
              <CheckBoxInput
                name="single"
                label="Single"
                isActive={Single}
                onClick={() => {
                  props.handleCheck("Single", !Single);
                }}
              />
              <CheckBoxInput
                name="double"
                label="Double"
                isActive={Double}
                onClick={() => {
                  props.handleCheck("Double", !Double);
                }}
              />
              <CheckBoxInput
                name="triple"
                label="Triple"
                isActive={Triple}
                onClick={() => {
                  props.handleCheck("Triple", !Triple);
                }}
              />
              <CheckBoxInput
                name="quadraple"
                label="Quadraple"
                isActive={Quadraple}
                onClick={() => {
                  props.handleCheck("Quadraple", !Quadraple);
                }}
              />
            </div>
          </div>
        </>
      )}
      {filterPage == "wishlist" && (
        <>
          <div className="disabled-filter"></div>
          <h3 className="mb-3">Filters</h3>
          <div>{renderPriceFilters()}</div>
          {/* <div>{renderOffers()}</div> */}
          <div>{renderRangeSlider()}</div>
          {/* <div>{renderOccupancyFilters()}</div> */}
          <div>{renderGenderFilters()}</div>
          <div className="mb-3 ">
            <label> Occupancy</label>
            <div className="occupancy-wrapper">
              <CheckBoxInput
                name="single"
                label="Single"
                isActive={Single}
                onClick={() => {
                  props.handleCheck("Single", !Single);
                }}
              />
              <CheckBoxInput
                name="double"
                label="Double"
                isActive={Double}
                onClick={() => {
                  props.handleCheck("Double", !Double);
                }}
              />
              <CheckBoxInput
                name="triple"
                label="Triple"
                isActive={Triple}
                onClick={() => {
                  props.handleCheck("Triple", !Triple);
                }}
              />
              <CheckBoxInput
                name="quadraple"
                label="Quadraple"
                isActive={Quadraple}
                onClick={() => {
                  props.handleCheck("Quadraple", !Quadraple);
                }}
              />
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default Filters;
