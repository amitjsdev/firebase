import React from "react";
import {
  Button,
  Container,
  Contaner,
  Row,
  Col,
  Card,
  CardBody,
} from "reactstrap";
import url from "../../Services/PostData";
import Axios from "axios";
import Layout from "../LayoutPage";
import { useEffect, useState } from "react";
import Slider from "react-slick";
import Ac from "../../assets/images/RoomDetails/ac.png";
import Wifi from "../../assets/images/RoomDetails/wifi.svg";
import Bed from "../../assets/images/RoomDetails/bed.svg";
import Bowl from "../../assets/images/RoomDetails/bowl.svg";
import Cctv from "../../assets/images/RoomDetails/cctv.svg";
import FireExtinguisher from "../../assets/images/RoomDetails/fire-extinguisher.svg";
import Geyser from "../../assets/images/RoomDetails/geyser.svg";
import InductionStove from "../../assets/images/RoomDetails/induction-stove.svg";
import Microwave from "../../assets/images/RoomDetails/microwave.svg";
import Power from "../../assets/images/RoomDetails/power.svg";
import Refrigerator from "../../assets/images/RoomDetails/refrigerator.svg";
import WashingMachine from "../../assets/images/RoomDetails/washing-machine.svg";
import PropertyType from "../../assets/images/RoomDetails/pgIcons/PropertyType.png";
import PropertyTypeRed from "../../assets/images/RoomDetails/pgIcons/propertyTypeRed.png";
import Floors from "../../assets/images/RoomDetails/pgIcons/Floors.png";
import FloorsRed from "../../assets/images/RoomDetails/pgIcons/FloorsRed.png";
import Liftservices from "../../assets/images/RoomDetails/pgIcons/Liftservices.png";
import LiftServicesRed from "../../assets/images/RoomDetails/pgIcons/liftServicesRed.png";
import ParkingFacility from "../../assets/images/RoomDetails/pgIcons/parkingFacility.png";
import ParkingFacilityRed from "../../assets/images/RoomDetails/pgIcons/parkingFacilityRed.png";
import CommonKitchen from "../../assets/images/RoomDetails/pgIcons/commonKitchen.png";
import CommonKitchenRed from "../../assets/images/RoomDetails/pgIcons/commonKitchenRed.png";
import SeprateCupboards from "../../assets/images/RoomDetails/pgIcons/SeprateCupboards.png";
import SeprateCupboardsRed from "../../assets/images/RoomDetails/pgIcons/SeprateCupboardsRed.png";
import Laundry from "../../assets/images/RoomDetails/pgIcons/Laundry.png";
import LaundryRed from "../../assets/images/RoomDetails/pgIcons/LaundryRed.png";
import PropertyCaretaker from "../../assets/images/RoomDetails/pgIcons/PropertyCaretaker.png";
import PropertyCaretakerRed from "../../assets/images/RoomDetails/pgIcons/propertyCaretakerRed.png";
import HousekeepingInBedroom from "../../assets/images/RoomDetails/pgIcons/HousekeepingInBedroom.png";
import HousekeepingInBedroomRed from "../../assets/images/RoomDetails/pgIcons/housekeepingInBedroomRed.png";
import HousekeepingInCommonArea from "../../assets/images/RoomDetails/pgIcons/HousekeepingInCommonArea.png";
import HousekeepingInCommonAreaRed from "../../assets/images/RoomDetails/pgIcons/HousekeepingInCommonAreaRed.png";
import ZomatoServices from "../../assets/images/RoomDetails/pgIcons/ZomatoServices.png";
import ZomatoServicesRed from "../../assets/images/RoomDetails/pgIcons/ZomatoServicesRed.png";
import UberOlaServices from "../../assets/images/RoomDetails/pgIcons/UberOlaServices.png";
import UberOlaServicesRed from "../../assets/images/RoomDetails/pgIcons/UberOlaServicesRed.png";
import GoogleMap from "../../assets/images/RoomDetails/google-map.jpg";
import RoomDetailsTabs from "./roomDetailsTabs";
import Modal from "../../components/WishList/modal";
import constant from "../../Services/constant.json"
import { navigate } from "@reach/router";

function Click(props) {
  const [data, setData] = useState("");
  const [modal, setModal] = useState(false);
  const [id, setId] = useState(false);
  const [DataSlot, setDataSlot] = useState("");
  const [gender, setgender] = useState("");
  const [value, setValue] = useState(true);
  const [newDate, setnewDate] = useState("");
  const [newTime, setnewTime] = useState("");

  const settings = {
    dots: false,
    arrow: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    centerMode: true,
  };

  useEffect(() => {
    console.log("props======", props);
    Axios.get(url.BaseUrl + "/room/read/" + props.id).then((res) => {
      console.log("res111111", res);
      setData(res.data);
      setDataSlot(res.DataSlot);
      setgender(res.data.gender);
      console.log("resresres", res.data.DateSlot);
    });
    localStorage.setItem("id", props.id);
  }, []);

  const handleModal = () => {
    console.log('proppssss',props.location.pathname)
    localStorage.setItem('navigatePrivate',props.location.pathname)
    if (localStorage.getItem("authentication")) {
      setModal(true);
    } else {
      navigate("/login");
    }
  };

  console.log("datadata", data.Bedroom, data.PropertyDetail);
  console.log("sds1234", newTime, newDate);
  return (
    <Layout>
      <div className="room-details-page-wrapper">
        <Slider {...settings}>
          {data.image &&
            data.image.map((item) => {
              return (
                <>
                  <div>
                    <img
                      src={item.image || ""}
                      className="img-fluid room-detail-image"
                    />
                  </div>
                </>
              );
            })}
        </Slider>
        <section className="room-details-information">
          <Container>
            <div className="room-details-info">
              <h2>{data.address && data.address}</h2>
              <p className="address">
                {data.address},{data.occupancy + " Bed"}
              </p>
              {/* {data.priceValue.map(item=>console.log('itemitem',item))} */}
              <Row>
                <Col md={12}>
                  <Row className="mx-0 RoomPriceDetailsWrapper">
                    <Col md={9}>
                      {data.priceValues &&
                        data.priceValues.map((item) => {
                          console.log("itmmm", item);
                          return (
                            <div className="room-detail-price-wrapper">
                              <div className="sharing-room-detail col-item">
                                <p className="mb-1">{item.RoomType}</p>
                                <h4>
                                  <sup className="price-symbol">₹</sup>
                                  {item.price}
                                  <span>/Per Bed</span>
                                </h4>
                                <div className="room-details-buttons">
                                  <Button color="bordered">
                                    {item.ACType}
                                  </Button>
                                  <Button color="bordered" className="ml-2">
                                    Available from today
                                  </Button>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                    </Col>
                    <Col md={3} className={value?"room-buttons":"room-buttons-bg"}>
                      <div className="d-flex justify-content-center flex-column h-100">
                        {value && (
                          <Button
                            color="bordered"
                            onClick={handleModal}
                            className="mr-1"
                          >
                            Scheduled Free visit
                          </Button>
                        )}
                        {/* <Button
                          color="theme"
                          onClick={() => {}}
                          className="mr-1 mt-2"
                        >
                          Pay to Book
                        </Button> */}
                        {!value && (
                          <div className="booked-time">
                            <p className="mb-0">
                              <span>Schedule booked on</span> {newDate} | {newTime}
                            </p>
                            <p className="mb-0">
                              {/* <span>Time</span> */}
                             
                            </p>
                          </div>
                        )}
                      </div>
                    </Col>
                  </Row>
                </Col>
              </Row>
            </div>
          </Container>
        </section>
        <section className="room-detail-amenties">
          <Container>
            <h2>Amenties</h2>
            <Row>
              <Col md={3} className="px-1">
                <div className="amenties-box">
                  <h3>Building Level</h3>
                  {data.BuildingLevel &&
                    data.BuildingLevel.map((item) => {
                      return (
                        <>
                          <p>{item.value}</p>
                        </>
                      );
                    })}
                </div>
              </Col>
              <Col md={3} className="px-1">
                <div className="amenties-box">
                  <h3>{constant.Bedroom}</h3>
                  {data.Bedroom &&
                    data.Bedroom.map((item) => {
                      return (
                        <>
                          <p>{item.value}</p>
                        </>
                      );
                    })}
                </div>
              </Col>
              <Col md={3} className="px-1">
                <div className="amenties-box">
                  <h3>{constant.kitchen}</h3>
                  {data.Kitchen &&
                    data.Kitchen.map((item) => {
                      return (
                        <>
                          <p>{item.value}</p>
                        </>
                      );
                    })}
                </div>
              </Col>
              <Col md={3} className="px-1">
                <div className="amenties-box">
                  <h3>{constant.Washroom}</h3>
                  {data.Washroom &&
                    data.Washroom.map((item) => {
                      return (
                        <>
                          <p>{item.value}</p>
                        </>
                      );
                    })}
                </div>
              </Col>
            </Row>
          </Container>
        </section>

        <section className="aboutTheProperty">
          <Container>
            <h2>{constant.AbouttheProperty}</h2>
            <p>
              This girls only house by OYO LIFE is located in close proximity to
              the hustle & bustle of the city.Go for a private room or share it
              with a friend, you can't have enough girl time.
            </p>
            <div className="properties-wrapper">
              <Row>
                {data.PropertyDetail &&
                  data.PropertyDetail.length > 0 &&
                  data.PropertyDetail.map((item) => {
                    console.log("sdff", item);
                    return (
                      <>
                        <Col className="px-0">
                          <div className="property-col">
                            <div className="property-icon">
                              <img src={PropertyType} className="img-1" />
                              <img src={PropertyTypeRed} className="img-2" />
                            </div>
                            <h3>{constant.PropertyType}</h3>
                            <p>{item.PropertyType}</p>
                          </div>
                        </Col>
                        <Col className="px-0">
                          <div className="property-col">
                            <div className="property-icon">
                              <img src={Floors} className="img-1" />
                              <img src={FloorsRed} className="img-2" />
                            </div>
                            <h3>{constant.No.offloors}</h3>
                            <p>{item.NoofFloors}</p>
                          </div>
                        </Col>
                        <Col className="px-0">
                          <div className="property-col">
                            <div className="property-icon">
                              <img src={Liftservices} className="img-1" />
                              <img src={LiftServicesRed} className="img-2" />
                            </div>
                            <h3>{constant.LiftFacility}</h3>
                            <p>{item.LiftFacility}</p>
                          </div>
                        </Col>
                        <Col className="px-0">
                          <div className="property-col">
                            <div className="property-icon">
                              <img src={ParkingFacility} className="img-1" />
                              <img src={ParkingFacilityRed} className="img-2" />
                            </div>

                            <h3>{constant.ParkingFacility}</h3>
                            <p>{item.ParkingFacility}</p>
                          </div>
                        </Col>
                        <Col className="px-0">
                          <div className="property-col">
                            <div className="property-icon">
                              <img src={CommonKitchen} className="img-1" />
                              <img src={CommonKitchenRed} className="img-2" />
                            </div>
                            <h3>{constant.CommonKitchen}</h3>
                            <p>{item.CommonKitchen}</p>
                          </div>
                        </Col>
                        <Col className="px-0">
                          <div className="property-col">
                            <div className="property-icon">
                              <img src={SeprateCupboards} className="img-1" />
                              <img
                                src={SeprateCupboardsRed}
                                className="img-2"
                              />
                            </div>
                            <h3>{constant.SeparateCupboardsineachroom}</h3>
                            <p>{item.NoofSeparateCupboardsineachroom}</p>
                          </div>
                        </Col>
                        <Col className="px-0">
                          <div className="property-col">
                            <div className="property-icon">
                              <img src={Laundry} className="img-1" />
                              <img src={LaundryRed} className="img-2" />
                            </div>
                            <h3>{constant.LaundaryService}</h3>
                            <p>{item.LaundaryService}</p>
                          </div>
                        </Col>
                        <Col className="px-0">
                          <div className="property-col">
                            <div className="property-icon">
                              <img src={PropertyCaretaker} className="img-1" />
                              <img
                                src={PropertyCaretakerRed}
                                className="img-2"
                              />
                            </div>
                            <h3>{constant.PropertyCaretaker}</h3>
                            <p>{item.PropertyCaretaker}</p>
                          </div>
                        </Col>
                        <Col className="px-0">
                          <div className="property-col">
                            <div className="property-icon">
                              <img
                                src={HousekeepingInBedroom}
                                className="img-1"
                              />
                              <img
                                src={HousekeepingInBedroomRed}
                                className="img-2"
                              />
                            </div>
                            <h3>{constant.HouseKeepinginBedroom}</h3>
                            <p>{item.HouseKeepinginBedroom}</p>
                          </div>
                        </Col>
                        <Col className="px-0">
                          <div className="property-col">
                            <div className="property-icon">
                              <img
                                src={HousekeepingInCommonArea}
                                className="img-1"
                              />
                              <img
                                src={HousekeepingInCommonAreaRed}
                                className="img-2"
                              />
                            </div>
                            <h3>{constant.HouseKeepingincommonarea}</h3>
                            <p>{item.HouseKeepingincommonarea}</p>
                          </div>
                        </Col>
                        <Col className="px-0">
                          <div className="property-col">
                            <div className="property-icon">
                              <img src={ZomatoServices} className="img-1" />
                              <img src={ZomatoServicesRed} className="img-2" />
                            </div>
                            <h3>Zomato/Swiggy services</h3>
                            <p>{item.ZomatoSwiggyservices}</p>
                          </div>
                        </Col>
                        <Col className="px-0">
                          <div className="property-col">
                            <div className="property-icon">
                              <img src={UberOlaServices} className="img-1" />
                              <img src={UberOlaServicesRed} className="img-2" />
                            </div>
                            <h3>Uber/Ola services</h3>
                            <p>{item.UberOlaservices}</p>
                          </div>
                        </Col>
                      </>
                    );
                  })}
              </Row>
            </div>
          </Container>
        </section>
        {/* <section className="nearby-wrapper">
          <Container>
            <h2>What's Nearby</h2>
            <Card>
              <CardBody>
                <Row>
                  <Col md={6}>
                    <RoomDetailsTabs />
                  </Col>
                  <Col md={6}>
                    <img src={GoogleMap} className="img-fluid" />
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Container>
        </section> */}
      </div>
      <Modal
        toggle={() => setModal((previous) => !previous)}
        onHide={() => setModal(false)}
        modal={modal}
        data={data}
        setDate={setnewDate}
        setTime={setnewTime}
        setValue={setValue}
      />
    </Layout>
  );
}

export default Click;
