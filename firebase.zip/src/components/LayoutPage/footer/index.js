import React from "react";
import { Row, Col, Container } from "reactstrap";
import Banglore from "../../../assets/images/footer/banglore.png";
import Gurgaon from "../../../assets/images/footer/gurgaon.png";
import Pune from "../../../assets/images/footer/pune.png";
import Noida from "../../../assets/images/footer/noida.png";
import Mumbai from "../../../assets/images/footer/mumbai.png";
import Dehli from "../../../assets/images/footer/dehli.png";
import Hyderabad from "../../../assets/images/footer/hyderabad.png";
import Chennai from "../../../assets/images/footer/chennai.png";
import Lucknow from "../../../assets/images/footer/lucknow.png";
import AppStore from "../../../assets/images/footer/app-store.png";
import PlayStore from "../../../assets/images/footer/play.png";
import Copyright from "../../../assets/images/footer/copyright.png";
import Facebook from "../../../assets/images/footer/facebook.png";
import Twitter from "../../../assets/images/footer/twitter.png";
import Instagram from "../../../assets/images/footer/instagram.png";
import constant from "../../../Services/constant.json"


export default () => (
  <footer className="footer">
    <div className="footer-top">
      <Container>
        <Row>
          <Col sm={12} xl={6} className="mb-5">
            <h2>{constant.FindOYOLIFEin}</h2>
            <Row>
              <Col lg={4} xs={6}>
                <div className="footer-city-wrap">
                  <img src={Banglore} />
                  <p className="mb-0">Banglore</p>
                </div>
              </Col>
              <Col lg={4} xs={6}>
                <div className="footer-city-wrap">
                  <img src={Gurgaon} />
                  <p className="mb-0">Gurgaon</p>
                </div>
              </Col>
              <Col lg={4} xs={6}>
                <div className="footer-city-wrap">
                  <img src={Pune} />
                  <p className="mb-0">Pune</p>
                </div>
              </Col>
              <Col lg={4} xs={6}>
                <div className="footer-city-wrap">
                  <img src={Noida} />
                  <p className="mb-0">Noida</p>
                </div>
              </Col>
              <Col lg={4} xs={6}>
                <div className="footer-city-wrap">
                  <img src={Mumbai} />
                  <p className="mb-0">Mumbai</p>
                </div>
              </Col>
              <Col lg={4} xs={6}>
                <div className="footer-city-wrap">
                  <img src={Dehli} />
                  <p className="mb-0">Dehli</p>
                </div>
              </Col>
              <Col lg={4} xs={6}>
                <div className="footer-city-wrap">
                  <img src={Hyderabad} />
                  <p className="mb-0">Hyderabad</p>
                </div>
              </Col>
              <Col lg={4} xs={6}>
                <div className="footer-city-wrap">
                  <img src={Chennai} />
                  <p className="mb-0">Chennai</p>
                </div>
              </Col>
              <Col lg={4} xs={6}>
                <div className="footer-city-wrap">
                  <img src={Lucknow} />
                  <p className="mb-0">Lucknow</p>
                </div>
              </Col>
            </Row>
            <Row>
              <Col md={12}>
                <div className="social-icons">
                  <a href="#">
                    <img src={Facebook} />
                  </a>
                  <a href="#">
                    <img src={Twitter} />
                  </a>
                  <a href="#">
                    <img src={Instagram} />
                  </a>
                </div>
              </Col>
            </Row>
          </Col>
          <Col sm={6} xl={3}>
            <h2>{constant.OYOLIFE}</h2>
            <Row className="footer-menu">
              <Col xs={6}>
                <ul className="pl-0">
                  <li>{constant.AboutUs}</li>
                  <li> {constant.Team}</li>
                  <li> {constant.Workwithus}</li>
                  <li> {constant.PressKit}</li>
                  <li> {constant.PrivacyPolicy}</li>
                </ul>
              </Col>
              <Col xs={6}>
                <ul className="pl-0">
                  <li>{constant.GuestPolicies}</li>
                  <li> {constant.Blog}</li>
                  <li> {constant.ReportConcerns}</li>
                  <li> {constant.FAQs}</li>
                  <li> {constant.PartnerwithUs}</li>
                  <li>{constant.PartnerPolicies}</li>
                </ul>
              </Col>
            </Row>
          </Col>
          <Col sm={6} xl={3} className="text-sm-center">
            <h2 className="mt-4 mt-sm-0">Download/Share</h2>
            <div className="footer-buttons">
              <button>
                <img src={AppStore} className="mr-2" />
                App Store
              </button>
              <button>
                <img src={PlayStore} className="mr-2" />
                Play Store
              </button>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
    <div className="footer-bottom">
      <p className="mb-0">
        <img src={Copyright} />
        2020, All Rights Reserved
      </p>
    </div>
  </footer>
);
