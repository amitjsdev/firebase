import React, { useState, useEffect } from "react";
import { Container, Dropdown, DropdownToggle, DropdownMenu } from "reactstrap";
import { Link } from "react-router-dom";
import Wishlist from "../../../assets/images/home/wishlist.png";
import Phone from "../../../assets/images/home/phone.png";
import Profile from "../../../assets/images/signin/profile.jpg";
import { navigate } from "gatsby";
import useFirebase from "../../../Services/firebase";
import constant from "../../../Services/constant.json"

// className="sticky-top"
function Header(props) {
  const firebase  = useFirebase();
  const [sticky, setSticky] = useState(false);
  const { transparentHeader = "" } = props;
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [key, setkey] = useState(undefined);
  const toggle = () => setDropdownOpen((prevState) => !prevState);

  const onScroll = (e) => {
    let scrollPosition = window.scrollY;
    if (scrollPosition >= 70) {
      setSticky(true);
    } else {
      setSticky(false);
    }
  };

  useEffect(() => {
    setkey(localStorage.getItem("authentication"))
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const wishList = () => {
    localStorage.setItem("navigatePrivate",'/wishlist')
    navigate("/wishlist");
  };

  const loginHandle = () => {
    localStorage.setItem('navigatePrivate',window.location.pathname)
     navigate("/login");
  };

  const logoutHandle = () => {
    !!firebase && firebase
      .auth()
      .signOut()
      .then(function (res) {
        console.log(res);
        localStorage.removeItem("authentication");
        navigate("/login");
      })
      .catch(function (error) {
        console.log(error);
      });
  };
  const calling = () => {
    navigate("/roomdetails");
  };

  const handlePartner=()=>{
    navigate('/partner-with-us')
  }

  return (
    <header
      id="header"
      className={
        sticky ? "sticky-top" : transparentHeader ? "transparentHeader" : ""
      }
    >
      <nav className="navbar navbar-expand-lg navbar-light">
        <div className="header-logo">
          <h4>
           { <a href="/">Dummy Logo</a>}
          </h4>
        </div>
        <div className="header-wrap ml-auto">
          {key && (
            <ul className="navbar-nav ">
              <li>
                <a href="/">Refer & Earn</a>
              </li>
              <li onClick={handlePartner}>
                   Partner with us
              </li>
            </ul>
          )}
          <div className="account-wrap">
            {key && (
              <button className="login-btn" onClick={logoutHandle}>
                Logout
              </button>
            )}
            {!key && (
              <>
                <button className="login-btn" onClick={loginHandle}>
                  Login
                </button>
                {/* <button className="icon ml-3" >
                  <img src={Phone} className="phone" />
                </button> */}
              </>
            )}

            <button className="icon ml-3" onClick={wishList}>
              <img src={Wishlist} />
            </button>
            <button className="icon ml-3">
              <img src={Phone} className="phone"onClick={calling} />
            </button>
            {key && (
              <Dropdown
                isOpen={dropdownOpen}
                toggle={toggle}
                className="loggedin-profile ml-3"
              >
                <DropdownToggle>
                  <img src={Profile} />
                </DropdownToggle>
                <DropdownMenu right>
                  <div className="profile-dropdown">
                    <img src={Profile} className="mb-2" />
                    <h2 className="mb-0">{localStorage.getItem("name")}</h2>
                    <p className="mb-0">{localStorage.getItem("email")}</p>
                    <p className="mb-0">{localStorage.getItem("number")}</p>
                  </div>
                </DropdownMenu>
              </Dropdown>
            )}
          </div>
        </div>
      </nav>
    </header>
  );
}

export default Header;
