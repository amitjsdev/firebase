
import React, { useState } from 'react';
import {navigate} from 'gatsby';

import {
  Container,
  FormGroup,
  Label,
  Input,
  Button,
  Row,
  Col,
} from "reactstrap";
import Comfort from "../../../assets/images/home/comfort.png";
import ComfortRed from "../../../assets/images/home/comfortRed.png";
import Proximity from "../../../assets/images/home/proximity.png";
import Safety from "../../../assets/images/home/safety.png";
import SafetyRed from "../../../assets/images/home/SafetyRed.png";
import PocketFriendly from "../../../assets/images/home/pocket-friendly.png";
// import Jaipur from "../../../assets/images/home/jaipur.png";
// import Hyderabad from "../../../assets/images/home/hyderabad.png";
import Chandigarh from "../../../assets/images/home/chandigarh.png";
 import Mohali from "../../../assets/images/home/dehli.png";
 import zirakpur from "../../../assets/images/home/mumbai.png";
// import Amritsar from "../../../assets/images/home/amritsar.png";
// import Bangalore from "../../../assets/images/home/bangalore.png";
import Goa from "../../../assets/images/home/goa.png";
import Lucknow from "../../../assets/images/home/lucknow.png";
import constant from "../../../Services/constant.json"
export default () => {
  // const [stateName, SetStateName] = useState("");
  const List=(cityname)=>{
    navigate('/'+cityname)
    // console.log("ijnnnn",stateName)
    };
    return(
  <section className="living-facilities-wrapper">
    <Container>
      <Row className="city-wrapper">
        {/* <Col>
          <div className="city-content">
            <img src={Jaipur} />
            <p className="text">Jaipur</p>
          </div>
        </Col> */}
        {/* <Col>
          <div className="city-content">
            <img src={Hyderabad} />
            <p className="text">Hyderabad</p>
          </div>
        </Col> */}
        <Col>
          <div className="city-content">
            <img src={Chandigarh} onClick={(e)=>{List("chandigarh")}}/>  
            <p className="text">Chandigarh</p>
          </div>
        </Col>
        {/* <Col>
          <div className="city-content">
            <img src={Dehli} />
            <p className="text">Dehli</p>
          </div>
        </Col> */}
        {/* <Col>
          <div className="city-content">
            <img src={Mumbai} />
            <p className="text">Mumbai</p>
          </div>
        </Col> */}
        {/* <Col>
          <div className="city-content">
            <img src={Amritsar} />
            <p className="text">Amritsar</p>
          </div>
        </Col> */}
        {/* <Col>
          <div className="city-content">
            <img src={Bangalore} />
            <p className="text">Bangalore</p>
          </div>
        </Col> */}
        {/* <Col>
          <div className="city-content">
            <img src={Goa} />
            <p className="text">Goa</p>
          </div>
        </Col> */}

        {/* <Col>
          <div className="city-content">
            <img src={Lucknow} />
            <p className="text">Lucknow</p>
          </div>
        </Col> */}
      </Row>
      <Row>
        <Col md={12}>
          <h5>{constant.LivingtheLoremIpsum}</h5>
          <h2>{constant.LivingtheLoremIpsumlifesimply}</h2>
          <div className="facilities-information">
            <Col lg={4} md={6} className="mb-5">
              <div className="column">
                <div className="facilities-image">
                  <img src={Comfort} className="img-1" />
                  <img src={ComfortRed} className="img-2" />
                </div>

                <h4>{constant.ComfortConvenience}</h4>
                <p>
                  Furnished Homes with a wide range of amenities. Just move-in
                  with your bags. Furnished Homes with a wide range of
                  amenities. Just move-in with your bags. Furnished Homes with a
                  wide range of amenities. Just move-in with your bags
                </p>
              </div>
            </Col>
            <Col lg={4} md={6} className="mb-5">
              <div className="column">
                <div className="facilities-image">
                  <img src={Safety} className="img-1" />
                  <img src={SafetyRed} className="img-2" />
                </div>
                <h4>{constant.SafetySecurity}</h4>
                <p>
                  High-end security with CCTV cameras and On-call stay
                  supervisor.High-end security with CCTV cameras and On-call
                  stay supervisor.High-end security with CCTV cameras and
                  On-call stay supervisor.
                </p>
              </div>
            </Col>
            <Col lg={4} md={6} className="mb-5">
              <div className="column">
                <div className="facilities-image">
                  <img src={Proximity} className="img-1" />
                  <img src={SafetyRed} className="img-2" />
                </div>
                <h4>{constant.Proximitytoworkspace}</h4>
                <p>
                  High-end security with CCTV cameras and On-call stay
                  supervisor.High-end security with CCTV cameras and On-call
                  stay supervisor.High-end security with CCTV cameras and
                  On-call stay supervisor.
                </p>
              </div>
            </Col>
            <Col lg={4} md={6} className="mb-5">
              <div className="column">
                <div className="facilities-image">
                  <img src={PocketFriendly} className="img-1" />
                  <img src={ComfortRed} className="img-2" />
                </div>
                <h4>{constant.Pocketfriendly}</h4>
                <p>
                  Furnished Homes with a wide range of amenities. Just move-in
                  with your bags. Furnished Homes with a wide range of
                  amenities. Just move-in with your bags. Furnished Homes with a
                  wide range of amenities. Just move-in with your bags
                </p>
              </div>
            </Col>
            <Col lg={4} md={6} className="mb-5">
              <div className="column">
                <div className="facilities-image">
                  <img src={Proximity} className="img-1" />
                  <img src={SafetyRed} className="img-2" />
                </div>
                <h4>Comfort & Convenience</h4>
                <p>
                  Furnished Homes with a wide range of amenities. Just move-in
                  with your bags. Furnished Homes with a wide range of
                  amenities. Just move-in with your bags. Furnished Homes with a
                  wide range of amenities. Just move-in with your bags
                </p>
              </div>
            </Col>
          </div>
        </Col>
      </Row>
    </Container>
  </section>
    )
      }
