import * as React from "react";
import {
  Container,
  FormGroup,
  Label,
  Input,
  Button,
  Row,
  Col,
} from "reactstrap";
import WIFI from "../../../assets/images/home/wifi.png";
import TV from "../../../assets/images/home/tv.png";
import RO from "../../../assets/images/home/RO.png";
import DTH from "../../../assets/images/home/dth.png";
import WashingMachine from "../../../assets/images/home/washing-machine.png";
import PowerBackup from "../../../assets/images/home/power.png";
import Refrigerator from "../../../assets/images/home/frize.png";
import AC from "../../../assets/images/home/ac.png";
import CCTV from "../../../assets/images/home/cctv.png";
import Building from "../../../assets/images/home/building.png";
import constant from "../../../Services/constant.json"

export default () => (
  <section className="livingGoodLife-wrapper">
    <Container>
      <Row className="align-items-center">
        <Col md={12} lg={6} className="text-lg-left text-center">
          <img src={Building} className="mb-4 good-life-image" />
          <h2 className="text-uppercase good-life-title">
            constant.livethegoodlife!
          </h2>
          <h4>{constant.Amenities}:</h4>
          <p>
            Enjoy DOZENS OF HAPPINESS with a wide range of amenities in our
            properties
          </p>
        </Col>

        <Col md={12} lg={6}>
          <div className="amenities-grid-wrapper">
            <div className="amenities-item-col">
              <img src={WIFI} />
              <h3>{constant.Wifi}</h3>
            </div>
            <div className="amenities-item-col">
              <img src={RO} />
              <h3>{constant.RO}</h3>
            </div>
            <div className="amenities-item-col">
              <img src={DTH} />
              <h3>{constant.DTH}</h3>
            </div>
            <div className="amenities-item-col">
              <img src={WashingMachine} />
              <h3>{constant.WashingMachine}</h3>
            </div>
            <div className="amenities-item-col">
              <img src={PowerBackup} />
              <h3>{constant.LimitedPowerBackup}</h3>
            </div>
            <div className="amenities-item-col">
              <img src={CCTV} />
              <h3>{constant.CCTV}</h3>
            </div>
            <div className="amenities-item-col">
              <img src={TV} />
              <h3>{constant.TV}</h3>
            </div>
            <div className="amenities-item-col">
              <img src={Refrigerator} />
              <h3>{constant.Refrigerator}</h3>
            </div>
            <div className="amenities-item-col">
              <img src={AC} />
              <h3>{constant.AC}</h3>
            </div>
          </div>
        </Col>
      </Row>
    </Container>
  </section>
);
