import React,{useState,useEffect} from "react";
import Banner from "./Banner";
import LivingFacilities from "./livingFacilities";
import SafetyInstructions from "./safetyInstructions";
import LiveTheGoodLife from "./LiveTheGoodLife";
import Testimonial from "./testimonial";
import Comparison from "./Comparison";
import Layout from "../LayoutPage";
import Loader from "../Loader";
function HomePage(props) {
  const [loader,setloader]=useState(true);
  useEffect(() => {
    setloader(false) ; 
  }, [])
  return (
    <>
    {!loader?(<Layout transparentHeader>
      <div className="home-wrapper">
        <Banner />
        <LivingFacilities />
        <SafetyInstructions />
        <LiveTheGoodLife />
        <Testimonial />
        <Comparison />
      </div>
    </Layout>):(<Loader/>)}
    </>
  );
}

export default HomePage;
