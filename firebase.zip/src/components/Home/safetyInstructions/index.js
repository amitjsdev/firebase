import * as React from "react";
import {
  Container,
  FormGroup,
  Label,
  Input,
  Button,
  Row,
  Col,
} from "reactstrap";
import SafetyInstruction from "../../../assets/images/home/safetyInstruction.png";
import PrecautionFirst from "../../../assets/images/home/precautionFirst.png";
import RegularSanetize from "../../../assets/images/home/regularSanetize.png";
import DigitallyEmpowered from "../../../assets/images/home/digitallyEmpowered.png";
import constant from "../../../Services/constant.json"

export default () => (
  <section className="safety-instructions-wrapper">
    <Container>
      <Row>
        <Col md={12}>
          <h2>{constant.SafeandSanitisedstays}!</h2>
        </Col>
      </Row>
      <Row>
        <Col lg={3} sm={6}>
          <div className="instruction-col">
            <div className="instruction-image">
              <img src={SafetyInstruction} />
            </div>
            <h3>{constant.MinimalTouchPolicy}</h3>
            <p>Limited contact service followed by our staff</p>
          </div>
        </Col>
        <Col lg={3} sm={6}>
          <div className="instruction-col">
            <div className="instruction-image">
              <img src={PrecautionFirst} />
            </div>
            <h3>{constant.PrecautionFirst}</h3>
            <p>Regular temperature checks for Residents and Visitors</p>
          </div>
        </Col>
        <Col lg={3} sm={6}>
          <div className="instruction-col">
            <div className="instruction-image">
              <img src={RegularSanetize} />
            </div>
            <h3>{constant.RegularlySanitised}</h3>
            <p>All properties sanitized thoroughly by well-trained staff</p>
          </div>
        </Col>
        <Col lg={3} sm={6}>
          <div className="instruction-col">
            <div className="instruction-image">
              <img src={DigitallyEmpowered} />
            </div>
            <h3>{constant.DigitallyEmpowered}</h3>
            <p>Aarogya Setu App is mandatory for everyone</p>
          </div>
        </Col>
      </Row>
    </Container>
  </section>
);
