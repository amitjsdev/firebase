import * as React from "react";
import { useState, useEffect } from "react";
import {
  Container,
  // FormGroup,
  // Label,
  Input,
  Button,
  Select,
  Row,
  Col,
} from "reactstrap";
import { navigate } from "gatsby";
import Arrow from "../../../assets/images/home/arrow.png";
import SearchIcon from "../../../assets/images/home/search.png";
import BannerImage from "../../../assets/images/home/banner.png";
import constant from "../../../Services/Constant.json";
import Search from "../Banner/search";
export default () => {
  const [stateName, SetStateName] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  let sliderSettings = {
    dots: false,
    arrows: true,
    centerMode: true,
    centerPadding: "5px",
    infinite: true,
    speed: 500,
    slidesToShow: 3,
  };

  let SearchDisplay = ["chandigarh", "amritsar"];

  const handleWishList = () => {
    navigate("/wishlist");
  };
  const SearchList = () => {
    navigate("/" + stateName);
    console.log("ijnnnn", stateName);
  };

  useEffect(() => {
    console.log("asdsfdg");
    const results = SearchDisplay.filter((item) =>
      item.toLowerCase().includes(stateName.toLowerCase())
    );
    setSearchResults(results);
  }, [stateName]);
  const handleSearch = (e) => {
    console.log("gdgd");
    SetStateName(e.target.value);
  };

  return (
    <>
      <section
        className="home-banner-wrapper"
        style={{ backgroundImage: `url(${BannerImage})` }}
      >
        <Container>
          <Row>
            <Col md={7}>
              <div>
                <h2>{constant.heading}</h2>
              </div>
            </Col>
          </Row>
        </Container>
        <div className="search-wrapper">
          <div className="search-wrap">
            <Input
              type="search"
              name="search"
              value={stateName || ""}
              placeholder="Search City"
              id="myInput"
              //onKeyPress ={myFunction}
              onChange={(e) => {
                handleSearch(e);
              }}
            />
            {searchResults.length && stateName ? (
              <ul className="search-list-wrapper list-unstyled">
                {stateName &&
                  searchResults.map((item) => {
                    console.log("searchResults", searchResults.length);
                    return (
                      <li>
                        <a href={item}>{item}</a>
                      </li>
                    );
                  })}
              </ul>
            ) : (
              ""
            )}
          </div>

          <div>
            <Button color="theme" onClick={SearchList}>
              <img src={SearchIcon} />
            </Button>
          </div>
        </div>
      </section>
    </>
  );
};
