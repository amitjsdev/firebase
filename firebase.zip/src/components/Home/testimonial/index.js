import * as React from "react";
import {
  Container,
  FormGroup,
  Label,
  Input,
  Button,
  Row,
  Col,
} from "reactstrap";
import Client from "../../../assets/images/home/client.jpeg";
import constant from "../../../Services/constant.json"
import Slider from "react-slick";
function Testimonial(props) {
  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 4,
  };
  return (
    <section className="testimonial-wrapper">
      <Container>
        <Row>
          <Col md={12}>
            <h2 className="text-center">Testimonials</h2>
          </Col>
        </Row>
        <Row className="testimonial-list">
          <Col md={4}>
            <div className="testimonial-col">
              <div className="testimonial-image">
                <img src={Client} alt="client" />
              </div>

              <div className="content">
                <h3>{constant.Loremipsum}</h3>
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesettingindustry Lorem Ipsum has been the industry's
                  standard dummy text ever since
                </p>
              </div>
            </div>
          </Col>
          <Col md={4}>
            <div className="testimonial-col">
              <div className="testimonial-image">
                <img src={Client} alt="client" />
              </div>
              <div className="content">
                <h3>{constant.Loremipsum}</h3>
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesettingindustry Lorem Ipsum has been the industry's
                  standard dummy text ever since
                </p>
              </div>
            </div>
          </Col>
          <Col md={4}>
            <div className="testimonial-col">
              <div className="testimonial-image">
                <img src={Client} alt="client" />
              </div>
              <div className="content">
                <h3>{constant.Loremipsum}</h3>
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesettingindustry Lorem Ipsum has been the industry's
                  standard dummy text ever since
                </p>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  );
}

export default Testimonial;
