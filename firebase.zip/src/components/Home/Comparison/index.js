import * as React from "react";
import {
  Container,
  FormGroup,
  Label,
  Input,
  Button,
  Row,
  Col,
  Table,
} from "reactstrap";
import Check from "../../../assets/images/home/check.png";
import Cancel from "../../../assets/images/home/cancel.png";
import AppStore from "../../../assets/images/footer/app-store.png";
import PlayStore from "../../../assets/images/footer/play.png";
import constant from '../../../Services/constant.json'
function Comparison(props) {
  return (
    <section className="comparison-wrapper">
      <Container fluid className="px-0">
        <Row className="mx-0 align-items-center">
          <Col md={6} className="p-0">
            <Table bordered className="comparison-table mb-0">
              <thead>
                <tr>
                  <th></th>
                  <th>{constant.OyoLife}</th>
                  <th>Others</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{constant.Brokerage}</td>
                  <td>
                    <img src={Cancel} />
                  </td>
                  <td>
                    <img src={Check} />
                  </td>
                </tr>
                <tr>
                  <td> {constant.Only1monthSecurityDeposit}</td>
                  <td>
                    <img src={Check} />
                  </td>
                  <td>
                    <img src={Cancel} />
                  </td>
                </tr>
                <tr>
                  <td>{constant.RegularHousekeeping}</td>
                  <td>
                    <img src={Check} />
                  </td>
                  <td>
                    <img src={Cancel} />
                  </td>
                </tr>
                <tr>
                  <td>{constant.Furnishedwithamenities}</td>
                  <td>
                    <img src={Check} />
                  </td>
                  <td>
                    <img src={Cancel} />
                  </td>
                </tr>
                <tr>
                  <td>{constant.FreeWiFi}</td>
                  <td>
                    <img src={Check} />
                  </td>
                  <td>
                    <img src={Cancel} />
                  </td>
                </tr>
                <tr>
                  <td>{constant.HassleFreeMovein}</td>
                  <td>
                    <img src={Check} />
                  </td>
                  <td>
                    <img src={Cancel} />
                  </td>
                </tr>
                <tr>
                  <td>{constant.OYOLIFEAppenabledStay}</td>
                  <td>
                    <img src={Check} />
                  </td>
                  <td>
                    <img src={Cancel} />
                  </td>
                </tr>
                <tr>
                  <td>{constant.OncallStaySupervisor}</td>
                  <td>
                    <img src={Check} />
                  </td>
                  <td>
                    <img src={Cancel} />
                  </td>
                </tr>
              </tbody>
            </Table>
          </Col>
          <Col md={6} className="p-0 comparison-content-col">
            <div className="text-center comparison-content">
              <h2>{constant.Comparison}</h2>
              <p>How’s OYO LIFE better than Routine PGs and Unmanaged Flats?</p>
              <div>
                <h3>{constant.DownloadApp}</h3>
                <button>
                  <img src={AppStore} className="mr-2" />
                  App Store
                </button>
                <button>
                  <img src={PlayStore} className="mr-2" />
                  Play Store
                </button>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  );
}

export default Comparison;
