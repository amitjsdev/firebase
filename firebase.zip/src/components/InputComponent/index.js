import React from "react";
import { FormGroup, Label, Input } from "reactstrap";

const InputComponent = (props) => {
  const {
    label = "",
    type = "text",
    name,
    placeholder = "",
    onChange = () => {},
    value = "",
    errorType = "",
    errorText = "",
    ...rest
  } = props;
  return (
    <FormGroup>
      {label && <Label>{label}</Label>}
      <Input
        {...rest}
        type={type}
        name={name}
        placeholder={placeholder}
        onChange={onChange}
        value={value}
        
      />
      {errorType === name && (
        <span className="form-error text-danger">{errorText}</span>
      )}
    </FormGroup>
  );
};

export default InputComponent;
