import React,{ useState } from "react";
import Slider from "react-slick";
import SlideCard from "./SlideCard";

const slickSlider=(props)=>{
  const {settings,sliderImages} = props;

 
  
 

  // if(val)
  //   {
  //     console.log('loccccc',location)   
  //     return <Link to={location}></Link>
  //   }
  //   console.log('vaaa22',val)
  return (
    <div className="location-wrapper">
      <Slider {...settings} >
        {
          sliderImages.map(el=>{
            return (<SlideCard {...el}/>)
          }) 
        }
      </Slider>
    </div>
  );
}

export default slickSlider;
