import React,{useState} from 'react'
import { Link,Redirect } from '@reach/router';


function SlideCard(props) {
  const [val,setVal]=useState('');

  const handleImageClick=(text)=>{
    setVal(text)
  }

  if(val)
  {
    return <Redirect to={"/"+val}></Redirect>
  }

  return (
    <div className="location" onClick = {()=>handleImageClick(props.alt)}>
    <div className="image">
      <img src={props.img} alt={props.alt} />
    </div>
    <p className="mb-0">{props.alt}</p>
  </div>
  )
}

export default SlideCard

