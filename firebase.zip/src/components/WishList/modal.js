import React, { Component } from "react";
import InputComponent from "../InputComponent";
import { Button, ModalHeader, ModalBody, Modal } from "reactstrap";
import Emailapi from "../PartnerWithUs/emailapi";
// import TimePicker from"react-bootstrap-time-picker"
import constant from "../../Services/constant.json"

var DatePicker = require("reactstrap-date-picker");

class DateModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      value: "",
      show: this.props.modal,
      selectedTimeSlot: "",
      formattedValue: "",
      errorText: "",
      errorname: "",
      close: false,
    };

    this.handleTimeChange = this.handleTimeChange.bind(this);
  }

  handleTimeChange(time) {
    console.log(time);
    this.setState({ time });
  }
  handleDate(value1, formatted) {
    console.log("dd", value1, formatted);
    this.setState({
      value: value1,
      formattedValue: formatted,
      errorname: "",
    });
  }
  handleChange = (event) => {
    this.setState({ selectedTimeSlot: event.target.value, errorname: "" });
  };

  handleSubmit = () => {
    const { selectedTimeSlot, formattedValue } = this.state;
    if (formattedValue == "") {
      this.setState({
        errorname: "formattedValue",
        errorText: "Select the Date",
      });
      return;
    }
    if (selectedTimeSlot == "") {
      this.setState({
        errorname: "selectedTimeSlot",
        errorText: "Select the Time",
      });
      return;
    }
    // handleChange = (event) => {
    //     this.setState({
    //         [event.target.name]: event.target.value,
    //         errorText: "",
    //     });
    // };
    const email = localStorage.getItem("email");
    console.log("email====", email);
    console.log("props.data===", this.props.data.email);
   // console.log('asda')

    const emailUser = localStorage.getItem("email");
    // const emailAdmin = this.props.data.email;
    let emailData = [];
    emailData.push({ email }, { email: this.props.data.email });
    // emailData.push({ email }, { email: this.props.data.email });

    console.log(emailData, "emailDataemailDataemailData");
    // Emailapi({
    //     to: { email: email },
    //     subject: "  Scheduled Free Visit",
    //     content: `<strong>Scheduled Free Visit</strong>
    //        <tr><td><strong>selectedTimeSlot:</strong></td><td>${selectedTimeSlot}</td></tr>
    //         <tr><td><strong>formattedValue:</strong></td><td>${formattedValue}</td></tr>`
    // })
    //  Emailapi({
    //     to: { email: this.props.data.email },
    //     subject: "  Scheduled Free Visit",
    //     content: `<strong>Scheduled Free Visit</strong>
    //        <tr><td><strong>selectedTimeSlot:</strong></td><td>${selectedTimeSlot}</td></tr>
    //         <tr><td><strong>formattedValue:</strong></td><td>${formattedValue}</td></tr>`
    // })
    // if(emailData && emailData.length >0){
    //     emailData.map((item)=>{
    //         console.log(item,'item............');
    //         Emailapi({
    //             to: { name : 'mohit' , email: item  },
    //             subject: "Frequently Asked Questions",
    //             content: `<strong>Frequently Asked Questions</strong>
    //               <tr><td><strong>selectedTimeSlot:</strong></td><td>${selectedTimeSlot}</td></tr>
    //               <tr><td><strong>formattedValue:</strong></td><td>${formattedValue}</td></tr>`
    //           });

    //     })
    // }
    console.log("hdvkuwqvdkyc", selectedTimeSlot);
    Emailapi({
      to: emailData,
      subject: " Scheduled Free Visit",
      content: `<strong>Scheduled Free Visit</strong>
              
      <br><tr><td><strong>selectedTimeSlot:</strong></td><td>${selectedTimeSlot}</td></tr></br>
      <br><tr><td><strong>formattedValue:</strong></td><td>${formattedValue}</td></tr></br>`,
    });
   { selectedTimeSlot && this.props.setDate(formattedValue);}
   { selectedTimeSlot && this.props.setTime(selectedTimeSlot)}
   this.props.setValue(false)
    this.props.toggle();
    //this.handleCloseModal();
  };

  handleCloseModal=()=>{
    console.log('asda')
   return this.props.toggle
  }

  render() {
    const { show, selectedTimeSlot, formattedValue, errorname } = this.state;
    console.log(
      "ggggformattedValue",
      selectedTimeSlot,
      formattedValue,
      this.state.value
    );
    return (
      <div>
        <Modal
          isOpen={this.props.modal}
          // toggle={this.props.toggle}
          className="scheduled-modal-wrapper modal-dialog-centered"
        >
          <ModalHeader toggle={this.props.toggle}>
            {constant.ChooseaDatandTime}
          </ModalHeader>
          <ModalBody>
            <label>Date & Time:</label>
            <div className="d-flex">
              <div>
              <div>
                <DatePicker
                  id="example-datepicker"
                  value={this.state.value}
                  onChange={(v, f) => this.handleDate(v, f) }
                />
              </div>
         
              <p className="error">  {errorname == "formattedValue" && (
                  <span className="form-error text-danger">
                    {this.state.errorText}
                  </span>
                )}
              </p></div>
              <div className="ml-3">
                <select
                  name="selectedTimeSlot"
                  placeholder="Enter a date"
                  onChange={(e) => this.handleChange(e)}
                  className="form-control"
                >
                  {this.props.data.DateSlot &&
                    this.props.data.DateSlot.map((item) => {
                      return (
                        <>
                          <option value={item.value}>{item.value}</option>
                        </>
                      );
                    })}
                </select>
       
                <p className="error">{errorname == "selectedTimeSlot" && (
                <span className="form-error text-danger">
                  {this.state.errorText}
                </span>
              )}
              </p>
              </div>
            </div>
            <div className="text-center my-4">
              <Button color="theme" onClick={this.handleSubmit}>
                Scheduled Free Visit
              </Button>
            </div>
          </ModalBody>
        </Modal>
      </div>
    );
  }
}
export default DateModal;
