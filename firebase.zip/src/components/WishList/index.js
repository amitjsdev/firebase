import React, { useState, useEffect } from "react";
import { Button, Row, Col, Container } from "reactstrap";
import axios from "axios";
import { navigate } from "gatsby";
import url from "../../Services/PostData";
import Layout from "../LayoutPage";
import Like from "../../assets/images/rooms/like.svg";
import Filter from "../RoomList/Filters";
import UnLike from "../../assets/images/rooms/heart.svg";
import Slider from "react-slick";
import Loader from "../Loader";
import constant from  "../../Services/constant.json"
function Index(props) {
  const [number, setNumber] = useState(localStorage.getItem("number"));
  const [data, setData] = useState("");
  const [modal, setModal] = useState(false);
  let setButton =
    data[0] && data[0][1].wishlist.includes(localStorage.getItem("number"));
  console.log("asaasd", setButton);
  const [toggle, setToggle] = useState(setButton);
  const [value, setVal] = useState(false);
  const [loader,setLoader]=useState(true);
  useEffect(() => {
    let data = {
      phoneNumber: number,
    };
    axios.post(url.BaseUrl + "/wishlist/get/", data).then((response) => {
      console.log(response);
      setData(response.data);
      setLoader(false);
    });
  }, [value]);

  const ScheduledFreeVisit = (data) => {
    navigate(`/detail/${data[0]}`);
  };
  const settings = {
    dots: false,
    arrow: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    // centerMode: true,
  };
  console.log("dfsf123", props);

  const sendData = async (getid, getdata) => {
    setLoader(true)
    let newdel = getdata.wishlist.slice();
    const newArr = newdel.filter(
      (item) => item != localStorage.getItem("number")
    );
    let data = {
      wishlist: newArr,
    };
    console.log("df", newArr, getid);
    await axios
      .put(url.BaseUrl + "/wishlist/remove/add/" + getid, data)
      .then((response) => {
        let valToggle = JSON.parse(response.config.data).wishlist.includes(
          localStorage.getItem("number")
        );
        setToggle(valToggle);
        setVal(!value);
      })
      .catch((error) => console.log(error));
  };

  return (
    <Layout>
      <div className="room-listing-wrapper">
        <div className="sidebar-wrapper">
          <Filter
            LowestPriceHandle={""}
            HighestPriceHandle={""}
            Distance={""}
            monthlyRent={""}
            handleCheck={""}
            isChecked={""}
            isGender={""}
            filterPage="wishlist"
          />
        </div>
        {!loader ?(<div className="rooms-listing-wrap">
          <div className="rooms-listing">
            <h2 className="mb-4 font-weight-bold ">{constant.Wishlist}</h2>
            <Row>
              {data ?
                (data.map((data) => {
                  console.log("data[1].image", data[1].image);
                  return (
                    <Col md={4}>
                      <div className="rooms-information">
                        <Slider {...settings}>
                          {data[1].image &&
                            data[1].image.map((item) => {
                              if (!item.image) {
                                return null;
                              }
                              return (
                                <img
                                  src={item.image || ""}
                                  className="img-fluid room-image"
                                />
                              );
                            })}
                        </Slider>
                        <div className="p-4">
                          <div className="room-content">
                            <div className="d-flex justify-content-between align-items-center mb-1">
                              <h3 className="mb-0"> {data[1]?.id}</h3>
                              <Button
                                color="theme"
                                className="icon"
                                onClick={() => sendData(data[0], data[1])}
                              >
                                {toggle ? (
                                  <img src={UnLike} />
                                ) : (
                                  <img src={Like} />
                                )}
                              </Button>
                            </div>
                            <p>
                              {" "}
                              {data[1]?.address},{data[1]?.occupancy + " Bed"}
                            </p>
                            <div className="price-wrap">
                              <h4>
                                <sup className="price-symbol">₹</sup>
                                {data[1]?.price}
                              </h4>
                              <p>
                                <span className="text-uppercase discount">
                                  30% Off
                                </span>
                                <span>/monthly</span>
                              </p>
                            </div>
                            <Button
                              color="bordered"
                              onClick={() => ScheduledFreeVisit(data)}
                              // className="ml-1"
                            >
                              Scheduled Free Visit
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Col>
                  );
                })): (
                  <Col md={12}>
                    <h2 className="no-results">No Results found</h2>
                  </Col>
                )}
            </Row>
          </div>
        </div>):(<Loader/>)}
      </div>
    </Layout>
  );
}
export default Index;
