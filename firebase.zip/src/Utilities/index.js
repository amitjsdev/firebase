export const validatePhone = (phone)=>{
  let ph = new RegExp(/^[789]\d{9}$/);
  // alert(ph.test(phone));
}