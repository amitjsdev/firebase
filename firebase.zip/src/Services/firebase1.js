// import firebase from "firebase";
// const firebaseConfig = {
//     apiKey: "AIzaSyBcksvE89zmfyy7WmjBb40kd5UwzaCkrwo",
//     authDomain: "oyolife-2ce61.firebaseapp.com",
//     databaseURL: "https://oyolife-2ce61-default-rtdb.firebaseio.com",
//     projectId: "oyolife-2ce61",
//     storageBucket: "oyolife-2ce61.appspot.com",
//     messagingSenderId: "1041731606496",
//     appId: "1:1041731606496:web:aab16abbf45aa5741b3d85"
//   };
//   firebase.initializeApp(firebaseConfig);


//   export const auth = firebase.auth;
//   export const db = firebase.database();
//   export default firebase;


import firebase from 'firebase/app';
import 'firebase/auth'; // importing the auth module as an example

// Firebase web config
const config = {
  apiKey: "AIzaSyBcksvE89zmfyy7WmjBb40kd5UwzaCkrwo",
  authDomain: "oyolife-2ce61.firebaseapp.com",
  databaseURL: "https://oyolife-2ce61-default-rtdb.firebaseio.com",
  projectId: "oyolife-2ce61",
  storageBucket: "oyolife-2ce61.appspot.com",
  messagingSenderId: "1041731606496",
  appId: "1:1041731606496:web:aab16abbf45aa5741b3d85"
};

let instance = null;

export default function getFirebase() {
  if (typeof window !== 'undefined') {
    if (instance) return instance;
    instance = firebase.initializeApp(config);
    return instance;
  }

  return null;
}

