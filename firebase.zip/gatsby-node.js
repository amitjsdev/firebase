/**
 * Implement Gatsby's Node APIs in this file.
 *
 * See: https://www.gatsbyjs.com/docs/node-apis/
 */

// You can delete this file if you're not using it
const path = require('path');

exports.onCreatePage = async ({ page, actions }) => {
  const { createPage } = actions
  // Only update the `/app` page.
  console.log('fff',page.path)
  if (page.path.match(/^\//)) {
    // page.matchPath is a special key that's used for matching pages
    // with corresponding routes only on the client.
    //page.matchPath = "/*"
    // Update the page.
   // createPage(page)
    createPage({
      path:"/",
      matchPath:'/*',
      component:path.resolve('src/pages/index.js')
    })
  }
}

exports.onCreateWebpackConfig = ({ stage, actions, getConfig }) => {
  if (stage === 'build-html') {
    actions.setWebpackConfig({
      externals: getConfig().externals.concat(function(context, request, callback) {
        const regex = /^@?firebase(\/(.+))?/;
        if (regex.test(request)) {
          return callback(null, `umd ${request}`);
        }
        callback();
      }),
    });
  }
};
